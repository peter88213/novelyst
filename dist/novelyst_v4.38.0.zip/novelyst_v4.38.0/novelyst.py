#!/usr/bin/python3
"""A novel organizer for writers. 

Version 4.38.0
Requires Python 3.6+
Copyright (c) 2023 Peter Triesberger
For further information see https://github.com/peter88213/novelyst
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
import sys
from pathlib import Path
import gettext
import locale

__all__ = ['Error',
           '_',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           'norm_path',
           'string_to_list',
           'list_to_string',
           ]


class Error(Exception):
    pass


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('pywriter', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)
import webbrowser
from tkinter import ttk
from tkinter import filedialog
import re
from typing import Iterator, Pattern


class BasicElement:

    def __init__(self):
        self.title: str = None

        self.desc: str = None

        self.kwVar: dict[str, str] = {}


class Chapter(BasicElement):

    def __init__(self):
        super().__init__()

        self.chLevel: int = None

        self.chType: int = None

        self.suppressChapterTitle: bool = None

        self.isTrash: bool = None

        self.suppressChapterBreak: bool = None

        self.srtScenes: list[str] = []
from typing import Pattern


ADDITIONAL_WORD_LIMITS: Pattern = re.compile('--|—|–')

NO_WORD_LIMITS: Pattern = re.compile('\[.+?\]|\/\*.+?\*\/|-|^\>', re.MULTILINE)

NON_LETTERS: Pattern = re.compile('\[.+?\]|\/\*.+?\*\/|\n|\r')


class Scene(BasicElement):
    STATUS: set = (None, 'Outline', 'Draft', '1st Edit', '2nd Edit', 'Done')

    ACTION_MARKER: str = 'A'
    REACTION_MARKER: str = 'R'
    NULL_DATE: str = '0001-01-01'
    NULL_TIME: str = '00:00:00'

    def __init__(self):
        super().__init__()

        self._sceneContent: str = None

        self.wordCount: int = 0

        self.letterCount: int = 0

        self.scType: int = None

        self.doNotExport: bool = None

        self.status: int = None

        self.notes: str = None

        self.tags: list[str] = None

        self.field1: str = None

        self.field2: str = None

        self.field3: str = None

        self.field4: str = None

        self.appendToPrev: bool = None

        self.isReactionScene: bool = None

        self.isSubPlot: bool = None

        self.goal: str = None

        self.conflict: str = None

        self.outcome: str = None

        self.characters: list[str] = None

        self.locations: list[str] = None

        self.items: list[str] = None

        self.date: str = None

        self.time: str = None

        self.day: str = None

        self.lastsMinutes: str = None

        self.lastsHours: str = None

        self.lastsDays: str = None

        self.image: str = None

        self.scnArcs: str = None

        self.scnStyle: str = None

    @property
    def sceneContent(self) -> str:
        return self._sceneContent

    @sceneContent.setter
    def sceneContent(self, text: str):
        self._sceneContent = text
        text = ADDITIONAL_WORD_LIMITS.sub(' ', text)
        text = NO_WORD_LIMITS.sub('', text)
        wordList = text.split()
        self.wordCount = len(wordList)
        text = NON_LETTERS.sub('', self._sceneContent)
        self.letterCount = len(text)


class WorldElement(BasicElement):

    def __init__(self):
        super().__init__()

        self.image: str = None

        self.tags: list[str] = None

        self.aka: str = None



class Character(WorldElement):
    MAJOR_MARKER: str = 'Major'
    MINOR_MARKER: str = 'Minor'

    def __init__(self):
        super().__init__()

        self.notes: str = None

        self.bio: str = None

        self.goals: str = None

        self.fullName: str = None

        self.isMajor: bool = None

LANGUAGE_TAG: Pattern = re.compile('\[lang=(.*?)\]')


class Novel(BasicElement):

    def __init__(self):
        super().__init__()

        self.authorName: str = None

        self.authorBio: str = None

        self.fieldTitle1: str = None

        self.fieldTitle2: str = None

        self.fieldTitle3: str = None

        self.fieldTitle4: str = None

        self.wordTarget: int = None

        self.wordCountStart: int = None

        self.wordTarget: int = None

        self.chapters: dict[str, Chapter] = {}

        self.scenes: dict[str, Scene] = {}

        self.languages: list[str] = None

        self.srtChapters: list[str] = []

        self.locations: dict[str, WorldElement] = {}

        self.srtLocations: list[str] = []

        self.items: dict[str, WorldElement] = {}

        self.srtItems: list[str] = []

        self.characters: dict[str, Character] = {}

        self.srtCharacters: list[str] = []

        self.projectNotes: dict[str, BasicElement] = {}

        self.srtPrjNotes: list[str] = []

        self.languageCode: str = None

        self.countryCode: str = None

    def get_languages(self):

        def languages(text: str) -> Iterator[str]:
            if text:
                m = LANGUAGE_TAG.search(text)
                while m:
                    text = text[m.span()[1]:]
                    yield m.group(1)
                    m = LANGUAGE_TAG.search(text)

        self.languages = []
        for scId in self.scenes:
            text = self.scenes[scId].sceneContent
            if text:
                for language in languages(text):
                    if not language in self.languages:
                        self.languages.append(language)

    def check_locale(self):
        if not self.languageCode:
            try:
                sysLng, sysCtr = locale.getlocale()[0].split('_')
            except:
                sysLng, sysCtr = locale.getdefaultlocale()[0].split('_')
            self.languageCode = sysLng
            self.countryCode = sysCtr
            return

        try:
            if len(self.languageCode) == 2:
                if len(self.countryCode) == 2:
                    return
        except:
            pass
        self.languageCode = 'zxx'
        self.countryCode = 'none'

import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox


class Ui:

    def __init__(self, title):
        self.infoWhatText = ''
        self.infoHowText = ''

    def ask_yes_no(self, text):
        return True

    def set_info_how(self, message):
        if message.startswith('!'):
            message = f'FAIL: {message.split("!", maxsplit=1)[1].strip()}'
            sys.stderr.write(message)
        self.infoHowText = message

    def set_info_what(self, message):
        self.infoWhatText = message

    def show_warning(self, message):
        pass

    def start(self):
        pass

from html import unescape
from datetime import datetime
import xml.etree.ElementTree as ET
from abc import ABC
from urllib.parse import quote


class File(ABC):
    DESCRIPTION = _('File')
    EXTENSION = None
    SUFFIX = None

    PRJ_KWVAR = []
    CHP_KWVAR = []
    SCN_KWVAR = []
    CRT_KWVAR = []
    LOC_KWVAR = []
    ITM_KWVAR = []
    PNT_KWVAR = []

    def __init__(self, filePath, **kwargs):
        self.novel = None

        self._filePath = None

        self.projectName = None

        self.projectPath = None

        self.scenesSplit = False
        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath):
        if self.SUFFIX is not None:
            suffix = self.SUFFIX
        else:
            suffix = ''
        if filePath.lower().endswith(f'{suffix}{self.EXTENSION}'.lower()):
            self._filePath = filePath
            try:
                head, tail = os.path.split(os.path.realpath(filePath))
            except:
                head, tail = os.path.split(filePath)
            self.projectPath = quote(head.replace('\\', '/'), '/:')
            self.projectName = quote(tail.replace(f'{suffix}{self.EXTENSION}', ''))

    def read(self):
        raise NotImplementedError

    def write(self):
        raise NotImplementedError

    def _convert_from_yw(self, text, quick=False):
        return text.rstrip()

    def _convert_to_yw(self, text):
        return text.rstrip()

from typing import Iterable


def create_id(elements: Iterable) -> str:
    i = 1
    while str(i) in elements:
        i += 1
    return str(i)



def indent(elem, level=0):
    i = f'\n{level * "  "}'
    if elem:
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


class Yw7File(File):
    DESCRIPTION = _('yWriter 7 project')
    EXTENSION = '.yw7'
    _CDATA_TAGS = ['Title', 'AuthorName', 'Bio', 'Desc',
                   'FieldTitle1', 'FieldTitle2', 'FieldTitle3',
                   'FieldTitle4', 'LaTeXHeaderFile', 'Tags',
                   'AKA', 'ImageFile', 'FullName', 'Goals',
                   'Notes', 'RTFFile', 'SceneContent',
                   'Outcome', 'Goal', 'Conflict']

    PRJ_KWVAR = [
        'Field_LanguageCode',
        'Field_CountryCode',
        ]
    SCN_KWVAR = [
        'Field_SceneArcs',
        'Field_SceneStyle',
        ]

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self.tree = None

    def adjust_scene_types(self):
        for chId in self.novel.srtChapters:
            if self.novel.chapters[chId].chType != 0:
                for scId in self.novel.chapters[chId].srtScenes:
                    self.novel.scenes[scId].scType = self.novel.chapters[chId].chType

    def is_locked(self):
        return os.path.isfile(f'{self.filePath}.lock')

    def read(self):

        for field in self.PRJ_KWVAR:
            self.novel.kwVar[field] = None

        if self.is_locked():
            raise Error(f'{_("yWriter seems to be open. Please close first")}.')
        try:
            self.tree = ET.parse(self.filePath)
        except:
            raise Error(f'{_("Can not process file")}: "{norm_path(self.filePath)}".')

        root = self.tree.getroot()
        self._read_project(root)
        self._read_locations(root)
        self._read_items(root)
        self._read_characters(root)
        self._read_projectvars(root)
        self._read_projectnotes(root)
        self._read_scenes(root)
        self._read_chapters(root)
        self.adjust_scene_types()

        for scId in self.novel.scenes:
            self.novel.scenes[scId].scnArcs = self.novel.scenes[scId].kwVar.get('Field_SceneArcs', None)
            self.novel.scenes[scId].scnStyle = self.novel.scenes[scId].kwVar.get('Field_SceneStyle', None)

    def write(self):
        if self.is_locked():
            raise Error(f'{_("yWriter seems to be open. Please close first")}.')

        if self.novel.languages is None:
            self.novel.get_languages()

        for scId in self.novel.scenes:
            if self.novel.scenes[scId].scnArcs is not None:
                self.novel.scenes[scId].kwVar['Field_SceneArcs'] = self.novel.scenes[scId].scnArcs
            if self.novel.scenes[scId].scnStyle is not None:
                self.novel.scenes[scId].kwVar['Field_SceneStyle'] = self.novel.scenes[scId].scnStyle

        self._build_element_tree()
        self._write_element_tree(self)
        self._postprocess_xml_file(self.filePath)

    def _build_element_tree(self):

        def set_element(parent, tag, text, index):
            subelement = parent.find(tag)
            if subelement is None:
                if text is not None:
                    subelement = ET.Element(tag)
                    parent.insert(index, subelement)
                    subelement.text = text
                    index += 1
            elif text is not None:
                subelement.text = text
                index += 1
            return index

        def build_scene_subtree(xmlScene, prjScn):

            def remove_date_time():
                if xmlScene.find('SpecificDateTime') is not None:
                    xmlScene.remove(xmlScene.find('SpecificDateTime'))

                if xmlScene.find('SpecificDateMode') is not None:
                    xmlScene.remove(xmlScene.find('SpecificDateMode'))

                if xmlScene.find('Day') is not None:
                    xmlScene.remove(xmlScene.find('Day'))

                if xmlScene.find('Hour') is not None:
                    xmlScene.remove(xmlScene.find('Hour'))

                if xmlScene.find('Minute') is not None:
                    xmlScene.remove(xmlScene.find('Minute'))

            i = 1
            i = set_element(xmlScene, 'Title', prjScn.title, i)

            if xmlScene.find('BelongsToChID') is None:
                for chId in self.novel.chapters:
                    if scId in self.novel.chapters[chId].srtScenes:
                        ET.SubElement(xmlScene, 'BelongsToChID').text = chId
                        break

            if prjScn.desc is not None:
                try:
                    xmlScene.find('Desc').text = prjScn.desc
                except(AttributeError):
                    if prjScn.desc:
                        ET.SubElement(xmlScene, 'Desc').text = prjScn.desc

            if xmlScene.find('SceneContent') is None:
                ET.SubElement(xmlScene, 'SceneContent').text = prjScn.sceneContent

            if xmlScene.find('WordCount') is None:
                ET.SubElement(xmlScene, 'WordCount').text = str(prjScn.wordCount)

            if xmlScene.find('LetterCount') is None:
                ET.SubElement(xmlScene, 'LetterCount').text = str(prjScn.letterCount)


            scTypeEncoding = (
                (False, None),
                (True, '1'),
                (True, '2'),
                (True, '0'),
                )
            if prjScn.scType is None:
                prjScn.scType = 0
            yUnused, ySceneType = scTypeEncoding[prjScn.scType]

            if yUnused:
                if xmlScene.find('Unused') is None:
                    ET.SubElement(xmlScene, 'Unused').text = '-1'
            elif xmlScene.find('Unused') is not None:
                xmlScene.remove(xmlScene.find('Unused'))

            xmlSceneFields = xmlScene.find('Fields')
            if xmlSceneFields is not None:
                fieldScType = xmlSceneFields.find('Field_SceneType')
                if ySceneType is None:
                    if fieldScType is not None:
                        xmlSceneFields.remove(fieldScType)
                else:
                    try:
                        fieldScType.text = ySceneType
                    except(AttributeError):
                        ET.SubElement(xmlSceneFields, 'Field_SceneType').text = ySceneType
            elif ySceneType is not None:
                xmlSceneFields = ET.SubElement(xmlScene, 'Fields')
                ET.SubElement(xmlSceneFields, 'Field_SceneType').text = ySceneType

            if self.novel.scenes[scId].doNotExport is not None:
                xmlExportCondSpecific = xmlScene.find('ExportCondSpecific')
                xmlExportWhenRtf = xmlScene.find('ExportWhenRTF')
                if self.novel.scenes[scId].doNotExport:
                    if xmlExportCondSpecific is None:
                        xmlExportCondSpecific = ET.SubElement(xmlScene, 'ExportCondSpecific')
                    if xmlExportWhenRtf is not None:
                        xmlScene.remove(xmlExportWhenRtf)
                else:
                    if xmlExportCondSpecific is not None:
                        if xmlExportWhenRtf is None:
                            ET.SubElement(xmlScene, 'ExportWhenRTF').text = '-1'

            for field in self.SCN_KWVAR:
                if self.novel.scenes[scId].kwVar.get(field, None):
                    if xmlSceneFields is None:
                        xmlSceneFields = ET.SubElement(xmlScene, 'Fields')
                    try:
                        xmlSceneFields.find(field).text = self.novel.scenes[scId].kwVar[field]
                    except(AttributeError):
                        ET.SubElement(xmlSceneFields, field).text = self.novel.scenes[scId].kwVar[field]
                elif xmlSceneFields is not None:
                    try:
                        xmlSceneFields.remove(xmlSceneFields.find(field))
                    except:
                        pass

            if prjScn.status is not None:
                try:
                    xmlScene.find('Status').text = str(prjScn.status)
                except:
                    ET.SubElement(xmlScene, 'Status').text = str(prjScn.status)

            if prjScn.notes is not None:
                try:
                    xmlScene.find('Notes').text = prjScn.notes
                except(AttributeError):
                    if prjScn.notes:
                        ET.SubElement(xmlScene, 'Notes').text = prjScn.notes

            if prjScn.tags is not None:
                try:
                    xmlScene.find('Tags').text = list_to_string(prjScn.tags)
                except(AttributeError):
                    if prjScn.tags:
                        ET.SubElement(xmlScene, 'Tags').text = list_to_string(prjScn.tags)

            if prjScn.field1 is not None:
                try:
                    xmlScene.find('Field1').text = prjScn.field1
                except(AttributeError):
                    if prjScn.field1:
                        ET.SubElement(xmlScene, 'Field1').text = prjScn.field1

            if prjScn.field2 is not None:
                try:
                    xmlScene.find('Field2').text = prjScn.field2
                except(AttributeError):
                    if prjScn.field2:
                        ET.SubElement(xmlScene, 'Field2').text = prjScn.field2

            if prjScn.field3 is not None:
                try:
                    xmlScene.find('Field3').text = prjScn.field3
                except(AttributeError):
                    if prjScn.field3:
                        ET.SubElement(xmlScene, 'Field3').text = prjScn.field3

            if prjScn.field4 is not None:
                try:
                    xmlScene.find('Field4').text = prjScn.field4
                except(AttributeError):
                    if prjScn.field4:
                        ET.SubElement(xmlScene, 'Field4').text = prjScn.field4

            if prjScn.appendToPrev:
                if xmlScene.find('AppendToPrev') is None:
                    ET.SubElement(xmlScene, 'AppendToPrev').text = '-1'
            elif xmlScene.find('AppendToPrev') is not None:
                xmlScene.remove(xmlScene.find('AppendToPrev'))

            if (prjScn.date is not None) and (prjScn.time is not None):
                separator = ' '
                dateTime = f'{prjScn.date}{separator}{prjScn.time}'

                if dateTime == separator:
                    remove_date_time()

                elif xmlScene.find('SpecificDateTime') is not None:
                    if dateTime.count(':') < 2:
                        dateTime = f'{dateTime}:00'
                    xmlScene.find('SpecificDateTime').text = dateTime
                else:
                    ET.SubElement(xmlScene, 'SpecificDateTime').text = dateTime
                    ET.SubElement(xmlScene, 'SpecificDateMode').text = '-1'

                    if xmlScene.find('Day') is not None:
                        xmlScene.remove(xmlScene.find('Day'))

                    if xmlScene.find('Hour') is not None:
                        xmlScene.remove(xmlScene.find('Hour'))

                    if xmlScene.find('Minute') is not None:
                        xmlScene.remove(xmlScene.find('Minute'))

            elif (prjScn.day is not None) or (prjScn.time is not None):

                if not prjScn.day and not prjScn.time:
                    remove_date_time()

                else:
                    if xmlScene.find('SpecificDateTime') is not None:
                        xmlScene.remove(xmlScene.find('SpecificDateTime'))

                    if xmlScene.find('SpecificDateMode') is not None:
                        xmlScene.remove(xmlScene.find('SpecificDateMode'))
                    if prjScn.day is not None:
                        try:
                            xmlScene.find('Day').text = prjScn.day
                        except(AttributeError):
                            ET.SubElement(xmlScene, 'Day').text = prjScn.day
                    if prjScn.time is not None:
                        hours, minutes, __ = prjScn.time.split(':')
                        try:
                            xmlScene.find('Hour').text = hours
                        except(AttributeError):
                            ET.SubElement(xmlScene, 'Hour').text = hours
                        try:
                            xmlScene.find('Minute').text = minutes
                        except(AttributeError):
                            ET.SubElement(xmlScene, 'Minute').text = minutes

            if prjScn.lastsDays is not None:
                try:
                    xmlScene.find('LastsDays').text = prjScn.lastsDays
                except(AttributeError):
                    if prjScn.lastsDays:
                        ET.SubElement(xmlScene, 'LastsDays').text = prjScn.lastsDays

            if prjScn.lastsHours is not None:
                try:
                    xmlScene.find('LastsHours').text = prjScn.lastsHours
                except(AttributeError):
                    if prjScn.lastsHours:
                        ET.SubElement(xmlScene, 'LastsHours').text = prjScn.lastsHours

            if prjScn.lastsMinutes is not None:
                try:
                    xmlScene.find('LastsMinutes').text = prjScn.lastsMinutes
                except(AttributeError):
                    if prjScn.lastsMinutes:
                        ET.SubElement(xmlScene, 'LastsMinutes').text = prjScn.lastsMinutes

            if prjScn.isReactionScene:
                if xmlScene.find('ReactionScene') is None:
                    ET.SubElement(xmlScene, 'ReactionScene').text = '-1'
            elif xmlScene.find('ReactionScene') is not None:
                xmlScene.remove(xmlScene.find('ReactionScene'))

            if prjScn.isSubPlot:
                if xmlScene.find('SubPlot') is None:
                    ET.SubElement(xmlScene, 'SubPlot').text = '-1'
            elif xmlScene.find('SubPlot') is not None:
                xmlScene.remove(xmlScene.find('SubPlot'))

            if prjScn.goal is not None:
                try:
                    xmlScene.find('Goal').text = prjScn.goal
                except(AttributeError):
                    if prjScn.goal:
                        ET.SubElement(xmlScene, 'Goal').text = prjScn.goal

            if prjScn.conflict is not None:
                try:
                    xmlScene.find('Conflict').text = prjScn.conflict
                except(AttributeError):
                    if prjScn.conflict:
                        ET.SubElement(xmlScene, 'Conflict').text = prjScn.conflict

            if prjScn.outcome is not None:
                try:
                    xmlScene.find('Outcome').text = prjScn.outcome
                except(AttributeError):
                    if prjScn.outcome:
                        ET.SubElement(xmlScene, 'Outcome').text = prjScn.outcome

            if prjScn.image is not None:
                try:
                    xmlScene.find('ImageFile').text = prjScn.image
                except(AttributeError):
                    if prjScn.image:
                        ET.SubElement(xmlScene, 'ImageFile').text = prjScn.image

            if prjScn.characters is not None:
                xmlCharacters = xmlScene.find('Characters')
                try:
                    for oldCrId in xmlCharacters.findall('CharID'):
                        xmlCharacters.remove(oldCrId)
                except(AttributeError):
                    xmlCharacters = ET.SubElement(xmlScene, 'Characters')
                for crId in prjScn.characters:
                    ET.SubElement(xmlCharacters, 'CharID').text = crId

            if prjScn.locations is not None:
                xmlLocations = xmlScene.find('Locations')
                try:
                    for oldLcId in xmlLocations.findall('LocID'):
                        xmlLocations.remove(oldLcId)
                except(AttributeError):
                    xmlLocations = ET.SubElement(xmlScene, 'Locations')
                for lcId in prjScn.locations:
                    ET.SubElement(xmlLocations, 'LocID').text = lcId

            if prjScn.items is not None:
                xmlItems = xmlScene.find('Items')
                try:
                    for oldItId in xmlItems.findall('ItemID'):
                        xmlItems.remove(oldItId)
                except(AttributeError):
                    xmlItems = ET.SubElement(xmlScene, 'Items')
                for itId in prjScn.items:
                    ET.SubElement(xmlItems, 'ItemID').text = itId


        def build_chapter_subtree(xmlChapter, prjChp, sortOrder):

            chTypeEncoding = (
                (False, '0', '0'),
                (True, '1', '1'),
                (True, '1', '2'),
                (True, '1', '0'),
                )
            if prjChp.chType is None:
                prjChp.chType = 0
            yUnused, yType, yChapterType = chTypeEncoding[prjChp.chType]

            i = 1
            i = set_element(xmlChapter, 'Title', prjChp.title, i)
            i = set_element(xmlChapter, 'Desc', prjChp.desc, i)

            if yUnused:
                if xmlChapter.find('Unused') is None:
                    elem = ET.Element('Unused')
                    elem.text = '-1'
                    xmlChapter.insert(i, elem)
            elif xmlChapter.find('Unused') is not None:
                xmlChapter.remove(xmlChapter.find('Unused'))
            if xmlChapter.find('Unused') is not None:
                i += 1

            i = set_element(xmlChapter, 'SortOrder', str(sortOrder), i)

            xmlChapterFields = xmlChapter.find('Fields')
            if prjChp.suppressChapterTitle:
                if xmlChapterFields is None:
                    xmlChapterFields = ET.Element('Fields')
                    xmlChapter.insert(i, xmlChapterFields)
                try:
                    xmlChapterFields.find('Field_SuppressChapterTitle').text = '1'
                except(AttributeError):
                    ET.SubElement(xmlChapterFields, 'Field_SuppressChapterTitle').text = '1'
            elif xmlChapterFields is not None:
                if xmlChapterFields.find('Field_SuppressChapterTitle') is not None:
                    xmlChapterFields.find('Field_SuppressChapterTitle').text = '0'

            if prjChp.suppressChapterBreak:
                if xmlChapterFields is None:
                    xmlChapterFields = ET.Element('Fields')
                    xmlChapter.insert(i, xmlChapterFields)
                try:
                    xmlChapterFields.find('Field_SuppressChapterBreak').text = '1'
                except(AttributeError):
                    ET.SubElement(xmlChapterFields, 'Field_SuppressChapterBreak').text = '1'
            elif xmlChapterFields is not None:
                if xmlChapterFields.find('Field_SuppressChapterBreak') is not None:
                    xmlChapterFields.find('Field_SuppressChapterBreak').text = '0'

            if prjChp.isTrash:
                if xmlChapterFields is None:
                    xmlChapterFields = ET.Element('Fields')
                    xmlChapter.insert(i, xmlChapterFields)
                try:
                    xmlChapterFields.find('Field_IsTrash').text = '1'
                except(AttributeError):
                    ET.SubElement(xmlChapterFields, 'Field_IsTrash').text = '1'

            elif xmlChapterFields is not None:
                if xmlChapterFields.find('Field_IsTrash') is not None:
                    xmlChapterFields.remove(xmlChapterFields.find('Field_IsTrash'))

            for field in self.CHP_KWVAR:
                if prjChp.kwVar.get(field, None):
                    if xmlChapterFields is None:
                        xmlChapterFields = ET.Element('Fields')
                        xmlChapter.insert(i, xmlChapterFields)
                    try:
                        xmlChapterFields.find(field).text = prjChp.kwVar[field]
                    except(AttributeError):
                        ET.SubElement(xmlChapterFields, field).text = prjChp.kwVar[field]
                elif xmlChapterFields is not None:
                    try:
                        xmlChapterFields.remove(xmlChapterFields.find(field))
                    except:
                        pass
            if xmlChapter.find('Fields') is not None:
                i += 1

            if xmlChapter.find('SectionStart') is not None:
                if prjChp.chLevel == 0:
                    xmlChapter.remove(xmlChapter.find('SectionStart'))
            elif prjChp.chLevel == 1:
                elem = ET.Element('SectionStart')
                elem.text = '-1'
                xmlChapter.insert(i, elem)
            if xmlChapter.find('SectionStart') is not None:
                i += 1

            i = set_element(xmlChapter, 'Type', yType, i)
            i = set_element(xmlChapter, 'ChapterType', yChapterType, i)

            xmlScnList = xmlChapter.find('Scenes')

            if xmlScnList is not None:
                xmlChapter.remove(xmlScnList)

            if prjChp.srtScenes:
                xmlScnList = ET.Element('Scenes')
                xmlChapter.insert(i, xmlScnList)
                for scId in prjChp.srtScenes:
                    ET.SubElement(xmlScnList, 'ScID').text = scId

        def build_location_subtree(xmlLoc, prjLoc, sortOrder):
            if prjLoc.title is not None:
                ET.SubElement(xmlLoc, 'Title').text = prjLoc.title

            if prjLoc.image is not None:
                ET.SubElement(xmlLoc, 'ImageFile').text = prjLoc.image

            if prjLoc.desc is not None:
                ET.SubElement(xmlLoc, 'Desc').text = prjLoc.desc

            if prjLoc.aka is not None:
                ET.SubElement(xmlLoc, 'AKA').text = prjLoc.aka

            if prjLoc.tags is not None:
                ET.SubElement(xmlLoc, 'Tags').text = list_to_string(prjLoc.tags)

            ET.SubElement(xmlLoc, 'SortOrder').text = str(sortOrder)

            xmlLocationFields = xmlLoc.find('Fields')
            for field in self.LOC_KWVAR:
                if self.novel.locations[lcId].kwVar.get(field, None):
                    if xmlLocationFields is None:
                        xmlLocationFields = ET.SubElement(xmlLoc, 'Fields')
                    try:
                        xmlLocationFields.find(field).text = self.novel.locations[lcId].kwVar[field]
                    except(AttributeError):
                        ET.SubElement(xmlLocationFields, field).text = self.novel.locations[lcId].kwVar[field]
                elif xmlLocationFields is not None:
                    try:
                        xmlLocationFields.remove(xmlLocationFields.find(field))
                    except:
                        pass

        def build_prjNote_subtree(xmlProjectnote, projectNote, sortOrder):
            if projectNote.title is not None:
                ET.SubElement(xmlProjectnote, 'Title').text = projectNote.title

            if projectNote.desc is not None:
                ET.SubElement(xmlProjectnote, 'Desc').text = projectNote.desc

            ET.SubElement(xmlProjectnote, 'SortOrder').text = str(sortOrder)

        def add_projectvariable(title, desc, tags):
            pvId = create_id(prjVars)
            prjVars.append(pvId)
            xmlProjectvar = ET.SubElement(xmlProjectvars, 'PROJECTVAR')
            ET.SubElement(xmlProjectvar, 'ID').text = pvId
            ET.SubElement(xmlProjectvar, 'Title').text = title
            ET.SubElement(xmlProjectvar, 'Desc').text = desc
            ET.SubElement(xmlProjectvar, 'Tags').text = tags

        def build_item_subtree(xmlItm, prjItm, sortOrder):
            if prjItm.title is not None:
                ET.SubElement(xmlItm, 'Title').text = prjItm.title

            if prjItm.image is not None:
                ET.SubElement(xmlItm, 'ImageFile').text = prjItm.image

            if prjItm.desc is not None:
                ET.SubElement(xmlItm, 'Desc').text = prjItm.desc

            if prjItm.aka is not None:
                ET.SubElement(xmlItm, 'AKA').text = prjItm.aka

            if prjItm.tags is not None:
                ET.SubElement(xmlItm, 'Tags').text = list_to_string(prjItm.tags)

            ET.SubElement(xmlItm, 'SortOrder').text = str(sortOrder)

            xmlItemFields = xmlItm.find('Fields')
            for field in self.ITM_KWVAR:
                if self.novel.items[itId].kwVar.get(field, None):
                    if xmlItemFields is None:
                        xmlItemFields = ET.SubElement(xmlItm, 'Fields')
                    try:
                        xmlItemFields.find(field).text = self.novel.items[itId].kwVar[field]
                    except(AttributeError):
                        ET.SubElement(xmlItemFields, field).text = self.novel.items[itId].kwVar[field]
                elif xmlItemFields is not None:
                    try:
                        xmlItemFields.remove(xmlItemFields.find(field))
                    except:
                        pass

        def build_character_subtree(xmlCrt, prjCrt, sortOrder):
            if prjCrt.title is not None:
                ET.SubElement(xmlCrt, 'Title').text = prjCrt.title

            if prjCrt.desc is not None:
                ET.SubElement(xmlCrt, 'Desc').text = prjCrt.desc

            if prjCrt.image is not None:
                ET.SubElement(xmlCrt, 'ImageFile').text = prjCrt.image

            ET.SubElement(xmlCrt, 'SortOrder').text = str(sortOrder)

            if prjCrt.notes is not None:
                ET.SubElement(xmlCrt, 'Notes').text = prjCrt.notes

            if prjCrt.aka is not None:
                ET.SubElement(xmlCrt, 'AKA').text = prjCrt.aka

            if prjCrt.tags is not None:
                ET.SubElement(xmlCrt, 'Tags').text = list_to_string(prjCrt.tags)

            if prjCrt.bio is not None:
                ET.SubElement(xmlCrt, 'Bio').text = prjCrt.bio

            if prjCrt.goals is not None:
                ET.SubElement(xmlCrt, 'Goals').text = prjCrt.goals

            if prjCrt.fullName is not None:
                ET.SubElement(xmlCrt, 'FullName').text = prjCrt.fullName

            if prjCrt.isMajor:
                ET.SubElement(xmlCrt, 'Major').text = '-1'

            xmlCharacterFields = xmlCrt.find('Fields')
            for field in self.CRT_KWVAR:
                if self.novel.characters[crId].kwVar.get(field, None):
                    if xmlCharacterFields is None:
                        xmlCharacterFields = ET.SubElement(xmlCrt, 'Fields')
                    try:
                        xmlCharacterFields.find(field).text = self.novel.characters[crId].kwVar[field]
                    except(AttributeError):
                        ET.SubElement(xmlCharacterFields, field).text = self.novel.characters[crId].kwVar[field]
                elif xmlCharacterFields is not None:
                    try:
                        xmlCharacterFields.remove(xmlCharacterFields.find(field))
                    except:
                        pass

        def build_project_subtree(xmlProject):
            VER = '7'
            try:
                xmlProject.find('Ver').text = VER
            except(AttributeError):
                ET.SubElement(xmlProject, 'Ver').text = VER

            if self.novel.title is not None:
                try:
                    xmlProject.find('Title').text = self.novel.title
                except(AttributeError):
                    ET.SubElement(xmlProject, 'Title').text = self.novel.title

            if self.novel.desc is not None:
                try:
                    xmlProject.find('Desc').text = self.novel.desc
                except(AttributeError):
                    ET.SubElement(xmlProject, 'Desc').text = self.novel.desc

            if self.novel.authorName is not None:
                try:
                    xmlProject.find('AuthorName').text = self.novel.authorName
                except(AttributeError):
                    ET.SubElement(xmlProject, 'AuthorName').text = self.novel.authorName

            if self.novel.authorBio is not None:
                try:
                    xmlProject.find('Bio').text = self.novel.authorBio
                except(AttributeError):
                    ET.SubElement(xmlProject, 'Bio').text = self.novel.authorBio

            if self.novel.fieldTitle1 is not None:
                try:
                    xmlProject.find('FieldTitle1').text = self.novel.fieldTitle1
                except(AttributeError):
                    ET.SubElement(xmlProject, 'FieldTitle1').text = self.novel.fieldTitle1

            if self.novel.fieldTitle2 is not None:
                try:
                    xmlProject.find('FieldTitle2').text = self.novel.fieldTitle2
                except(AttributeError):
                    ET.SubElement(xmlProject, 'FieldTitle2').text = self.novel.fieldTitle2

            if self.novel.fieldTitle3 is not None:
                try:
                    xmlProject.find('FieldTitle3').text = self.novel.fieldTitle3
                except(AttributeError):
                    ET.SubElement(xmlProject, 'FieldTitle3').text = self.novel.fieldTitle3

            if self.novel.fieldTitle4 is not None:
                try:
                    xmlProject.find('FieldTitle4').text = self.novel.fieldTitle4
                except(AttributeError):
                    ET.SubElement(xmlProject, 'FieldTitle4').text = self.novel.fieldTitle4

            if self.novel.wordCountStart is not None:
                try:
                    xmlProject.find('WordCountStart').text = str(self.novel.wordCountStart)
                except(AttributeError):
                    ET.SubElement(xmlProject, 'WordCountStart').text = str(self.novel.wordCountStart)

            if self.novel.wordTarget is not None:
                try:
                    xmlProject.find('WordTarget').text = str(self.novel.wordTarget)
                except(AttributeError):
                    ET.SubElement(xmlProject, 'WordTarget').text = str(self.novel.wordTarget)


            self.novel.kwVar['Field_LanguageCode'] = None
            self.novel.kwVar['Field_CountryCode'] = None

            xmlProjectFields = xmlProject.find('Fields')
            for field in self.PRJ_KWVAR:
                setting = self.novel.kwVar.get(field, None)
                if setting:
                    if xmlProjectFields is None:
                        xmlProjectFields = ET.SubElement(xmlProject, 'Fields')
                    try:
                        xmlProjectFields.find(field).text = setting
                    except(AttributeError):
                        ET.SubElement(xmlProjectFields, field).text = setting
                else:
                    try:
                        xmlProjectFields.remove(xmlProjectFields.find(field))
                    except:
                        pass

        TAG = 'YWRITER7'
        xmlNewScenes = {}
        xmlNewChapters = {}
        try:
            root = self.tree.getroot()
            xmlProject = root.find('PROJECT')
            xmlLocations = root.find('LOCATIONS')
            xmlItems = root.find('ITEMS')
            xmlCharacters = root.find('CHARACTERS')
            xmlProjectnotes = root.find('PROJECTNOTES')
            xmlScenes = root.find('SCENES')
            xmlChapters = root.find('CHAPTERS')
        except(AttributeError):
            root = ET.Element(TAG)
            xmlProject = ET.SubElement(root, 'PROJECT')
            xmlLocations = ET.SubElement(root, 'LOCATIONS')
            xmlItems = ET.SubElement(root, 'ITEMS')
            xmlCharacters = ET.SubElement(root, 'CHARACTERS')
            xmlProjectnotes = ET.SubElement(root, 'PROJECTNOTES')
            xmlScenes = ET.SubElement(root, 'SCENES')
            xmlChapters = ET.SubElement(root, 'CHAPTERS')


        build_project_subtree(xmlProject)


        for xmlLoc in xmlLocations.findall('LOCATION'):
            xmlLocations.remove(xmlLoc)

        sortOrder = 0
        for lcId in self.novel.srtLocations:
            sortOrder += 1
            xmlLoc = ET.SubElement(xmlLocations, 'LOCATION')
            ET.SubElement(xmlLoc, 'ID').text = lcId
            build_location_subtree(xmlLoc, self.novel.locations[lcId], sortOrder)


        for xmlItm in xmlItems.findall('ITEM'):
            xmlItems.remove(xmlItm)

        sortOrder = 0
        for itId in self.novel.srtItems:
            sortOrder += 1
            xmlItm = ET.SubElement(xmlItems, 'ITEM')
            ET.SubElement(xmlItm, 'ID').text = itId
            build_item_subtree(xmlItm, self.novel.items[itId], sortOrder)


        for xmlCrt in xmlCharacters.findall('CHARACTER'):
            xmlCharacters.remove(xmlCrt)

        sortOrder = 0
        for crId in self.novel.srtCharacters:
            sortOrder += 1
            xmlCrt = ET.SubElement(xmlCharacters, 'CHARACTER')
            ET.SubElement(xmlCrt, 'ID').text = crId
            build_character_subtree(xmlCrt, self.novel.characters[crId], sortOrder)


        if xmlProjectnotes is not None:
            for xmlProjectnote in xmlProjectnotes.findall('PROJECTNOTE'):
                xmlProjectnotes.remove(xmlProjectnote)
            if not self.novel.srtPrjNotes:
                root.remove(xmlProjectnotes)
        elif self.novel.srtPrjNotes:
            xmlProjectnotes = ET.SubElement(root, 'PROJECTNOTES')
        if self.novel.srtPrjNotes:
            sortOrder = 0
            for pnId in self.novel.srtPrjNotes:
                sortOrder += 1
                xmlProjectnote = ET.SubElement(xmlProjectnotes, 'PROJECTNOTE')
                ET.SubElement(xmlProjectnote, 'ID').text = pnId
                build_prjNote_subtree(xmlProjectnote, self.novel.projectNotes[pnId], sortOrder)

        xmlProjectvars = root.find('PROJECTVARS')
        if self.novel.languages or self.novel.languageCode or self.novel.countryCode:
            self.novel.check_locale()
            if xmlProjectvars is None:
                xmlProjectvars = ET.SubElement(root, 'PROJECTVARS')
            prjVars = []
            languages = self.novel.languages.copy()
            hasLanguageCode = False
            hasCountryCode = False
            for xmlProjectvar in xmlProjectvars.findall('PROJECTVAR'):
                prjVars.append(xmlProjectvar.find('ID').text)
                title = xmlProjectvar.find('Title').text

                if title.startswith('lang='):
                    try:
                        __, langCode = title.split('=')
                        languages.remove(langCode)
                    except:
                        pass

                elif title == 'Language':
                    xmlProjectvar.find('Desc').text = self.novel.languageCode
                    hasLanguageCode = True

                elif title == 'Country':
                    xmlProjectvar.find('Desc').text = self.novel.countryCode
                    hasCountryCode = True

            if not hasLanguageCode:
                add_projectvariable('Language',
                                    self.novel.languageCode,
                                    '0')

            if not hasCountryCode:
                add_projectvariable('Country',
                                    self.novel.countryCode,
                                    '0')

            for langCode in languages:
                add_projectvariable(f'lang={langCode}',
                                    f'<HTM <SPAN LANG="{langCode}"> /HTM>',
                                    '0')
                add_projectvariable(f'/lang={langCode}',
                                    f'<HTM </SPAN> /HTM>',
                                    '0')


        for xmlScene in xmlScenes.findall('SCENE'):
            scId = xmlScene.find('ID').text
            xmlNewScenes[scId] = xmlScene
            xmlScenes.remove(xmlScene)

        for scId in self.novel.scenes:
            if not scId in xmlNewScenes:
                xmlNewScenes[scId] = ET.Element('SCENE')
                ET.SubElement(xmlNewScenes[scId], 'ID').text = scId
            build_scene_subtree(xmlNewScenes[scId], self.novel.scenes[scId])
            xmlScenes.append(xmlNewScenes[scId])


        for xmlChapter in xmlChapters.findall('CHAPTER'):
            chId = xmlChapter.find('ID').text
            xmlNewChapters[chId] = xmlChapter
            xmlChapters.remove(xmlChapter)

        sortOrder = 0
        for chId in self.novel.srtChapters:
            sortOrder += 1
            if not chId in xmlNewChapters:
                xmlNewChapters[chId] = ET.Element('CHAPTER')
                ET.SubElement(xmlNewChapters[chId], 'ID').text = chId
            build_chapter_subtree(xmlNewChapters[chId], self.novel.chapters[chId], sortOrder)
            xmlChapters.append(xmlNewChapters[chId])

        for xmlScene in root.find('SCENES'):
            scId = xmlScene.find('ID').text
            if self.novel.scenes[scId].sceneContent is not None:
                xmlScene.find('SceneContent').text = self.novel.scenes[scId].sceneContent
                xmlScene.find('WordCount').text = str(self.novel.scenes[scId].wordCount)
                xmlScene.find('LetterCount').text = str(self.novel.scenes[scId].letterCount)
            try:
                xmlScene.remove(xmlScene.find('RTFFile'))
            except:
                pass

        indent(root)
        self.tree = ET.ElementTree(root)

    def _postprocess_xml_file(self, filePath):
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
        lines = text.split('\n')
        newlines = ['<?xml version="1.0" encoding="utf-8"?>']
        for line in lines:
            for tag in self._CDATA_TAGS:
                line = re.sub(f'\<{tag}\>', f'<{tag}><![CDATA[', line)
                line = re.sub(f'\<\/{tag}\>', f']]></{tag}>', line)
            newlines.append(line)
        text = '\n'.join(newlines)
        text = text.replace('[CDATA[ \n', '[CDATA[')
        text = text.replace('\n]]', ']]')
        if not self.novel.chapters:
            text = text.replace('<CHAPTERS />', '<CHAPTERS></CHAPTERS>')
        text = unescape(text)
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

    def _read_project(self, root):
        xmlProject = root.find('PROJECT')

        if xmlProject.find('Title') is not None:
            self.novel.title = xmlProject.find('Title').text

        if xmlProject.find('AuthorName') is not None:
            self.novel.authorName = xmlProject.find('AuthorName').text

        if xmlProject.find('Bio') is not None:
            self.novel.authorBio = xmlProject.find('Bio').text

        if xmlProject.find('Desc') is not None:
            self.novel.desc = xmlProject.find('Desc').text

        if xmlProject.find('FieldTitle1') is not None:
            self.novel.fieldTitle1 = xmlProject.find('FieldTitle1').text

        if xmlProject.find('FieldTitle2') is not None:
            self.novel.fieldTitle2 = xmlProject.find('FieldTitle2').text

        if xmlProject.find('FieldTitle3') is not None:
            self.novel.fieldTitle3 = xmlProject.find('FieldTitle3').text

        if xmlProject.find('FieldTitle4') is not None:
            self.novel.fieldTitle4 = xmlProject.find('FieldTitle4').text

        if xmlProject.find('WordCountStart') is not None:
            try:
                self.novel.wordCountStart = int(xmlProject.find('WordCountStart').text)
            except:
                self.novel.wordCountStart = 0
        if xmlProject.find('WordTarget') is not None:
            try:
                self.novel.wordTarget = int(xmlProject.find('WordTarget').text)
            except:
                self.novel.wordTarget = 0

        for fieldName in self.PRJ_KWVAR:
            self.novel.kwVar[fieldName] = None

        for xmlProjectFields in xmlProject.findall('Fields'):
            for fieldName in self.PRJ_KWVAR:
                field = xmlProjectFields.find(fieldName)
                if field is not None:
                    self.novel.kwVar[fieldName] = field.text

        if self.novel.kwVar['Field_LanguageCode']:
            self.novel.languageCode = self.novel.kwVar['Field_LanguageCode']
        if self.novel.kwVar['Field_CountryCode']:
            self.novel.countryCode = self.novel.kwVar['Field_CountryCode']

    def _read_locations(self, root):
        self.novel.srtLocations = []
        for xmlLocation in root.find('LOCATIONS'):
            lcId = xmlLocation.find('ID').text
            self.novel.srtLocations.append(lcId)
            self.novel.locations[lcId] = WorldElement()

            if xmlLocation.find('Title') is not None:
                self.novel.locations[lcId].title = xmlLocation.find('Title').text

            if xmlLocation.find('ImageFile') is not None:
                self.novel.locations[lcId].image = xmlLocation.find('ImageFile').text

            if xmlLocation.find('Desc') is not None:
                self.novel.locations[lcId].desc = xmlLocation.find('Desc').text

            if xmlLocation.find('AKA') is not None:
                self.novel.locations[lcId].aka = xmlLocation.find('AKA').text

            if xmlLocation.find('Tags') is not None:
                if xmlLocation.find('Tags').text is not None:
                    tags = string_to_list(xmlLocation.find('Tags').text)
                    self.novel.locations[lcId].tags = self._strip_spaces(tags)

            for fieldName in self.LOC_KWVAR:
                self.novel.locations[lcId].kwVar[fieldName] = None

            for xmlLocationFields in xmlLocation.findall('Fields'):
                for fieldName in self.LOC_KWVAR:
                    field = xmlLocationFields.find(fieldName)
                    if field is not None:
                        self.novel.locations[lcId].kwVar[fieldName] = field.text

    def _read_items(self, root):
        self.novel.srtItems = []
        for xmlItem in root.find('ITEMS'):
            itId = xmlItem.find('ID').text
            self.novel.srtItems.append(itId)
            self.novel.items[itId] = WorldElement()

            if xmlItem.find('Title') is not None:
                self.novel.items[itId].title = xmlItem.find('Title').text

            if xmlItem.find('ImageFile') is not None:
                self.novel.items[itId].image = xmlItem.find('ImageFile').text

            if xmlItem.find('Desc') is not None:
                self.novel.items[itId].desc = xmlItem.find('Desc').text

            if xmlItem.find('AKA') is not None:
                self.novel.items[itId].aka = xmlItem.find('AKA').text

            if xmlItem.find('Tags') is not None:
                if xmlItem.find('Tags').text is not None:
                    tags = string_to_list(xmlItem.find('Tags').text)
                    self.novel.items[itId].tags = self._strip_spaces(tags)

            for fieldName in self.ITM_KWVAR:
                self.novel.items[itId].kwVar[fieldName] = None

            for xmlItemFields in xmlItem.findall('Fields'):
                for fieldName in self.ITM_KWVAR:
                    field = xmlItemFields.find(fieldName)
                    if field is not None:
                        self.novel.items[itId].kwVar[fieldName] = field.text

    def _read_characters(self, root):
        self.novel.srtCharacters = []
        for xmlCharacter in root.find('CHARACTERS'):
            crId = xmlCharacter.find('ID').text
            self.novel.srtCharacters.append(crId)
            self.novel.characters[crId] = Character()

            if xmlCharacter.find('Title') is not None:
                self.novel.characters[crId].title = xmlCharacter.find('Title').text

            if xmlCharacter.find('ImageFile') is not None:
                self.novel.characters[crId].image = xmlCharacter.find('ImageFile').text

            if xmlCharacter.find('Desc') is not None:
                self.novel.characters[crId].desc = xmlCharacter.find('Desc').text

            if xmlCharacter.find('AKA') is not None:
                self.novel.characters[crId].aka = xmlCharacter.find('AKA').text

            if xmlCharacter.find('Tags') is not None:
                if xmlCharacter.find('Tags').text is not None:
                    tags = string_to_list(xmlCharacter.find('Tags').text)
                    self.novel.characters[crId].tags = self._strip_spaces(tags)

            if xmlCharacter.find('Notes') is not None:
                self.novel.characters[crId].notes = xmlCharacter.find('Notes').text

            if xmlCharacter.find('Bio') is not None:
                self.novel.characters[crId].bio = xmlCharacter.find('Bio').text

            if xmlCharacter.find('Goals') is not None:
                self.novel.characters[crId].goals = xmlCharacter.find('Goals').text

            if xmlCharacter.find('FullName') is not None:
                self.novel.characters[crId].fullName = xmlCharacter.find('FullName').text

            if xmlCharacter.find('Major') is not None:
                self.novel.characters[crId].isMajor = True
            else:
                self.novel.characters[crId].isMajor = False

            for fieldName in self.CRT_KWVAR:
                self.novel.characters[crId].kwVar[fieldName] = None

            for xmlCharacterFields in xmlCharacter.findall('Fields'):
                for fieldName in self.CRT_KWVAR:
                    field = xmlCharacterFields.find(fieldName)
                    if field is not None:
                        self.novel.characters[crId].kwVar[fieldName] = field.text

    def _read_projectnotes(self, root):
        self.novel.srtPrjNotes = []

        try:
            for xmlProjectnote in root.find('PROJECTNOTES'):
                if xmlProjectnote.find('ID') is not None:
                    pnId = xmlProjectnote.find('ID').text
                    self.novel.srtPrjNotes.append(pnId)
                    self.novel.projectNotes[pnId] = BasicElement()
                    if xmlProjectnote.find('Title') is not None:
                        self.novel.projectNotes[pnId].title = xmlProjectnote.find('Title').text
                    if xmlProjectnote.find('Desc') is not None:
                        self.novel.projectNotes[pnId].desc = xmlProjectnote.find('Desc').text

                for fieldName in self.PNT_KWVAR:
                    self.novel.projectNotes[pnId].kwVar[fieldName] = None

                for pnFields in xmlProjectnote.findall('Fields'):
                    field = pnFields.find(fieldName)
                    if field is not None:
                        self.novel.projectNotes[pnId].kwVar[fieldName] = field.text
        except:
            pass

    def _read_projectvars(self, root):
        try:
            for xmlProjectvar in root.find('PROJECTVARS'):
                if xmlProjectvar.find('Title') is not None:
                    title = xmlProjectvar.find('Title').text
                    if title == 'Language':
                        if xmlProjectvar.find('Desc') is not None:
                            self.novel.languageCode = xmlProjectvar.find('Desc').text

                    elif title == 'Country':
                        if xmlProjectvar.find('Desc') is not None:
                            self.novel.countryCode = xmlProjectvar.find('Desc').text

                    elif title.startswith('lang='):
                        try:
                            __, langCode = title.split('=')
                            if self.novel.languages is None:
                                self.novel.languages = []
                            self.novel.languages.append(langCode)
                        except:
                            pass
        except:
            pass

    def _read_scenes(self, root):
        for xmlScene in root.find('SCENES'):
            scId = xmlScene.find('ID').text
            self.novel.scenes[scId] = Scene()

            if xmlScene.find('Title') is not None:
                self.novel.scenes[scId].title = xmlScene.find('Title').text

            if xmlScene.find('Desc') is not None:
                self.novel.scenes[scId].desc = xmlScene.find('Desc').text

            if xmlScene.find('SceneContent') is not None:
                sceneContent = xmlScene.find('SceneContent').text
                if sceneContent is not None:
                    self.novel.scenes[scId].sceneContent = sceneContent



            self.novel.scenes[scId].scType = 0

            for fieldName in self.SCN_KWVAR:
                self.novel.scenes[scId].kwVar[fieldName] = None

            for xmlSceneFields in xmlScene.findall('Fields'):
                for fieldName in self.SCN_KWVAR:
                    field = xmlSceneFields.find(fieldName)
                    if field is not None:
                        self.novel.scenes[scId].kwVar[fieldName] = field.text

                if xmlSceneFields.find('Field_SceneType') is not None:
                    if xmlSceneFields.find('Field_SceneType').text == '1':
                        self.novel.scenes[scId].scType = 1
                    elif xmlSceneFields.find('Field_SceneType').text == '2':
                        self.novel.scenes[scId].scType = 2
            if xmlScene.find('Unused') is not None:
                if self.novel.scenes[scId].scType == 0:
                    self.novel.scenes[scId].scType = 3

            if xmlScene.find('ExportCondSpecific') is None:
                self.novel.scenes[scId].doNotExport = False
            elif xmlScene.find('ExportWhenRTF') is not None:
                self.novel.scenes[scId].doNotExport = False
            else:
                self.novel.scenes[scId].doNotExport = True

            if xmlScene.find('Status') is not None:
                self.novel.scenes[scId].status = int(xmlScene.find('Status').text)

            if xmlScene.find('Notes') is not None:
                self.novel.scenes[scId].notes = xmlScene.find('Notes').text

            if xmlScene.find('Tags') is not None:
                if xmlScene.find('Tags').text is not None:
                    tags = string_to_list(xmlScene.find('Tags').text)
                    self.novel.scenes[scId].tags = self._strip_spaces(tags)

            if xmlScene.find('Field1') is not None:
                self.novel.scenes[scId].field1 = xmlScene.find('Field1').text

            if xmlScene.find('Field2') is not None:
                self.novel.scenes[scId].field2 = xmlScene.find('Field2').text

            if xmlScene.find('Field3') is not None:
                self.novel.scenes[scId].field3 = xmlScene.find('Field3').text

            if xmlScene.find('Field4') is not None:
                self.novel.scenes[scId].field4 = xmlScene.find('Field4').text

            if xmlScene.find('AppendToPrev') is not None:
                self.novel.scenes[scId].appendToPrev = True
            else:
                self.novel.scenes[scId].appendToPrev = False

            if xmlScene.find('SpecificDateTime') is not None:
                dateTimeStr = xmlScene.find('SpecificDateTime').text

                try:
                    dateTime = datetime.fromisoformat(dateTimeStr)
                except:
                    self.novel.scenes[scId].date = ''
                    self.novel.scenes[scId].time = ''
                else:
                    startDateTime = dateTime.isoformat().split('T')
                    self.novel.scenes[scId].date = startDateTime[0]
                    self.novel.scenes[scId].time = startDateTime[1]
            else:
                if xmlScene.find('Day') is not None:
                    day = xmlScene.find('Day').text

                    try:
                        int(day)
                    except ValueError:
                        day = ''
                    self.novel.scenes[scId].day = day

                hasUnspecificTime = False
                if xmlScene.find('Hour') is not None:
                    hour = xmlScene.find('Hour').text.zfill(2)
                    hasUnspecificTime = True
                else:
                    hour = '00'
                if xmlScene.find('Minute') is not None:
                    minute = xmlScene.find('Minute').text.zfill(2)
                    hasUnspecificTime = True
                else:
                    minute = '00'
                if hasUnspecificTime:
                    self.novel.scenes[scId].time = f'{hour}:{minute}:00'

            if xmlScene.find('LastsDays') is not None:
                self.novel.scenes[scId].lastsDays = xmlScene.find('LastsDays').text

            if xmlScene.find('LastsHours') is not None:
                self.novel.scenes[scId].lastsHours = xmlScene.find('LastsHours').text

            if xmlScene.find('LastsMinutes') is not None:
                self.novel.scenes[scId].lastsMinutes = xmlScene.find('LastsMinutes').text

            if xmlScene.find('ReactionScene') is not None:
                self.novel.scenes[scId].isReactionScene = True
            else:
                self.novel.scenes[scId].isReactionScene = False

            if xmlScene.find('SubPlot') is not None:
                self.novel.scenes[scId].isSubPlot = True
            else:
                self.novel.scenes[scId].isSubPlot = False

            if xmlScene.find('Goal') is not None:
                self.novel.scenes[scId].goal = xmlScene.find('Goal').text

            if xmlScene.find('Conflict') is not None:
                self.novel.scenes[scId].conflict = xmlScene.find('Conflict').text

            if xmlScene.find('Outcome') is not None:
                self.novel.scenes[scId].outcome = xmlScene.find('Outcome').text

            if xmlScene.find('ImageFile') is not None:
                self.novel.scenes[scId].image = xmlScene.find('ImageFile').text

            if xmlScene.find('Characters') is not None:
                for characters in xmlScene.find('Characters').iter('CharID'):
                    crId = characters.text
                    if crId in self.novel.srtCharacters:
                        if self.novel.scenes[scId].characters is None:
                            self.novel.scenes[scId].characters = []
                        self.novel.scenes[scId].characters.append(crId)

            if xmlScene.find('Locations') is not None:
                for locations in xmlScene.find('Locations').iter('LocID'):
                    lcId = locations.text
                    if lcId in self.novel.srtLocations:
                        if self.novel.scenes[scId].locations is None:
                            self.novel.scenes[scId].locations = []
                        self.novel.scenes[scId].locations.append(lcId)

            if xmlScene.find('Items') is not None:
                for items in xmlScene.find('Items').iter('ItemID'):
                    itId = items.text
                    if itId in self.novel.srtItems:
                        if self.novel.scenes[scId].items is None:
                            self.novel.scenes[scId].items = []
                        self.novel.scenes[scId].items.append(itId)

    def _read_chapters(self, root):
        self.novel.srtChapters = []
        for xmlChapter in root.find('CHAPTERS'):
            chId = xmlChapter.find('ID').text
            self.novel.chapters[chId] = Chapter()
            self.novel.srtChapters.append(chId)

            if xmlChapter.find('Title') is not None:
                self.novel.chapters[chId].title = xmlChapter.find('Title').text

            if xmlChapter.find('Desc') is not None:
                self.novel.chapters[chId].desc = xmlChapter.find('Desc').text

            if xmlChapter.find('SectionStart') is not None:
                self.novel.chapters[chId].chLevel = 1
            else:
                self.novel.chapters[chId].chLevel = 0


            self.novel.chapters[chId].chType = 0
            if xmlChapter.find('Unused') is not None:
                yUnused = True
            else:
                yUnused = False
            if xmlChapter.find('ChapterType') is not None:
                yChapterType = xmlChapter.find('ChapterType').text
                if yChapterType == '2':
                    self.novel.chapters[chId].chType = 2
                elif yChapterType == '1':
                    self.novel.chapters[chId].chType = 1
                elif yUnused:
                    self.novel.chapters[chId].chType = 3
            else:
                if xmlChapter.find('Type') is not None:
                    yType = xmlChapter.find('Type').text
                    if yType == '1':
                        self.novel.chapters[chId].chType = 1
                    elif yUnused:
                        self.novel.chapters[chId].chType = 3

            self.novel.chapters[chId].suppressChapterTitle = False
            if self.novel.chapters[chId].title is not None:
                if self.novel.chapters[chId].title.startswith('@'):
                    self.novel.chapters[chId].suppressChapterTitle = True

            for fieldName in self.CHP_KWVAR:
                self.novel.chapters[chId].kwVar[fieldName] = None

            for xmlChapterFields in xmlChapter.findall('Fields'):
                if xmlChapterFields.find('Field_SuppressChapterTitle') is not None:
                    if xmlChapterFields.find('Field_SuppressChapterTitle').text == '1':
                        self.novel.chapters[chId].suppressChapterTitle = True
                self.novel.chapters[chId].isTrash = False
                if xmlChapterFields.find('Field_IsTrash') is not None:
                    if xmlChapterFields.find('Field_IsTrash').text == '1':
                        self.novel.chapters[chId].isTrash = True
                self.novel.chapters[chId].suppressChapterBreak = False
                if xmlChapterFields.find('Field_SuppressChapterBreak') is not None:
                    if xmlChapterFields.find('Field_SuppressChapterBreak').text == '1':
                        self.novel.chapters[chId].suppressChapterBreak = True

                for fieldName in self.CHP_KWVAR:
                    field = xmlChapterFields.find(fieldName)
                    if field is not None:
                        self.novel.chapters[chId].kwVar[fieldName] = field.text

            self.novel.chapters[chId].srtScenes = []
            if xmlChapter.find('Scenes') is not None:
                for scn in xmlChapter.find('Scenes').findall('ScID'):
                    scId = scn.text
                    if scId in self.novel.scenes:
                        self.novel.chapters[chId].srtScenes.append(scId)

    def _strip_spaces(self, lines):
        stripped = []
        for line in lines:
            stripped.append(line.strip())
        return stripped

    def _write_element_tree(self, ywProject):
        backedUp = False
        if os.path.isfile(ywProject.filePath):
            try:
                os.replace(ywProject.filePath, f'{ywProject.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(ywProject.filePath)}".')
            else:
                backedUp = True
        try:
            ywProject.tree.write(ywProject.filePath, xml_declaration=False, encoding='utf-8')
        except:
            if backedUp:
                os.replace(f'{ywProject.filePath}.bak', ywProject.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(ywProject.filePath)}".')



class MainTk(Ui):
    _KEY_RESTORE_STATUS = ('<Escape>', 'Esc')
    _KEY_OPEN_PROJECT = ('<Control-o>', 'Ctrl-O')
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')
    _YW_CLASS = Yw7File

    def __init__(self, title, **kwargs):
        super().__init__(title)
        self._fileTypes = [(_('yWriter 7 project'), '.yw7')]
        self.title = title
        self._statusText = ''
        self.kwargs = kwargs
        self.prjFile = None
        self.novel = None
        self.root = tk.Tk()
        self.root.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.root.title(title)
        if kwargs.get('root_geometry', None):
            self.root.geometry(kwargs['root_geometry'])
        self.mainMenu = tk.Menu(self.root)

        self._build_main_menu()

        self.root.config(menu=self.mainMenu)
        self.mainWindow = tk.Frame()
        self.mainWindow.pack(expand=True, fill='both')
        self.statusBar = tk.Label(self.root, text='', anchor='w', padx=5, pady=2)
        self.statusBar.pack(expand=False, fill='both')
        self.statusBar.bind('<Button-1>', self.restore_status)
        self.pathBar = tk.Label(self.root, text='', anchor='w', padx=5, pady=3)
        self.pathBar.pack(expand=False, fill='both')

        self.root.bind(self._KEY_RESTORE_STATUS[0], self.restore_status)
        self.root.bind(self._KEY_OPEN_PROJECT[0], self._open_project)
        self.root.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

    def ask_yes_no(self, text, title=None):
        if title is None:
            title = self.title
        return messagebox.askyesno(title, text)

    def close_project(self, event=None):
        self.prjFile = None
        self.root.title(self.title)
        self.show_status('')
        self.show_path('')
        self.disable_menu()

    def disable_menu(self):
        self.fileMenu.entryconfig(_('Close'), state='disabled')

    def enable_menu(self):
        self.fileMenu.entryconfig(_('Close'), state='normal')

    def on_quit(self, event=None):
        self.kwargs['root_geometry'] = self.root.winfo_geometry()
        self.root.quit()

    def open_project(self, fileName):
        self.restore_status()
        fileName = self.select_project(fileName)
        if not fileName:
            return False

        if self.prjFile is not None:
            self.close_project()
        self.kwargs['yw_last_open'] = fileName
        self.prjFile = self._YW_CLASS(fileName)
        self.novel = Novel()
        self.prjFile.novel = self.novel
        try:
            self.prjFile.read()
        except Error as ex:
            self.close_project()
            self.set_info_how(f'!{str(ex)}')
            return False

        self.show_path(f'{norm_path(self.prjFile.filePath)}')
        self.set_title()
        self.enable_menu()
        return True

    def restore_status(self, event=None):
        self.show_status(self._statusText)

    def select_project(self, fileName):
        initDir = os.path.dirname(self.kwargs.get('yw_last_open', ''))
        if not initDir:
            initDir = './'
        if not fileName or not os.path.isfile(fileName):
            fileName = filedialog.askopenfilename(filetypes=self._fileTypes, defaultextension='.yw7', initialdir=initDir)
        if not fileName:
            return ''

        return fileName

    def set_info_how(self, message):
        if message.startswith('!'):
            self.statusBar.config(bg='red')
            self.statusBar.config(fg='white')
            self.infoHowText = message.split('!', maxsplit=1)[1].strip()
        else:
            self.statusBar.config(bg='green')
            self.statusBar.config(fg='white')
            self.infoHowText = message
        self.statusBar.config(text=self.infoHowText)

    def set_title(self):
        if self.novel.title:
            titleView = self.novel.title
        else:
            titleView = _('Untitled project')
        if self.novel.authorName:
            authorView = self.novel.authorName
        else:
            authorView = _('Unknown author')
        self.root.title(f'{titleView} {_("by")} {authorView} - {self.title}')

    def show_error(self, message, title=None):
        if title is None:
            title = self.title
        messagebox.showerror(title, message)

    def show_info(self, message, title=None):
        if title is None:
            title = self.title
        messagebox.showinfo(title, message)

    def show_path(self, message):
        self._pathText = message
        self.pathBar.config(text=message)

    def show_status(self, message):
        self._statusText = message
        self.statusBar.config(bg=self.root.cget('background'))
        self.statusBar.config(fg='black')
        self.statusBar.config(text=message)

    def show_warning(self, message, title=None):
        if title is None:
            title = self.title
        messagebox.showwarning(title, message)

    def start(self):
        self.root.mainloop()

    def _build_main_menu(self):
        self.fileMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('File'), menu=self.fileMenu)
        self.fileMenu.add_command(label=_('Open...'), accelerator=self._KEY_OPEN_PROJECT[1], command=lambda: self.open_project(''))
        self.fileMenu.add_command(label=_('Close'), command=self.close_project)
        self.fileMenu.entryconfig(_('Close'), state='disabled')
        self.fileMenu.add_command(label=_('Exit'), accelerator=self._KEY_QUIT_PROGRAM[1], command=self.on_quit)

    def _open_project(self, event=None):
        self.open_project('')



def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from datetime import datetime
from datetime import date


class WorkFile(Yw7File):
    DESCRIPTION = _('novelyst project')
    _LOCKFILE_PREFIX = '.LOCK.'
    _LOCKFILE_SUFFIX = '#'

    PRJ_KWVAR = [
        'Field_WorkPhase',
        'Field_RenumberChapters',
        'Field_RenumberParts',
        'Field_RenumberWithinParts',
        'Field_RomanChapterNumbers',
        'Field_RomanPartNumbers',
        'Field_ChapterHeadingPrefix',
        'Field_ChapterHeadingSuffix',
        'Field_PartHeadingPrefix',
        'Field_PartHeadingSuffix',
        'Field_CustomGoal',
        'Field_CustomConflict',
        'Field_CustomOutcome',
        'Field_CustomChrBio',
        'Field_CustomChrGoals',
        'Field_SaveWordCount',
        'Field_LanguageCode',
        'Field_CountryCode',
        ]
    CHP_KWVAR = [
        'Field_NoNumber',
        'Field_ArcDefinition',
        ]
    SCN_KWVAR = [
        'Field_SceneArcs',
        'Field_SceneAssoc',
        'Field_CustomAR',
        'Field_SceneStyle',  # TODO: Change the wording and use "Mode" instead of "Style".
        ]

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self.timestamp = None
        self.wcLog = {}
        self.wcLogUpdate = {}

    @property
    def fileDate(self):
        if self.timestamp is not None:
            return datetime.fromtimestamp(self.timestamp).replace(microsecond=0).isoformat(sep=' ')
        else:
            return 'Never'

    def adjust_scene_types(self):
        isModified = False
        partType = 0
        for chId in self.novel.srtChapters:
            if self.novel.chapters[chId].chLevel == 1:
                partType = self.novel.chapters[chId].chType
            elif partType != 0 and not self.novel.chapters[chId].isTrash:
                if self.novel.chapters[chId].chType != partType:
                    self.novel.chapters[chId].chType = partType
                    isModified = True
            if self.novel.chapters[chId].chType != 0:
                for scId in self.novel.chapters[chId].srtScenes:
                    if self.novel.scenes[scId].scType != self.novel.chapters[chId].chType:
                        self.novel.scenes[scId].scType = self.novel.chapters[chId].chType
                        isModified = True
        return isModified

    def check_arcs(self, addChapters=False):
        arcs = []
        scnPoints = {}
        for scId in self.novel.scenes:
            scnPoints[scId] = []

        for chId in self.novel.srtChapters:
            if self.novel.chapters[chId].chType == 2 and self.novel.chapters[chId].chLevel == 0:

                arc = self.novel.chapters[chId].kwVar.get('Field_ArcDefinition', None)
                if arc:
                    if arc in arcs:
                        self.novel.chapters[chId].kwVar['Field_ArcDefinition'] = None
                        arc = None
                    else:
                        arcs.append(arc)

                    for ptId in self.novel.chapters[chId].srtScenes:
                        self.novel.scenes[ptId].scnArcs = arc

                        scenes = string_to_list(self.novel.scenes[ptId].kwVar.get('Field_SceneAssoc', None))
                        self.novel.scenes[ptId].kwVar['Field_SceneAssoc'] = None
                        if scenes and arc:

                            scId = scenes[0]

                            if scId in self.novel.scenes:
                                if self.novel.scenes[scId].scType == 0:

                                    if arc in string_to_list(self.novel.scenes[scId].scnArcs):
                                        self.novel.scenes[ptId].kwVar['Field_SceneAssoc'] = scId

                                        scnPoints[scId].append(ptId)

                                        self.novel.scenes[ptId].date = self.novel.scenes[scId].date
                                        self.novel.scenes[ptId].time = self.novel.scenes[scId].time
                                        self.novel.scenes[ptId].day = self.novel.scenes[scId].day
            else:
                for scId in self.novel.chapters[chId].srtScenes:
                    if self.novel.scenes[scId].scType != 0:
                        self.novel.scenes[scId].kwVar['Field_SceneAssoc'] = None
                        self.novel.scenes[scId].scnArcs = None

        for scId in self.novel.scenes:
            if self.novel.scenes[scId].scType == 0:
                if scnPoints[scId]:
                    self.novel.scenes[scId].kwVar['Field_SceneAssoc'] = list_to_string(scnPoints[scId])
                else:
                    self.novel.scenes[scId].kwVar['Field_SceneAssoc'] = None

        newChapters = []
        partCreated = False
        for scId in self.novel.scenes:
            scnArcs = string_to_list(self.novel.scenes[scId].scnArcs)
            for scnArc in scnArcs:
                if not scnArc in arcs:
                    if addChapters:
                        if not partCreated:
                            chId = create_id(self.novel.chapters)
                            self.novel.chapters[chId] = Chapter()
                            self.novel.chapters[chId].title = _('Arcs')
                            self.novel.chapters[chId].chLevel = 1
                            self.novel.chapters[chId].chType = 2
                            self.novel.srtChapters.append(chId)
                            partCreated = True

                        chId = create_id(self.novel.chapters)
                        self.novel.chapters[chId] = Chapter()
                        self.novel.chapters[chId].title = f'{scnArc} - {_("Narrative arc")}'
                        self.novel.chapters[chId].chLevel = 0
                        self.novel.chapters[chId].chType = 2
                        for fieldName in self.CHP_KWVAR:
                            self.novel.chapters[chId].kwVar[fieldName] = None
                        self.novel.chapters[chId].kwVar['Field_ArcDefinition'] = scnArc
                        self.novel.srtChapters.append(chId)
                        arcs.append(scnArc)
                        newChapters.append(chId)
                    else:
                        scnArcs.remove(scnArc)
                        self.novel.scenes[scId].scnArcs = list_to_string(scnArcs)
        return newChapters

    def count_words(self):
        count = 0
        totalCount = 0
        for chId in self.novel.srtChapters:
            if not self.novel.chapters[chId].isTrash:
                for scId in self.novel.chapters[chId].srtScenes:
                    if self.novel.scenes[scId].scType in (0, 3) and not self.novel.scenes[scId].doNotExport:
                        totalCount += self.novel.scenes[scId].wordCount
                        if self.novel.scenes[scId].scType == 0:
                            count += self.novel.scenes[scId].wordCount
        return count, totalCount

    def get_counts(self):
        partCount = 0
        chapterCount = 0
        sceneCount = 0
        wordCount = 0
        for chId in self.novel.srtChapters:
            if self.novel.chapters[chId].chType == 0:
                for scId in self.novel.chapters[chId].srtScenes:
                    if self.novel.scenes[scId].scType == 0 and not self.novel.scenes[scId].doNotExport:
                        sceneCount += 1
                        wordCount += self.novel.scenes[scId].wordCount
                if self.novel.chapters[chId].chLevel == 1:
                    partCount += 1
                else:
                    chapterCount += 1
        return wordCount, sceneCount, chapterCount, partCount

    def get_status_counts(self):
        counts = [None, 0, 0, 0, 0, 0]
        for scId in self.novel.scenes:
            if self.novel.scenes[scId].scType == 0 and not self.novel.scenes[scId].doNotExport:
                if self.novel.scenes[scId].status is not None:
                    counts[self.novel.scenes[scId].status] += self.novel.scenes[scId].wordCount
        return counts

    def has_changed_on_disk(self):
        try:
            if self.timestamp != os.path.getmtime(self.filePath):
                return True
            else:
                return False

        except:
            return False

    def has_lockfile(self):
        head, tail = self._split_file_path()
        lockfilePath = f'{head}{self._LOCKFILE_PREFIX}{tail}{self._LOCKFILE_SUFFIX}'
        return os.path.isfile(lockfilePath)

    def lock(self):
        head, tail = self._split_file_path()
        lockfilePath = f'{head}{self._LOCKFILE_PREFIX}{tail}{self._LOCKFILE_SUFFIX}'
        if not os.path.isfile(lockfilePath):
            with open(lockfilePath, 'w') as f:
                f.write('')

    def read(self):
        super().read()

        try:
            self.timestamp = os.path.getmtime(self.filePath)
        except:
            self.timestamp = None

        root = self.tree.getroot()
        xmlWclog = root.find('WCLog')
        if xmlWclog is not None:
            for xmlWc in xmlWclog.findall('WC'):
                wcDate = xmlWc.find('Date').text
                wcCount = xmlWc.find('Count').text
                wcTotalCount = xmlWc.find('TotalCount').text
                self.wcLog[wcDate] = [wcCount, wcTotalCount]

        if self.wcLog:
            actualCountInt, actualTotalCountInt = self.count_words()
            actualCount = str(actualCountInt)
            actualTotalCount = str(actualTotalCountInt)
            latestDate = list(self.wcLog)[-1]
            latestCount = self.wcLog[latestDate][0]
            latestTotalCount = self.wcLog[latestDate][1]
            if actualCount != latestCount or actualTotalCount != latestTotalCount:
                try:
                    fileDate = date.fromtimestamp(self.timestamp).isoformat()
                except:
                    fileDate = date.today().isoformat()
                self.wcLogUpdate[fileDate] = [actualCount, actualTotalCount]

        for chId in self.novel.chapters:
            oldField = self.novel.chapters[chId].kwVar.get('Field_Arc_Definition', None)
            if oldField:
                self.novel.chapters[chId].kwVar['Field_ArcDefinition'] = oldField
                self.novel.chapters[chId].kwVar['Field_Arc_Definition'] = None

        self.check_arcs(addChapters=True)

        srtCharacters = []
        for crId in self.novel.srtCharacters:
            if not crId in srtCharacters:
                srtCharacters.append(crId)
        self.novel.srtCharacters = srtCharacters
        srtLocations = []
        for lcId in self.novel.srtLocations:
            if not lcId in srtLocations:
                srtLocations.append(lcId)
        self.novel.srtLocations = srtLocations
        srtItems = []
        for itId in self.novel.srtItems:
            if not itId in srtItems:
                srtItems.append(itId)
        self.novel.srtItems = srtItems

        for scId in self.novel.scenes:
            if self.novel.scenes[scId].characters is None:
                self.novel.scenes[scId].characters = []
            if self.novel.scenes[scId].locations is None:
                self.novel.scenes[scId].locations = []
            if self.novel.scenes[scId].items is None:
                self.novel.scenes[scId].items = []
            if self.novel.scenes[scId].status is None:
                self.novel.scenes[scId].status = 1

        self.novel.check_locale()

    def renumber_chapters(self):
        ROMAN = [
            (1000, 'M'),
            (900, 'CM'),
            (500, 'D'),
            (400, 'CD'),
            (100, 'C'),
            (90, 'XC'),
            (50, 'L'),
            (40, 'XL'),
            (10, 'X'),
            (9, 'IX'),
            (5, 'V'),
            (4, 'IV'),
            (1, 'I'),
        ]

        def number_to_roman(n):
            result = []
            for (arabic, roman) in ROMAN:
                (factor, n) = divmod(n, arabic)
                result.append(roman * factor)
                if n == 0:
                    break

            return "".join(result)

        isModified = False
        chapterCount = 0
        partCount = 0
        for chId in self.novel.srtChapters:
            if 'Field_NoNumber' in self.novel.chapters[chId].kwVar:
                if self.novel.chapters[chId].kwVar.get('Field_NoNumber', None):
                    continue

            if self.novel.chapters[chId].chType != 0:
                continue

            if self.novel.chapters[chId].chLevel == 0:
                if not self.novel.kwVar.get('Field_RenumberChapters', None):
                    continue

            else:
                if self.novel.kwVar.get('Field_RenumberWithinParts', None):
                    chapterCount = 0
                if not self.novel.kwVar.get('Field_RenumberParts', None):
                    continue

            headingPrefix = ''
            headingSuffix = ''
            if self.novel.chapters[chId].chLevel == 0:
                chapterCount += 1
                if self.novel.kwVar.get('Field_RomanChapterNumbers', None):
                    number = number_to_roman(chapterCount)
                else:
                    number = str(chapterCount)
                if self.novel.kwVar.get('Field_ChapterHeadingPrefix', None) is not None:
                    headingPrefix = self.novel.kwVar['Field_ChapterHeadingPrefix']
                if self.novel.kwVar.get('Field_ChapterHeadingSuffix', None) is not None:
                    headingSuffix = self.novel.kwVar['Field_ChapterHeadingSuffix']
            else:
                partCount += 1
                if self.novel.kwVar.get('Field_RomanPartNumbers', None):
                    number = number_to_roman(partCount)
                else:
                    number = str(partCount)
                if self.novel.kwVar.get('Field_PartHeadingPrefix', None) is not None:
                    headingPrefix = self.novel.kwVar['Field_PartHeadingPrefix']
                if self.novel.kwVar.get('Field_PartHeadingSuffix', None) is not None:
                    headingSuffix = self.novel.kwVar['Field_PartHeadingSuffix']
            newTitle = f'{headingPrefix}{number}{headingSuffix}'
            if self.novel.chapters[chId].title != newTitle:
                self.novel.chapters[chId].title = newTitle
                isModified = True

        return isModified

    def unlock(self):
        head, tail = self._split_file_path()
        lockfilePath = f'{head}{self._LOCKFILE_PREFIX}{tail}{self._LOCKFILE_SUFFIX}'
        try:
            os.remove(lockfilePath)
        except:
            pass

    def write(self):
        if self.novel.kwVar.get('Field_SaveWordCount', False):
            newCountInt, newTotalCountInt = self.count_words()
            newCount = str(newCountInt)
            newTotalCount = str(newTotalCountInt)
            today = date.today().isoformat()
            self.wcLogUpdate[today] = [newCount, newTotalCount]
            for wcDate in self.wcLogUpdate:
                self.wcLog[wcDate] = self.wcLogUpdate[wcDate]
        self.wcLogUpdate = {}

        super().write()
        self.timestamp = os.path.getmtime(self.filePath)

    def _build_element_tree(self):
        super()._build_element_tree()

        root = self.tree.getroot()
        xmlWcLog = root.find('WCLog')
        if xmlWcLog is not None:
            root.remove(xmlWcLog)
        if self.wcLog:
            xmlWcLog = ET.SubElement(root, 'WCLog')
            wcLastCount = None
            wcLastTotalCount = None
            for wc in self.wcLog:
                if self.novel.kwVar.get('Field_SaveWordCount', False):
                    if self.wcLog[wc][0] == wcLastCount and self.wcLog[wc][1] == wcLastTotalCount:
                        continue

                    wcLastCount = self.wcLog[wc][0]
                    wcLastTotalCount = self.wcLog[wc][1]
                xmlWc = ET.SubElement(xmlWcLog, 'WC')
                ET.SubElement(xmlWc, 'Date').text = wc
                ET.SubElement(xmlWc, 'Count').text = self.wcLog[wc][0]
                ET.SubElement(xmlWc, 'TotalCount').text = self.wcLog[wc][1]

        indent(root)
        self.tree = ET.ElementTree(root)

    def _split_file_path(self):
        head, tail = os.path.split(self.filePath)
        if head:
            head = f'{head}/'
        else:
            head = './'
        return head, tail

import glob
import importlib


class RejectedPlugin:
    VERSION = '-'
    NOVELYST_API = '-'
    URL = ''

    def __init__(self, filePath, message):
        self.filePath = filePath
        self.isActive = False
        self.isRejected = True
        self.DESCRIPTION = message



class PluginCollection(dict):

    def __init__(self, ui):
        super().__init__()
        self._ui = ui

        versionStr = '4.38.0'

        try:
            majorStr, minorStr, patchStr = versionStr.split('.')
            self.majorVersion = int(majorStr)
            self.minorVersion = int(minorStr)
            self.patchlevel = int(patchStr)
        except ValueError:
            self.majorVersion = 4
            self.minorVersion = 36
            self.patchlevel = 0

    def delete_file(self, moduleName):
        if moduleName in self:
            try:
                if self[moduleName].filePath:
                    if self._ui.ask_yes_no(f'{_("Delete file")} "{self[moduleName].filePath}"?'):
                        os.remove(self[moduleName].filePath)
                        self[moduleName].filePath = ''
                        return True

            except Exception as ex:
                print(str(ex))
        return False

    def load_file(self, filePath):
        try:
            moduleName = os.path.split(filePath)[1][:-3]

            module = importlib.import_module(moduleName)

            pluginObject = module.Plugin()
            apiVerStr = pluginObject.NOVELYST_API
            majorStr, minorStr = apiVerStr.split('.')
            apiMajorVersion = int(majorStr)
            apiMinorVersion = int(minorStr)
            isCompatible = True
            if apiMajorVersion != self.majorVersion:
                isCompatible = False
            if apiMinorVersion > self.minorVersion:
                isCompatible = False
            if isCompatible:
                pluginObject.install(self._ui)

            pluginObject.isActive = isCompatible
            pluginObject.isRejected = False

            self[moduleName] = pluginObject

            module.Plugin.filePath = filePath
            return True

        except Exception as ex:
            self[moduleName] = RejectedPlugin(filePath, str(ex))
            return False

    def load_plugins(self, pluginPath):
        if not os.path.isdir(pluginPath):
            print('Plugin directory not found.')
            return False

        self._ui.tv.tree.bind('<Double-1>', self.open_node)
        self._ui.tv.tree.bind('<Return>', self.open_node)

        sys.path.append(pluginPath)
        for file in glob.iglob(f'{pluginPath}/novelyst_*.py'):
            self.load_file(file)

        return True

    def disable_menu(self):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].disable_menu()
                except:
                    pass

    def enable_menu(self):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].enable_menu()
                except:
                    pass

    def on_quit(self):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].on_quit()
                except:
                    pass

    def on_close(self):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].on_close()
                except:
                    pass

    def open_node(self, event=None):
        for moduleName in self:
            if self[moduleName].isActive:
                try:
                    self[moduleName].open_node()
                except:
                    pass

from tkinter import ttk
import tkinter.font as tkFont


class HistoryList:

    def __init__(self):
        self._historyList = []
        self._pointer = None
        self._lock = False

    def append_node(self, node):
        if not self._lock:
            try:
                del self._historyList[self._pointer + 1:]
            except:
                pass
            if self._pointer is None or self._historyList[self._pointer] != node:
                self._historyList.append(node)
                self._pointer = len(self._historyList) - 1
        self._lock = False

    def go_back(self):
        if self._pointer > 0:
            self._pointer -= 1
        return self._historyList[self._pointer]

    def go_forward(self):
        if self._pointer + 1 < len(self._historyList):
            self._pointer += 1
        return self._historyList[self._pointer]

    def lock(self):
        self._lock = True

    def reset(self):
        self._historyList = []
        self._pointer = None
        self._lock = False



class TreeViewer(ttk.Frame):
    PART_PREFIX = 'pt'
    CHAPTER_PREFIX = 'ch'
    SCENE_PREFIX = 'sc'
    CHARACTER_PREFIX = 'cr'
    LOCATION_PREFIX = 'lc'
    ITEM_PREFIX = 'it'
    PRJ_NOTE_PREFIX = 'pn'
    NV_ROOT = 'nv'
    RS_ROOT = 'rs'
    PL_ROOT = 'pl'
    CR_ROOT = f'wr{CHARACTER_PREFIX}'
    LC_ROOT = f'wr{LOCATION_PREFIX}'
    IT_ROOT = f'wr{ITEM_PREFIX}'
    PN_ROOT = f'wr{PRJ_NOTE_PREFIX}'

    _COLUMNS = dict(
        wc=(_('Words'), 'wc_width'),
        vp=(_('Viewpoint'), 'vp_width'),
        sy=(_('Mode'), 'mode_width'),
        st=(_('Status'), 'status_width'),
        nt=(_('N'), 'nt_width'),
        dt=(_('Date'), 'date_width'),
        tm=(_('Time'), 'time_width'),
        dr=(_('Duration'), 'duration_width'),
        tg=(_('Tags'), 'tags_width'),
        po=(_('Position'), 'ps_width'),
        ac=(_('Arcs'), 'arcs_width'),
        ar=(_('A/R'), 'pacing_width'),
        pt=(_('Plot'), 'plot_width'),
        )

    _KEY_CANCEL_PART = '<Shift-Delete>'
    _KEY_DEMOTE_PART = '<Shift-Right>'
    _KEY_PROMOTE_CHAPTER = '<Shift-Left>'

    _SCN_STATUS = []
    for status in Scene.STATUS:
        if not status:
            _SCN_STATUS.append(status)
        else:
            _SCN_STATUS.append(_(status))

    def __init__(self, parent, ui, kwargs, **kw):
        super().__init__(parent, **kw)
        self._ui = ui
        self._wordsTotal = None
        self._trashNode = None

        self.tree = ttk.Treeview(self, selectmode='extended')
        scrollX = ttk.Scrollbar(self, orient='horizontal', command=self.tree.xview)
        scrollY = ttk.Scrollbar(self.tree, orient='vertical', command=self.tree.yview)
        self.tree.configure(xscrollcommand=scrollX.set)
        self.tree.configure(yscrollcommand=scrollY.set)
        scrollX.pack(side='bottom', fill='x')
        scrollY.pack(side='right', fill='y')
        self.tree.pack(fill='both', expand=True)

        self.configure_columns()


        self.scStyleMenu = tk.Menu(self.tree, tearoff=0)
        self.scStyleMenu.add_command(label=_('staged'), command=lambda: self._set_scn_mode(self.tree.selection(), None))
        self.scStyleMenu.add_command(label=_('explaining'), command=lambda: self._set_scn_mode(self.tree.selection(), 'explaining'))
        self.scStyleMenu.add_command(label=_('descriptive'), command=lambda: self._set_scn_mode(self.tree.selection(), 'descriptive'))
        self.scStyleMenu.add_command(label=_('summarizing'), command=lambda: self._set_scn_mode(self.tree.selection(), 'summarizing'))

        self.scTypeMenu = tk.Menu(self.tree, tearoff=0)
        self.scTypeMenu.add_command(label=_('Normal'), command=lambda: self._set_type(self.tree.selection(), 0))
        self.scTypeMenu.add_command(label=_('Notes'), command=lambda: self._set_type(self.tree.selection(), 1))
        self.scTypeMenu.add_command(label=_('Todo'), command=lambda: self._set_type(self.tree.selection(), 2))
        self.scTypeMenu.add_command(label=_('Unused'), command=lambda: self._set_type(self.tree.selection(), 3))

        self.scStatusMenu = tk.Menu(self.tree, tearoff=0)
        self.scStatusMenu.add_command(label=_('Outline'), command=lambda: self._set_scn_status(self.tree.selection(), 1))
        self.scStatusMenu.add_command(label=_('Draft'), command=lambda: self._set_scn_status(self.tree.selection(), 2))
        self.scStatusMenu.add_command(label=_('1st Edit'), command=lambda: self._set_scn_status(self.tree.selection(), 3))
        self.scStatusMenu.add_command(label=_('2nd Edit'), command=lambda: self._set_scn_status(self.tree.selection(), 4))
        self.scStatusMenu.add_command(label=_('Done'), command=lambda: self._set_scn_status(self.tree.selection(), 5))

        self.crStatusMenu = tk.Menu(self.tree, tearoff=0)
        self.crStatusMenu.add_command(label=_('Major Character'), command=lambda: self._set_chr_status(self.tree.selection(), True))
        self.crStatusMenu.add_command(label=_('Minor Character'), command=lambda: self._set_chr_status(self.tree.selection(), False))


        self._nvCtxtMenu = tk.Menu(self.tree, tearoff=0)
        self._nvCtxtMenu.add_command(label=_('Add Scene'), command=self.add_scene)
        self._nvCtxtMenu.add_command(label=_('Add Chapter'), command=self.add_chapter)
        self._nvCtxtMenu.add_command(label=_('Promote Chapter'), command=lambda: self.tree.event_generate(self._KEY_PROMOTE_CHAPTER, when='tail'))
        self._nvCtxtMenu.add_command(label=_('Add Part'), command=self.add_part)
        self._nvCtxtMenu.add_command(label=_('Demote Part'), command=lambda: self.tree.event_generate(self._KEY_DEMOTE_PART, when='tail'))
        self._nvCtxtMenu.add_command(label=_('Cancel Part'), command=lambda: self.tree.event_generate(self._KEY_CANCEL_PART, when='tail'))
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_command(label=_('Delete'), command=lambda: self.tree.event_generate('<Delete>', when='tail'))
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_cascade(label=_('Set Type'), menu=self.scTypeMenu)
        self._nvCtxtMenu.add_cascade(label=_('Set Status'), menu=self.scStatusMenu)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_cascade(label=_('Set Mode'), menu=self.scStyleMenu)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_command(label=_('Join with previous'), command=self.join_scenes)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_command(label=_('Chapter level'), command=lambda: self.show_chapters(self.NV_ROOT))
        self._nvCtxtMenu.add_command(label=_('Expand'), command=lambda: self.open_children(self.tree.selection()[0]))
        self._nvCtxtMenu.add_command(label=_('Collapse'), command=lambda: self.close_children(self.tree.selection()[0]))
        self._nvCtxtMenu.add_command(label=_('Expand all'), command=lambda: self.open_children(''))
        self._nvCtxtMenu.add_command(label=_('Collapse all'), command=lambda: self.close_children(''))

        self._wrCtxtMenu = tk.Menu(self.tree, tearoff=0)
        self._wrCtxtMenu.add_command(label=_('Add'), command=self.add_other_element)
        self._wrCtxtMenu.add_separator()
        self._wrCtxtMenu.add_command(label=_('Delete'), command=lambda: self.tree.event_generate('<Delete>', when='tail'))
        self._wrCtxtMenu.add_separator()
        self._wrCtxtMenu.add_cascade(label=_('Set Status'), menu=self.crStatusMenu)

        fontSize = tkFont.nametofont('TkDefaultFont').actual()['size']
        self.tree.tag_configure('root', font=('', fontSize, 'bold'))
        self.tree.tag_configure('chapter', foreground=kwargs['color_chapter'])
        self.tree.tag_configure('unused', foreground=kwargs['color_unused'])
        self.tree.tag_configure('not exported', foreground=kwargs['color_not_exported'])
        self.tree.tag_configure('notes', foreground=kwargs['color_notes'])
        self.tree.tag_configure('todo', foreground=kwargs['color_todo'])
        self.tree.tag_configure('todo part', font=('', fontSize, 'bold'), foreground=kwargs['color_todo'])
        self.tree.tag_configure('part', font=('', fontSize, 'bold'))
        self.tree.tag_configure('notes part', font=('', fontSize, 'bold'), foreground=kwargs['color_notes'])
        self.tree.tag_configure('major', foreground=kwargs['color_major'])
        self.tree.tag_configure('minor', foreground=kwargs['color_minor'])
        self.tree.tag_configure('Outline', foreground=kwargs['color_outline'])
        self.tree.tag_configure('Draft', foreground=kwargs['color_draft'])
        self.tree.tag_configure('1st Edit', foreground=kwargs['color_1st_edit'])
        self.tree.tag_configure('2nd Edit', foreground=kwargs['color_2nd_edit'])
        self.tree.tag_configure('Done', foreground=kwargs['color_done'])
        self.tree.tag_configure('summarizing', foreground=kwargs['color_summarizing'])
        self.tree.tag_configure('descriptive', foreground=kwargs['color_descriptive'])
        self.tree.tag_configure('explaining', foreground=kwargs['color_explaining'])
        self.tree.tag_configure('On_schedule', foreground=kwargs['color_on_schedule'])
        self.tree.tag_configure('Behind_schedule', foreground=kwargs['color_behind_schedule'])
        self.tree.tag_configure('Before_schedule', foreground=kwargs['color_before_schedule'])

        self._history = HistoryList()

        self.tree.bind('<<TreeviewSelect>>', self._on_select_node)
        self.tree.bind('<<TreeviewOpen>>', self._on_open_branch)
        self.tree.bind('<<TreeviewClose>>', self._on_close_branch)
        self.tree.bind('<Alt-B1-Motion>', self._move_node)
        self.tree.bind('<Delete>', self._delete_node)
        self.tree.bind(self._KEY_CANCEL_PART, self._cancel_part)
        self.tree.bind(self._KEY_DEMOTE_PART, self._demote_part)
        self.tree.bind(self._KEY_PROMOTE_CHAPTER, self._promote_chapter)
        self.tree.bind(kwargs['button_context_menu'], self._open_context_menu)

    def add_chapter(self, **kwargs):
        if self._ui.check_lock():
            return

        selection = kwargs.get('selection', None)
        if not selection:
            try:
                selection = self.tree.selection()[0]
            except:
                selection = ''
        parent = self.NV_ROOT
        index = 0
        if selection.startswith(self.SCENE_PREFIX):
            parent = self.tree.parent(selection)
            selection = self.tree.parent(selection)
        if selection.startswith(self.CHAPTER_PREFIX):
            parent = self.tree.parent(selection)
            index = self.tree.index(selection) + 1
        elif selection.startswith(self.PART_PREFIX):
            parent = selection
        chId = create_id(self._ui.novel.chapters)
        newNode = f'{self.CHAPTER_PREFIX}{chId}'
        self._ui.novel.chapters[chId] = Chapter()
        title = kwargs.get('title', None)
        if title:
            self._ui.novel.chapters[chId].title = title
        else:
            self._ui.novel.chapters[chId].title = f'{_("New Chapter")} (ID{chId})'
        self._ui.novel.chapters[chId].chLevel = 0

        for fieldName in self._ui.prjFile.CHP_KWVAR:
            self._ui.novel.chapters[chId].kwVar[fieldName] = None
        self._ui.novel.chapters[chId].kwVar['Field_NoNumber'] = kwargs.get('NoNumber', None)

        if self.tree.parent(parent).startswith(self.PL_ROOT):
            self._ui.novel.chapters[chId].chType = 2
        elif self.tree.parent(parent).startswith(self.RS_ROOT):
            self._ui.novel.chapters[chId].chType = 1
        else:
            self._ui.novel.chapters[chId].chType = kwargs.get('chType', 0)

        self._ui.novel.srtChapters.append(chId)
        title, columns, nodeTags = self._set_chapter_display(chId)
        self.tree.insert(parent, index, newNode, text=title, values=columns, tags=nodeTags)
        self.update_prj_structure()
        self.refresh_tree()
        self.go_to_node(newNode)
        return chId

    def add_character(self, **kwargs):
        if self._ui.check_lock():
            return

        selection = kwargs.get('selection', None)
        if not selection:
            try:
                selection = self.tree.selection()[0]
            except:
                selection = ''
        title = kwargs.get('title', None)
        isMajor = kwargs.get('isMajor', False)
        index = 0
        if selection.startswith(self.CHARACTER_PREFIX):
            index = self.tree.index(selection) + 1
        crId = create_id(self._ui.novel.characters)
        newNode = f'{self.CHARACTER_PREFIX}{crId}'
        self._ui.novel.characters[crId] = Character()
        if title:
            self._ui.novel.characters[crId].title = title
        else:
            self._ui.novel.characters[crId].title = f'{_("New Character")} (ID{crId})'
        self._ui.novel.characters[crId].isMajor = isMajor

        for fieldName in self._ui.prjFile.CRT_KWVAR:
            self._ui.novel.characters[crId].kwVar[fieldName] = None
        title, columns, nodeTags = self._set_character_display(crId)
        self.tree.insert(self.CR_ROOT, index, newNode, text=title, values=columns, tags=nodeTags)
        self.update_prj_structure()
        self.go_to_node(newNode)
        return crId

    def add_item(self, **kwargs):
        if self._ui.check_lock():
            return

        selection = kwargs.get('selection', None)
        if not selection:
            try:
                selection = self.tree.selection()[0]
            except:
                selection = ''
        title = kwargs.get('title', None)
        index = 0
        if selection.startswith(self.ITEM_PREFIX):
            index = self.tree.index(selection) + 1
        itId = create_id(self._ui.novel.items)
        newNode = f'{self.ITEM_PREFIX}{itId}'
        self._ui.novel.items[itId] = WorldElement()
        if title:
            self._ui.novel.items[itId].title = title
        else:
            self._ui.novel.items[itId].title = f'{_("New Item")} (ID{itId})'

        for fieldName in self._ui.prjFile.ITM_KWVAR:
            self._ui.novel.items[itId].kwVar[fieldName] = None
        title, columns, nodeTags = self._set_item_display(itId)
        self.tree.insert(self.IT_ROOT, index, newNode, text=title, values=columns, tags=nodeTags)
        self.update_prj_structure()
        self.go_to_node(newNode)
        return itId

    def add_location(self, **kwargs):
        if self._ui.check_lock():
            return

        selection = kwargs.get('selection', None)
        if not selection:
            try:
                selection = self.tree.selection()[0]
            except:
                selection = ''
        title = kwargs.get('title', None)
        index = 0
        if selection.startswith(self.LOCATION_PREFIX):
            index = self.tree.index(selection) + 1
        lcId = create_id(self._ui.novel.locations)
        newNode = f'{self.LOCATION_PREFIX}{lcId}'
        self._ui.novel.locations[lcId] = WorldElement()
        if title:
            self._ui.novel.locations[lcId].title = title
        else:
            self._ui.novel.locations[lcId].title = f'{_("New Location")} (ID{lcId})'

        for fieldName in self._ui.prjFile.LOC_KWVAR:
            self._ui.novel.locations[lcId].kwVar[fieldName] = None
        title, columns, nodeTags = self._set_location_display(lcId)
        self.tree.insert(self.LC_ROOT, index, newNode, text=title, values=columns, tags=nodeTags)
        self.update_prj_structure()
        self.go_to_node(newNode)
        return lcId

    def add_other_element(self):
        try:
            selection = self.tree.selection()[0]
        except:
            return

        if self.CHARACTER_PREFIX in selection:
            self.add_character()
        elif self.LOCATION_PREFIX in selection:
            self.add_location()
        elif self.ITEM_PREFIX in selection:
            self.add_item()
        elif self.PRJ_NOTE_PREFIX in selection:
            self.add_project_note()

    def add_part(self, **kwargs):
        if self._ui.check_lock():
            return

        selection = kwargs.get('selection', None)
        if not selection:
            try:
                selection = self.tree.selection()[0]
            except:
                selection = ''
        parent = self.NV_ROOT
        index = 0
        if selection.startswith(self.SCENE_PREFIX):
            selection = self.tree.parent(selection)
        if selection.startswith(self.CHAPTER_PREFIX):
            index = self.tree.index(selection) + 1
            selection = self.tree.parent(selection)
        if selection.startswith(self.PART_PREFIX):
            index = self.tree.index(selection) + 1
            parent = self.tree.parent(selection)
        elif selection.startswith(self.PL_ROOT):
            index = 0
            parent = self.PL_ROOT
        elif selection.startswith(self.RS_ROOT):
            index = 0
            parent = self.RS_ROOT
        chId = create_id(self._ui.novel.chapters)
        newNode = f'{self.PART_PREFIX}{chId}'
        self._ui.novel.chapters[chId] = Chapter()
        title = kwargs.get('title', None)
        if title:
            self._ui.novel.chapters[chId].title = title
        else:
            self._ui.novel.chapters[chId].title = f'{_("New Part")} (ID{chId})'
        self._ui.novel.chapters[chId].chLevel = 1

        for fieldName in self._ui.prjFile.CHP_KWVAR:
            self._ui.novel.chapters[chId].kwVar[fieldName] = None
        self._ui.novel.chapters[chId].kwVar['Field_NoNumber'] = kwargs.get('NoNumber', None)
        if parent.startswith(self.PL_ROOT):
            self._ui.novel.chapters[chId].chType = 2
        elif parent.startswith(self.RS_ROOT):
            self._ui.novel.chapters[chId].chType = 1
        else:
            self._ui.novel.chapters[chId].chType = kwargs.get('chType', 0)
        self._ui.novel.srtChapters.append(chId)
        title, columns, nodeTags = self._set_chapter_display(chId)
        self.tree.insert(parent, index, newNode, text=title, values=columns, tags=nodeTags)
        self.update_prj_structure()
        self.refresh_tree()
        self.go_to_node(newNode)
        return chId

    def add_project_note(self, **kwargs):
        if self._ui.check_lock():
            return

        selection = kwargs.get('selection', None)
        if not selection:
            try:
                selection = self.tree.selection()[0]
            except:
                selection = ''
        title = kwargs.get('title', None)
        index = 0
        if selection.startswith(self.PRJ_NOTE_PREFIX):
            index = self.tree.index(selection) + 1
        pnId = create_id(self._ui.novel.projectNotes)
        newNode = f'{self.PRJ_NOTE_PREFIX}{pnId}'
        self._ui.novel.projectNotes[pnId] = BasicElement()
        if title:
            self._ui.novel.projectNotes[pnId].title = title
        else:
            self._ui.novel.projectNotes[pnId].title = f'{_("New Note")} (ID{pnId})'

        title, columns, nodeTags = self._set_prjNote_display(pnId)
        self.tree.insert(self.PN_ROOT, index, newNode, text=title, values=columns, tags=nodeTags)
        self.update_prj_structure()
        self.go_to_node(newNode)
        return pnId

    def add_scene(self, **kwargs):
        if self._ui.check_lock():
            return

        selection = kwargs.get('selection', None)
        if not selection:
            try:
                selection = self.tree.selection()[0]
            except:
                return

        index = 0
        if selection.startswith(self.SCENE_PREFIX):
            parent = self.tree.parent(selection)
            index = self.tree.index(selection) + 1
        elif selection.startswith(self.CHAPTER_PREFIX):
            parent = selection
        elif selection.startswith(self.PART_PREFIX):
            parent = selection
        else:
            return

        scId = create_id(self._ui.novel.scenes)
        newNode = f'{self.SCENE_PREFIX}{scId}'
        self._ui.novel.scenes[scId] = Scene()
        title = kwargs.get('title', None)
        if title:
            self._ui.novel.scenes[scId].title = title
        else:
            self._ui.novel.scenes[scId].title = f'{_("New Scene")} (ID{scId})'
        self._ui.novel.scenes[scId].status = kwargs.get('status', 1)
        self._ui.novel.scenes[scId].scType = kwargs.get('scType', 0)
        self._ui.novel.scenes[scId].appendToPrev = kwargs.get('appendToPrev', False)

        for fieldName in self._ui.prjFile.SCN_KWVAR:
            self._ui.novel.scenes[scId].kwVar[fieldName] = None
        title, columns, nodeTags = self._set_scene_display(scId)
        self.tree.insert(parent, index, newNode, text=title, values=columns, tags=nodeTags)
        self.update_prj_structure()
        self.go_to_node(newNode)
        return scId

    def build_tree(self):
        self.reset_tree()

        self.tree.insert('', 'end', self.NV_ROOT, text=_('Book'), tags='root', open=True)
        self.tree.insert('', 'end', self.CR_ROOT, text=_('Characters'), tags='root', open=False)
        self.tree.insert('', 'end', self.LC_ROOT, text=_('Locations'), tags='root', open=False)
        self.tree.insert('', 'end', self.IT_ROOT, text=_('Items'), tags='root', open=False)
        self.tree.insert('', 'end', self.RS_ROOT, text=_('Research'), tags='root', open=False)
        self.tree.insert('', 'end', self.PL_ROOT, text=_('Planning'), tags='root', open=False)
        self.tree.insert('', 'end', self.PN_ROOT, text=_('Project notes'), tags='root', open=True)

        inPart = False
        inNotesPart = False
        inTodoPart = False
        wordCount = 0
        self._wordsTotal = self._ui.prjFile.get_counts()[0]
        for chId in self._ui.novel.srtChapters:
            if self._ui.novel.chapters[chId].isTrash:
                self._ui.novel.chapters[chId].chType = 3
                self._trashNode = f'{self.CHAPTER_PREFIX}{chId}'
                inPart = False
            if self._ui.novel.chapters[chId].chLevel == 1:
                inPart = True
                inChapter = False
                if self._ui.novel.chapters[chId].chType == 1:
                    inTodoPart = False
                    inNotesPart = True
                    parent = self.RS_ROOT
                elif self._ui.novel.chapters[chId].chType == 2:
                    inNotesPart = False
                    inTodoPart = True
                    parent = self.PL_ROOT
                else:
                    inNotesPart = False
                    inTodoPart = False
                    parent = self.NV_ROOT
                title, columns, nodeTags = self._set_chapter_display(chId, position=wordCount)
                partNode = self.tree.insert(parent, 'end', f'{self.PART_PREFIX}{chId}', text=title, values=columns, tags=nodeTags, open=True)
            else:
                inChapter = True
                if self._ui.novel.chapters[chId].chType != 1:
                    if inNotesPart:
                        inNotesPart = False
                        inPart = False
                if self._ui.novel.chapters[chId].chType != 2:
                    if inTodoPart:
                        inTodoPart = False
                        inPart = False
                if inPart:
                    parentNode = partNode
                else:
                    parentNode = self.NV_ROOT
                title, columns, nodeTags = self._set_chapter_display(chId, position=wordCount)
                chapterNode = self.tree.insert(parentNode, 'end', f'{self.CHAPTER_PREFIX}{chId}', text=title, values=columns, tags=nodeTags, open=True)
            for scId in self._ui.novel.chapters[chId].srtScenes:
                title, columns, nodeTags = self._set_scene_display(scId, position=wordCount)
                if inChapter:
                    parentNode = chapterNode
                else:
                    parentNode = partNode
                self.tree.insert(parentNode, 'end', f'{self.SCENE_PREFIX}{scId}', text=title, values=columns, tags=nodeTags)

                if self._ui.novel.scenes[scId].scType == 0 and not self._ui.novel.scenes[scId].doNotExport:
                    wordCount += self._ui.novel.scenes[scId].wordCount

        for crId in self._ui.novel.srtCharacters:
            title, columns, nodeTags = self._set_character_display(crId)
            self.tree.insert(self.CR_ROOT, 'end', f'{self.CHARACTER_PREFIX}{crId}', text=title, values=columns, tags=nodeTags)

        for lcId in self._ui.novel.srtLocations:
            title, columns, nodeTags = self._set_location_display(lcId)
            self.tree.insert(self.LC_ROOT, 'end', f'{self.LOCATION_PREFIX}{lcId}', text=title, values=columns, tags=nodeTags)

        for itId in self._ui.novel.srtItems:
            title, columns, nodeTags = self._set_item_display(itId)
            self.tree.insert(self.IT_ROOT, 'end', f'{self.ITEM_PREFIX}{itId}', text=title, values=columns, tags=nodeTags)

        for pnId in self._ui.novel.srtPrjNotes:
            title, columns, nodeTags = self._set_prjNote_display(pnId)
            self.tree.insert(self.PN_ROOT, 'end', f'{self.PRJ_NOTE_PREFIX}{pnId}', text=title, values=columns, tags=nodeTags)

        self.go_to_node(self.NV_ROOT)

    def close_children(self, parent):
        self.tree.item(parent, open=False)
        if parent.startswith(self.CHAPTER_PREFIX):
            self._configure_chapter_columns(parent, collect=True)
        for child in self.tree.get_children(parent):
            self.close_children(child)

    def configure_columns(self):
        self._colPos = {}
        self.columns = []
        titles = []
        srtColumns = string_to_list(self._ui.kwargs['column_order'])

        for coId in self._COLUMNS:
            if not coId in srtColumns:
                srtColumns.append(coId)
        i = 0
        for coId in srtColumns:
            try:
                title, width = self._COLUMNS[coId]
            except:
                continue
            self._colPos[coId] = i
            i += 1
            self.columns.append((coId, title, width))
            titles.append(title)
        self.tree.configure(columns=tuple(titles))
        for column in self.columns:
            self.tree.heading(column[1], text=column[1], anchor='w')
            self.tree.column(column[1], width=int(self._ui.kwargs[column[2]]), minwidth=3, stretch=False)
        self.tree.column('#0', width=int(self._ui.kwargs['title_width']), stretch=False)

    def go_back(self, event=None):
        self._browse_tree(self._history.go_back())

    def go_forward(self, event=None):
        self._browse_tree(self._history.go_forward())

    def go_to_node(self, node):
        self.tree.see(node)
        self.tree.selection_set(node)
        self.tree.focus_set()
        self.tree.focus(node)

    def join_scenes(self):

        def join_str(prevText, thisText):
            if prevText is None:
                prevText = ''
            if thisText is None:
                thisText = ''
            if prevText or thisText:
                prevText = f'{prevText}\n{thisText}'.strip()
            return prevText

        def join_lst(prevList, thisList):
            if thisList:
                for elemId in thisList:
                    if not prevList:
                        prevList = []
                    if not elemId in prevList:
                        prevList.append(elemId)

        if self._ui.check_lock():
            return

        try:
            selection = self.tree.selection()[0]
        except:
            return

        if not selection.startswith(self.SCENE_PREFIX):
            return

        try:
            parent = self.tree.parent(selection)
            prevNode = self.prev_node(selection, parent)
            if not prevNode:
                raise Error(_('There is no previous scene in the chapter'))

            thisScId = selection[2:]
            prevScId = prevNode[2:]

            if self._ui.novel.scenes[thisScId].scType != self._ui.novel.scenes[prevScId].scType:
                raise Error(_('The scenes are not of the same type'))

            if self._ui.novel.scenes[thisScId].characters:
                if self._ui.novel.scenes[thisScId].characters:
                    if self._ui.novel.scenes[prevScId].characters:
                        if self._ui.novel.scenes[thisScId].characters[0] != self._ui.novel.scenes[prevScId].characters[0]:
                            raise Error(_('The scenes have different viewpoints'))

                    else:
                        self._ui.novel.scenes[prevScId].characters.append(self._ui.novel.scenes[thisScId].characters[0])

        except Error as ex:
            self._ui.show_error(str(ex), title=_('Cannot join scenes'))
            return

        joinedTitles = f'{self._ui.novel.scenes[prevScId].title} & {self._ui.novel.scenes[thisScId].title}'
        self._ui.novel.scenes[prevScId].title = joinedTitles

        prevContent = self._ui.novel.scenes[prevScId].sceneContent
        thisContent = self._ui.novel.scenes[thisScId].sceneContent
        self._ui.novel.scenes[prevScId].sceneContent = join_str(prevContent, thisContent)

        self._ui.novel.scenes[prevScId].desc = join_str(self._ui.novel.scenes[prevScId].desc, self._ui.novel.scenes[thisScId].desc)
        self._ui.novel.scenes[prevScId].goal = join_str(self._ui.novel.scenes[prevScId].goal, self._ui.novel.scenes[thisScId].goal)
        self._ui.novel.scenes[prevScId].conflict = join_str(self._ui.novel.scenes[prevScId].conflict, self._ui.novel.scenes[thisScId].conflict)
        self._ui.novel.scenes[prevScId].outcome = join_str(self._ui.novel.scenes[prevScId].outcome, self._ui.novel.scenes[thisScId].outcome)
        self._ui.novel.scenes[prevScId].notes = join_str(self._ui.novel.scenes[prevScId].notes, self._ui.novel.scenes[thisScId].notes)

        join_lst(self._ui.novel.scenes[prevScId].characters, self._ui.novel.scenes[thisScId].characters)
        join_lst(self._ui.novel.scenes[prevScId].locations, self._ui.novel.scenes[thisScId].locations)
        join_lst(self._ui.novel.scenes[prevScId].items, self._ui.novel.scenes[thisScId].items)
        join_lst(self._ui.novel.scenes[prevScId].tags, self._ui.novel.scenes[thisScId].tags)

        arcs = string_to_list(self._ui.novel.scenes[prevScId].scnArcs)
        for arc in string_to_list(self._ui.novel.scenes[thisScId].scnArcs):
            if not arc in arcs:
                arcs.append(arc)
        self._ui.novel.scenes[prevScId].scnArcs = list_to_string(arcs)

        pointIds = string_to_list(self._ui.novel.scenes[thisScId].kwVar.get('Field_SceneAssoc', None))
        for ptId in pointIds:
            self._ui.novel.scenes[ptId].kwVar['Field_SceneAssoc'] = prevScId

        try:
            thisLastsMin = int(self._ui.novel.scenes[thisScId].lastsMinutes)
        except:
            thisLastsMin = 0
        try:
            prevLastsMin = int(self._ui.novel.scenes[prevScId].lastsMinutes)
        except:
            prevLastsMin = 0
        hoursLeft, prevLastsMin = divmod((prevLastsMin + thisLastsMin), 60)
        self._ui.novel.scenes[prevScId].lastsMinutes = str(prevLastsMin)
        try:
            thisLastsHours = int(self._ui.novel.scenes[thisScId].lastsHours)
        except:
            thisLastsHours = 0
        try:
            prevLastsHours = int(self._ui.novel.scenes[prevScId].lastsHours)
        except:
            prevLastsHours = 0
        daysLeft, prevLastsHours = divmod((prevLastsHours + thisLastsHours + hoursLeft), 24)
        self._ui.novel.scenes[prevScId].lastsHours = str(prevLastsHours)
        try:
            thisLastsDays = int(self._ui.novel.scenes[thisScId].lastsDays)
        except:
            thisLastsDays = 0
        try:
            prevLastsDays = int(self._ui.novel.scenes[prevScId].lastsDays)
        except:
            prevLastsDays = 0
        prevLastsDays = prevLastsDays + thisLastsDays + daysLeft
        self._ui.novel.scenes[prevScId].lastsDays = str(prevLastsDays)

        chId = parent[2:]
        self._ui.novel.chapters[chId].srtScenes.remove(thisScId)

        self.tree.delete(selection)

        del(self._ui.novel.scenes[thisScId])
        self.update_prj_structure()
        self.go_to_node(prevNode)

    def next_node(self, thisNode, root):

        def search_tree(parent, result, flag):
            for child in self.tree.get_children(parent):
                if result:
                    break
                if child.startswith(prefix):
                    if flag:
                        result = child
                        break
                    elif child == thisNode:
                        flag = True
                else:
                    result, flag = search_tree(child, result, flag)
            return result, flag

        prefix = thisNode[:2]
        nextNode, __ = search_tree(root, None, False)
        return nextNode

    def on_quit(self):
        self._ui.kwargs['title_width'] = self.tree.column('#0', 'width')
        for i, column in enumerate(self.columns):
            self._ui.kwargs[column[2]] = self.tree.column(i, 'width')

    def open_children(self, parent):
        self.tree.item(parent, open=True)
        if parent.startswith(self.CHAPTER_PREFIX):
            self._configure_chapter_columns(parent, collect=False)
        for child in self.tree.get_children(parent):
            self.open_children(child)

    def prev_node(self, thisNode, root):

        def search_tree(parent, result, prevNode):
            for child in self.tree.get_children(parent):
                if result:
                    break
                if child.startswith(prefix):
                    if child == thisNode:
                        result = prevNode
                        break
                    else:
                        prevNode = child
                else:
                    result, prevNode = search_tree(child, result, prevNode)
            return result, prevNode

        prefix = thisNode[:2]
        prevNode, __ = search_tree(root, None, None)
        return prevNode

    def refresh_tree(self):
        isModified = False
        if self._ui.prjFile.renumber_chapters():
            isModified = True
        if self._ui.prjFile.adjust_scene_types():
            isModified = True
        self.build_tree()
        if isModified:
            self._ui.isModified = True

    def reset_tree(self):
        for child in self.tree.get_children(''):
            self.tree.delete(child)
        self._history.reset()

    def show_branch(self, node):
        self.go_to_node(node)
        self.open_children(node)

    def show_chapters(self, parent):
        if parent.startswith(self.CHAPTER_PREFIX):
            self.tree.item(parent, open=False)
            self._configure_chapter_columns(parent, collect=True)
        else:
            self.tree.item(parent, open=True)
            for child in self.tree.get_children(parent):
                self.show_chapters(child)

    def update_prj_structure(self):

        def serialize_tree(node, chId, scnPos=0):
            for childNode in self.tree.get_children(node):
                if childNode.startswith(self.SCENE_PREFIX):
                    scId = childNode[2:]
                    self._ui.novel.chapters[chId].srtScenes.append(scId)
                    title, columns, nodeTags = self._set_scene_display(scId, position=scnPos)
                    if self._ui.novel.scenes[scId].scType == 0 and not self._ui.novel.scenes[scId].doNotExport:
                        scnPos += self._ui.novel.scenes[scId].wordCount
                elif childNode.startswith(self.CHARACTER_PREFIX):
                    crId = childNode[2:]
                    self._ui.novel.srtCharacters.append(crId)
                    title, columns, nodeTags = self._set_character_display(crId)
                elif childNode.startswith(self.LOCATION_PREFIX):
                    lcId = childNode[2:]
                    self._ui.novel.srtLocations.append(lcId)
                    title, columns, nodeTags = self._set_location_display(lcId)
                elif childNode.startswith(self.ITEM_PREFIX):
                    itId = childNode[2:]
                    self._ui.novel.srtItems.append(itId)
                    title, columns, nodeTags = self._set_item_display(itId)
                elif childNode.startswith(self.PRJ_NOTE_PREFIX):
                    pnId = childNode[2:]
                    self._ui.novel.srtPrjNotes.append(pnId)
                    title, columns, nodeTags = self._set_prjNote_display(pnId)
                else:
                    chId = childNode[2:]
                    self._ui.novel.srtChapters.append(chId)
                    self._ui.novel.chapters[chId].srtScenes = []
                    chpPos = scnPos
                    scnPos = serialize_tree(childNode, chId, scnPos)
                    doCollect = not self.tree.item(childNode, 'open')
                    title, columns, nodeTags = self._set_chapter_display(chId, position=chpPos, collect=doCollect)
                self.tree.item(childNode, text=title, values=columns, tags=nodeTags)
            return scnPos

        self._wordsTotal = self._ui.prjFile.get_counts()[0]
        self._ui.novel.srtChapters = []
        self._ui.novel.srtCharacters = []
        self._ui.novel.srtLocations = []
        self._ui.novel.srtItems = []
        self._ui.novel.srtPrjNotes = []
        serialize_tree(self.NV_ROOT, '')
        serialize_tree(self.PL_ROOT, '')
        serialize_tree(self.RS_ROOT, '')
        serialize_tree(self.CR_ROOT, '')
        serialize_tree(self.LC_ROOT, '')
        serialize_tree(self.IT_ROOT, '')
        serialize_tree(self.PN_ROOT, '')

        if self._ui.prjFile.adjust_scene_types():
            try:
                if self.tree.next(self._trashNode) != '':
                    self.tree.move(self._trashNode, self.NV_ROOT, 'end')
            except:
                pass

        self._ui.prjFile.check_arcs()

        self._ui.isModified = True
        self._ui.show_status()

    def _browse_tree(self, node):
        if self.tree.exists(node):
            if self.tree.selection()[0] != node:
                self._history.lock()
                self.go_to_node(node)
        else:
            self._history.reset()
            self._history.append_node(self.tree.selection()[0])

    def _cancel_part(self, event):
        if self._ui.check_lock():
            return

        selection = self.tree.selection()[0]
        if not selection.startswith(self.PART_PREFIX):
            return
        elemId = selection[2:]
        if self._ui.ask_yes_no(_('Remove part "{}" and keep the chapters?').format(self._ui.novel.chapters[elemId].title)):
            if self.tree.prev(selection):
                self.go_to_node(self.tree.prev(selection))
            else:
                self.go_to_node(self.tree.parent(selection))
            self._ui.novel.chapters[elemId].chLevel = 0
            self.update_prj_structure()
            self.refresh_tree()
            del self._ui.novel.chapters[elemId]
            self._ui.novel.srtChapters.remove(elemId)
            self.tree.delete(f'{self.CHAPTER_PREFIX}{elemId}')
            self.update_prj_structure()

    def _configure_chapter_columns(self, nodeId, collect=False):
        if nodeId.startswith(self.CHAPTER_PREFIX):
            chId = nodeId[2:]
            positionStr = self.tree.item(nodeId)['values'][self._colPos['po']]
            __, columns, __ = self._set_chapter_display(chId, position=None, collect=collect)
            columns[self._colPos['po']] = positionStr
            self.tree.item(nodeId, values=columns)

    def _delete_node(self, event):

        def waste_scenes(node):
            if node.startswith(self.SCENE_PREFIX):
                scId = node[2:]
                self._ui.novel.scenes[scId].scType = 3
                self.tree.move(node, self._trashNode, 0)
            else:
                chId = node[2:]
                del self._ui.novel.chapters[chId]
                if chId in self._ui.novel.srtChapters:
                    self._ui.novel.srtChapters.remove(chId)
                for childNode in self.tree.get_children(node):
                    waste_scenes(childNode)

        if self._ui.check_lock():
            return

        for  selection in self.tree.selection():
            elemId = selection[2:]
            if selection.startswith(self.SCENE_PREFIX):
                candidate = f'{_("Scene")} "{self._ui.novel.scenes[elemId].title}"'
            elif selection.startswith(self.CHAPTER_PREFIX):
                candidate = f'{_("Chapter")} "{self._ui.novel.chapters[elemId].title}"'
            elif selection.startswith(self.PART_PREFIX):
                candidate = f'{_("Part")} "{self._ui.novel.chapters[elemId].title}"'
            elif selection.startswith(self.CHARACTER_PREFIX):
                candidate = f'{_("Character")} "{self._ui.novel.characters[elemId].title}"'
            elif selection.startswith(self.LOCATION_PREFIX):
                candidate = f'{_("Location")} "{self._ui.novel.locations[elemId].title}"'
            elif selection.startswith(self.ITEM_PREFIX):
                candidate = f'{_("Item")} "{self._ui.novel.items[elemId].title}"'
            elif selection.startswith(self.PRJ_NOTE_PREFIX):
                candidate = f'{_("Project note")} "{self._ui.novel.projectNotes[elemId].title}"'
            else:
                return

            if not self._ui.ask_yes_no(_('Delete {}?').format(candidate)):
                return

            if self.tree.prev(selection):
                self.go_to_node(self.tree.prev(selection))
            else:
                self.go_to_node(self.tree.parent(selection))
            if selection == self._trashNode:
                self.tree.delete(selection)
                self._trashNode = None
                for scId in self._ui.novel.chapters[elemId].srtScenes:
                    del self._ui.novel.scenes[scId]
                self._ui.novel.chapters[elemId].srtScenes = []
                del self._ui.novel.chapters[elemId]
                if elemId in self._ui.novel.srtChapters:
                    self._ui.novel.srtChapters.remove(elemId)
            elif selection.startswith(self.CHARACTER_PREFIX):
                self.tree.delete(selection)
                del self._ui.novel.characters[elemId]
                for scId in self._ui.novel.scenes:
                    try:
                        self._ui.novel.scenes[scId].characters.remove(elemId)
                    except:
                        pass
            elif selection.startswith(self.LOCATION_PREFIX):
                self.tree.delete(selection)
                del self._ui.novel.locations[elemId]
                for scId in self._ui.novel.scenes:
                    try:
                        self._ui.novel.scenes[scId].locations.remove(elemId)
                    except:
                        pass
            elif selection.startswith(self.ITEM_PREFIX):
                self.tree.delete(selection)
                del self._ui.novel.items[elemId]
                for scId in self._ui.novel.scenes:
                    try:
                        self._ui.novel.scenes[scId].items.remove(elemId)
                    except:
                        pass
            elif selection.startswith(self.PRJ_NOTE_PREFIX):
                self.tree.delete(selection)
                del self._ui.novel.projectNotes[elemId]
            else:
                if self._trashNode is None:
                    trashId = create_id(self._ui.novel.chapters)
                    self._ui.novel.chapters[trashId] = Chapter()
                    for fieldName in self._ui.prjFile.CHP_KWVAR:
                        self._ui.novel.chapters[trashId].kwVar[fieldName] = None
                    self._ui.novel.chapters[trashId].title = _('Trash')
                    self._ui.novel.chapters[trashId].isTrash = True
                    self._trashNode = f'{self.CHAPTER_PREFIX}{trashId}'
                    self.tree.insert(self.NV_ROOT, 'end', self._trashNode, text=_('Trash'), tags='unused', open=True)
                if selection.startswith(self.SCENE_PREFIX):
                    if self.tree.parent(selection) == self._trashNode:
                        self.tree.delete(selection)
                        del self._ui.novel.scenes[elemId]
                    else:
                        waste_scenes(selection)
                else:
                    waste_scenes(selection)
                    self.tree.delete(selection)
                self._set_type([self._trashNode], 3)
            self.update_prj_structure()

    def _demote_part(self, event):
        if self._ui.check_lock():
            return

        selection = self.tree.selection()[0]
        if not selection.startswith(self.PART_PREFIX):
            return
        elemId = selection[2:]
        if self._ui.ask_yes_no(_('Demote part "{}" to chapter?').format(self._ui.novel.chapters[elemId].title)):
            self._ui.novel.chapters[elemId].chLevel = 0
            self.update_prj_structure()
            self.refresh_tree()

    def _on_close_branch(self, event=None):
        try:
            nodeId = self.tree.selection()[0]
        except IndexError:
            pass
        else:
            self._configure_chapter_columns(nodeId, collect=True)

    def _on_open_branch(self, event=None):
        try:
            nodeId = self.tree.selection()[0]
        except IndexError:
            pass
        else:
            self._configure_chapter_columns(nodeId, collect=False)

    def _on_select_node(self, event=None):
        self._ui.show_properties(event)
        try:
            nodeId = self.tree.selection()[0]
        except IndexError:
            pass
        else:
            self._history.append_node(nodeId)

    def _move_node(self, event):
        if self._ui.isLocked:
            return

        node = self.tree.selection()[0]
        if node == self._trashNode:
            return

        targetNode = self.tree.identify_row(event.y)
        if node[:2] == targetNode[:2]:
            self.tree.move(node, self.tree.parent(targetNode), self.tree.index(targetNode))
        elif node.startswith(self.SCENE_PREFIX) and targetNode.startswith(self.CHAPTER_PREFIX) and not self.tree.get_children(targetNode):
            self.tree.move(node, targetNode, 0)
        elif node.startswith(self.SCENE_PREFIX) and targetNode.startswith(self.PART_PREFIX):
            self.tree.move(node, targetNode, 0)
        elif node.startswith(self.CHAPTER_PREFIX) and targetNode.startswith(self.PART_PREFIX) and not self.tree.get_children(targetNode):
            self.tree.move(node, targetNode, self.tree.index(targetNode))
        self.update_prj_structure()

    def _open_context_menu(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            self.go_to_node(row)
            prefix = row[:2]
            if prefix in (self.NV_ROOT, self.RS_ROOT, self.PL_ROOT, self.PART_PREFIX, self.CHAPTER_PREFIX, self.SCENE_PREFIX):
                if self._ui.isLocked:
                    self._nvCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Mode'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Scene'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Part'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Cancel Part'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Demote Part'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Promote Chapter'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                elif prefix.startswith(self.NV_ROOT):
                    self._nvCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Status'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Set Mode'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Scene'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Part'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Cancel Part'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Demote Part'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Promote Chapter'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                elif prefix.startswith(self.RS_ROOT):
                    self._nvCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Mode'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Scene'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Part'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Cancel Part'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Demote Part'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Promote Chapter'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                elif prefix.startswith(self.PL_ROOT):
                    self._nvCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Mode'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Scene'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Part'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Cancel Part'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Demote Part'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Promote Chapter'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                else:
                    self._nvCtxtMenu.entryconfig(_('Delete'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Set Type'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Set Status'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Set Mode'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Scene'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Part'), state='normal')
                    if prefix.startswith(self.PART_PREFIX):
                        self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                        self._nvCtxtMenu.entryconfig(_('Cancel Part'), state='normal')
                        self._nvCtxtMenu.entryconfig(_('Demote Part'), state='normal')
                    else:
                        self._nvCtxtMenu.entryconfig(_('Cancel Part'), state='disabled')
                        self._nvCtxtMenu.entryconfig(_('Demote Part'), state='disabled')
                    if prefix.startswith(self.CHAPTER_PREFIX):
                        self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                        if row != self._trashNode:
                            self._nvCtxtMenu.entryconfig(_('Promote Chapter'), state='normal')
                        else:
                            self._nvCtxtMenu.entryconfig(_('Promote Chapter'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Add Scene'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Add Part'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Set Mode'), state='disabled')
                    else:
                        self._nvCtxtMenu.entryconfig(_('Promote Chapter'), state='disabled')
                    if prefix.startswith(self.SCENE_PREFIX):
                        self._nvCtxtMenu.entryconfig(_('Join with previous'), state='normal')
                try:
                    self._nvCtxtMenu.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    self._nvCtxtMenu.grab_release()
            elif prefix in ('wr', self.CHARACTER_PREFIX, self.LOCATION_PREFIX, self.ITEM_PREFIX, self.PRJ_NOTE_PREFIX):
                if self._ui.isLocked:
                    self._wrCtxtMenu.entryconfig(_('Add'), state='disabled')
                    self._wrCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._wrCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                else:
                    self._wrCtxtMenu.entryconfig(_('Add'), state='normal')
                    if prefix.startswith('wr'):
                        self._wrCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    else:
                        self._wrCtxtMenu.entryconfig(_('Delete'), state='normal')
                    if prefix.startswith(self.CHARACTER_PREFIX) or  row.endswith(self.CHARACTER_PREFIX):
                        self._wrCtxtMenu.entryconfig(_('Set Status'), state='normal')
                    else:
                        self._wrCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                try:
                    self._wrCtxtMenu.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    self._wrCtxtMenu.grab_release()

    def _promote_chapter(self, event):
        if self._ui.check_lock():
            return

        selection = self.tree.selection()[0]
        if not selection.startswith(self.CHAPTER_PREFIX):
            return
        elemId = selection[2:]
        if self._ui.novel.chapters[elemId].isTrash:
            return

        if self._ui.ask_yes_no(_('Promote chapter "{}" to part?').format(self._ui.novel.chapters[elemId].title)):
            self._ui.novel.chapters[elemId].chLevel = 1
            self.update_prj_structure()
            self.refresh_tree()

    def _set_chapter_display(self, chId, position=None, collect=False):

        def count_words(chId):
            chapterWordCount = 0
            if self._ui.novel.chapters[chId].chType == 0:
                for scId in self._ui.novel.chapters[chId].srtScenes:
                    if self._ui.novel.scenes[scId].scType == 0 and not self._ui.novel.scenes[scId].doNotExport:
                        chapterWordCount += self._ui.novel.scenes[scId].wordCount
            return chapterWordCount

        def collect_viewpoints(chId):
            chapterViewpoints = []
            if self._ui.novel.chapters[chId].chType == 0:
                for scId in self._ui.novel.chapters[chId].srtScenes:
                    if self._ui.novel.scenes[scId].scType == 0 and not self._ui.novel.scenes[scId].doNotExport:
                        try:
                            crId = self._ui.novel.scenes[scId].characters[0]
                            viewpoint = self._ui.novel.characters[crId].title
                            if not viewpoint in chapterViewpoints:
                                chapterViewpoints.append(viewpoint)
                        except:
                            pass
            return list_to_string(chapterViewpoints)

        def collect_tags(chId):
            chapterTags = []
            if self._ui.novel.chapters[chId].chType != 3:
                for scId in self._ui.novel.chapters[chId].srtScenes:
                    if self._ui.novel.scenes[scId].scType != 3 and not self._ui.novel.scenes[scId].doNotExport:
                        if self._ui.novel.scenes[scId].tags:
                            for tag in self._ui.novel.scenes[scId].tags:
                                if not tag in chapterTags:
                                    chapterTags.append(tag)
            return list_to_string(chapterTags)

        def collect_arcpoints(chId):
            chapterPoints = []
            if self._ui.novel.chapters[chId].chType == 0:
                for scId in self._ui.novel.chapters[chId].srtScenes:
                    if self._ui.novel.scenes[scId].scType == 0 and not self._ui.novel.scenes[scId].doNotExport:
                        scenePtIds = string_to_list(self._ui.novel.scenes[scId].kwVar.get('Field_SceneAssoc', None))
                        for ptId in scenePtIds:
                            arcPoint = self._ui.novel.scenes[ptId].title
                            if not arcPoint in chapterPoints:
                                chapterPoints.append(arcPoint)
            return list_to_string(chapterPoints)

        def collect_arcs(chId):
            chapterArcs = []
            if self._ui.novel.chapters[chId].chType == 0:
                for scId in self._ui.novel.chapters[chId].srtScenes:
                    if self._ui.novel.scenes[scId].scType == 0 and not self._ui.novel.scenes[scId].doNotExport:
                        sceneArcs = string_to_list(self._ui.novel.scenes[scId].kwVar.get('Field_SceneArcs', None))
                        for arc in sceneArcs:
                            if not arc in chapterArcs:
                                chapterArcs.append(arc)
            return list_to_string(chapterArcs)

        def collect_note_indicators(chId):
            indicator = ''
            if self._ui.novel.chapters[chId].chType != 3:
                for scId in self._ui.novel.chapters[chId].srtScenes:
                    if self._ui.novel.scenes[scId].scType != 3 and not self._ui.novel.scenes[scId].doNotExport:
                        if self._ui.novel.scenes[scId].notes:
                            indicator = _('N')
            return indicator

        title = self._ui.novel.chapters[chId].title
        if not title:
            title = _('Unnamed')
        columns = []
        for __ in self.columns:
            columns.append('')
        nodeTags = []
        if self._ui.novel.chapters[chId].chType == 1:
            if self._ui.novel.chapters[chId].chLevel == 1:
                nodeTags.append('notes part')
            else:
                nodeTags.append('notes')
        elif self._ui.novel.chapters[chId].chType == 2:
            if self._ui.novel.chapters[chId].chLevel == 1:
                nodeTags.append('todo part')
            else:
                nodeTags.append('todo')
                arc = self._ui.novel.chapters[chId].kwVar['Field_ArcDefinition']
                if arc:
                    wordCount = 0
                    for sid in self._ui.novel.scenes:
                        if self._ui.novel.scenes[sid].scType == 0 and not self._ui.novel.scenes[sid].doNotExport:
                            if arc in string_to_list(self._ui.novel.scenes[sid].scnArcs):
                                wordCount += self._ui.novel.scenes[sid].wordCount
                    columns[self._colPos['wc']] = wordCount
        elif self._ui.novel.chapters[chId].chType == 3:
            nodeTags.append('unused')
        else:
            nodeTags.append('chapter')
            try:
                positionStr = f'{round(100 * position / self._wordsTotal, 1)}%'
            except:
                positionStr = ''
            wordCount = count_words(chId)
            if self._ui.novel.chapters[chId].chLevel == 1:
                nodeTags.append('part')
                i = self._ui.novel.srtChapters.index(chId) + 1
                while i < len(self._ui.novel.srtChapters):
                    c = self._ui.novel.srtChapters[i]
                    if self._ui.novel.chapters[c].chLevel == 1:
                        break
                    i += 1
                    wordCount += count_words(c)
            columns[self._colPos['wc']] = wordCount
            columns[self._colPos['po']] = positionStr
            if collect:
                columns[self._colPos['vp']] = collect_viewpoints(chId)
        if collect:
            columns[self._colPos['tg']] = collect_tags(chId)
            columns[self._colPos['ac']] = collect_arcs(chId)
            columns[self._colPos['pt']] = collect_arcpoints(chId)
            columns[self._colPos['nt']] = collect_note_indicators(chId)
        return title, columns, tuple(nodeTags)

    def _set_character_display(self, crId):
        title = self._ui.novel.characters[crId].title
        if not title:
            title = _('Unnamed')
        columns = []
        for __ in self.columns:
            columns.append('')

        if self._ui.novel.characters[crId].notes:
            columns[self._colPos['nt']] = _('N')

        wordCount = 0
        for scId in self._ui.novel.scenes:
            if self._ui.novel.scenes[scId].scType == 0:
                if self._ui.novel.scenes[scId].characters:
                    if self._ui.novel.scenes[scId].characters[0] == crId and not self._ui.novel.scenes[scId].doNotExport:
                        wordCount += self._ui.novel.scenes[scId].wordCount
        if wordCount > 0:
            columns[self._colPos['wc']] = wordCount

            try:
                percentageStr = f'{round(100 * wordCount / self._wordsTotal, 1)}%'
            except:
                percentageStr = ''
            columns[self._colPos['vp']] = percentageStr

        try:
            columns[self._colPos['tg']] = list_to_string(self._ui.novel.characters[crId].tags)
        except:
            pass

        nodeTags = []
        if self._ui.novel.characters[crId].isMajor:
            nodeTags.append('major')
        else:
            nodeTags.append('minor')
        return title, columns, tuple(nodeTags)

    def _set_chr_status(self, nodes, chrStatus):
        if self._ui.check_lock():
            return

        has_changed = False
        for node in nodes:
            if node.startswith(self.CHARACTER_PREFIX):
                if self._ui.novel.characters[node[2:]].isMajor != chrStatus:
                    self._ui.novel.characters[node[2:]].isMajor = chrStatus
                    has_changed = True
            elif node == self.CR_ROOT:

                self._set_chr_status(self.tree.get_children(node), chrStatus)
        if has_changed:
            self.update_prj_structure()

    def _set_item_display(self, itId):
        title = self._ui.novel.items[itId].title
        if not title:
            title = _('Unnamed')
        columns = []
        for __ in self.columns:
            columns.append('')

        try:
            columns[self._colPos['tg']] = list_to_string(self._ui.novel.items[itId].tags)
        except:
            pass
        nodeTags = []
        return title, columns, tuple(nodeTags)

    def _set_location_display(self, lcId):
        title = self._ui.novel.locations[lcId].title
        if not title:
            title = _('Unnamed')
        columns = []
        for __ in self.columns:
            columns.append('')

        try:
            columns[self._colPos['tg']] = list_to_string(self._ui.novel.locations[lcId].tags)
        except:
            pass
        nodeTags = []
        return title, columns, tuple(nodeTags)

    def _set_prjNote_display(self, pnId):
        title = self._ui.novel.projectNotes[pnId].title
        if not title:
            title = _('Unnamed')
        columns = []
        for __ in self.columns:
            columns.append('')
        nodeTags = []
        return title, columns, tuple(nodeTags)

    def _set_scene_display(self, scId, position=None):
        title = self._ui.novel.scenes[scId].title
        if not title:
            title = _('Unnamed')

        if self._ui.novel.scenes[scId].date is not None and self._ui.novel.scenes[scId].date != Scene.NULL_DATE:
            dispDate = self._ui.novel.scenes[scId].date
        else:
            if self._ui.novel.scenes[scId].day is not None:
                dispDate = f'{_("Day")} {self._ui.novel.scenes[scId].day}'
            else:
                dispDate = ''

        if self._ui.novel.scenes[scId].time is not None:
            dispTime = self._ui.novel.scenes[scId].time.rsplit(':', 1)[0]
        else:
            dispTime = ''

        points = []
        pointIds = string_to_list(self._ui.novel.scenes[scId].kwVar.get('Field_SceneAssoc', None))
        for ptId in pointIds:
            points.append(self._ui.novel.scenes[ptId].title)

        if self._ui.novel.scenes[scId].lastsDays and self._ui.novel.scenes[scId].lastsDays != '0':
            days = f'{self._ui.novel.scenes[scId].lastsDays}d '
        else:
            days = ''
        if self._ui.novel.scenes[scId].lastsHours and self._ui.novel.scenes[scId].lastsHours != '0':
            hours = f'{self._ui.novel.scenes[scId].lastsHours}h '
        else:
            hours = ''
        if self._ui.novel.scenes[scId].lastsMinutes and self._ui.novel.scenes[scId].lastsMinutes != '0':
            minutes = f'{self._ui.novel.scenes[scId].lastsMinutes}min'
        else:
            minutes = ''

        columns = []
        for __ in self.columns:
            columns.append('')
        nodeTags = []
        if self._ui.novel.scenes[scId].doNotExport:
            nodeTags.append('not exported')
        elif self._ui.novel.scenes[scId].scType == 2:
            nodeTags.append('todo')

            arcs = self._ui.novel.scenes[scId].scnArcs
            if arcs is not None:
                columns[self._colPos['ac']] = arcs

            columns[self._colPos['pt']] = list_to_string(points)

        elif self._ui.novel.scenes[scId].scType == 1:
            nodeTags.append('notes')
            columns[self._colPos['dt']] = dispDate
            columns[self._colPos['tm']] = dispTime
            columns[self._colPos['dr']] = f'{days}{hours}{minutes}'

        else:
            positionStr = ''
            if self._ui.novel.scenes[scId].scType == 3:
                nodeTags.append('unused')
            else:
                if self._ui.coloringMode == 1:
                    nodeTags.append(Scene.STATUS[self._ui.novel.scenes[scId].status])
                elif self._ui.coloringMode == 2:
                    try:
                        workPhase = int(self._ui.novel.kwVar['Field_WorkPhase'])
                    except:
                        workPhase = 0
                        nodeTags.append('On_schedule')
                    else:
                        if self._ui.novel.scenes[scId].status == workPhase:
                            nodeTags.append('On_schedule')
                        elif self._ui.novel.scenes[scId].status < workPhase:
                            nodeTags.append('Behind_schedule')
                        else:
                            nodeTags.append('Before_schedule')
                elif self._ui.coloringMode == 3:
                    sceneMode = self._ui.novel.scenes[scId].scnStyle
                    if sceneMode:
                        nodeTags.append(sceneMode)
                try:
                    positionStr = f'{round(100 * position / self._wordsTotal, 1)}%'
                except:
                    pass
            columns[self._colPos['po']] = positionStr
            columns[self._colPos['wc']] = self._ui.novel.scenes[scId].wordCount
            columns[self._colPos['st']] = self._SCN_STATUS[self._ui.novel.scenes[scId].status]
            sceneMode = self._ui.novel.scenes[scId].scnStyle
            if sceneMode:
                sceneMode = _(sceneMode)
            else:
                sceneMode = _('staged')
            columns[self._colPos['sy']] = sceneMode
            try:
                columns[self._colPos['vp']] = self._ui.novel.characters[self._ui.novel.scenes[scId].characters[0]].title
            except:
                columns[self._colPos['vp']] = _('N/A')
            if self._ui.novel.scenes[scId].kwVar.get('Field_CustomAR', None):
                columns[self._colPos['ar']] = _('C')
            elif self._ui.novel.scenes[scId].isReactionScene:
                columns[self._colPos['ar']] = _('R')
            else:
                columns[self._colPos['ar']] = _('A')

            columns[self._colPos['dt']] = dispDate
            columns[self._colPos['tm']] = dispTime
            columns[self._colPos['dr']] = f'{days}{hours}{minutes}'

            arcs = self._ui.novel.scenes[scId].scnArcs
            if arcs is not None:
                columns[self._colPos['ac']] = arcs

            columns[self._colPos['pt']] = list_to_string(points)

        if self._ui.novel.scenes[scId].notes:
            columns[self._colPos['nt']] = _('N')

        try:
            columns[self._colPos['tg']] = list_to_string(self._ui.novel.scenes[scId].tags)
        except:
            pass
        return title, columns, tuple(nodeTags)

    def _set_scn_status(self, nodes, scnStatus):
        if self._ui.check_lock():
            return

        has_changed = False
        for node in nodes:
            if node.startswith(self.SCENE_PREFIX):
                if  self._ui.novel.scenes[node[2:]].status != scnStatus:
                    self._ui.novel.scenes[node[2:]].status = scnStatus
                    has_changed = True
            elif node.startswith(self.CHAPTER_PREFIX) or node.startswith(self.PART_PREFIX) or node.startswith(self.NV_ROOT):
                self.tree.item(node, open=True)

                self._set_scn_status(self.tree.get_children(node), scnStatus)
        if has_changed:
            self.update_prj_structure()
            self.refresh_tree()

    def _set_scn_mode(self, nodes, scnMode):
        if self._ui.check_lock():
            return

        has_changed = False
        for node in nodes:
            if node.startswith(self.SCENE_PREFIX):
                if  self._ui.novel.scenes[node[2:]].scnStyle != scnMode:
                    self._ui.novel.scenes[node[2:]].scnStyle = scnMode
                    has_changed = True
            elif node.startswith(self.CHAPTER_PREFIX) or node.startswith(self.PART_PREFIX) or node.startswith(self.NV_ROOT):
                self.tree.item(node, open=True)

                self._set_scn_mode(self.tree.get_children(node), scnMode)
        if has_changed:
            self.update_prj_structure()

    def _set_type(self, nodes, newType):
        if self._ui.check_lock():
            return

        has_changed = False
        for node in nodes:
            if node.startswith(self.SCENE_PREFIX):
                scene = self._ui.novel.scenes[node[2:]]
                if scene.scType != newType:
                    scene.scType = newType
                    has_changed = True
            elif node.startswith(self.CHAPTER_PREFIX) or node.startswith(self.PART_PREFIX):
                self.tree.item(node, open=True)
                chapter = self._ui.novel.chapters[node[2:]]
                if chapter.isTrash:
                    newType = 3
                if chapter.chType != newType:
                    chapter.chType = newType
                    has_changed = True

                self._set_type(self.tree.get_children(node), newType)
        if has_changed:
            self.update_prj_structure()
            self.refresh_tree()

from tkinter import ttk
from tkinter import font as tkFont
from tkinter import font as tkFont
from tkinter import ttk


class RichTextTk(tk.Text):
    H1_TAG = 'h1'
    H2_TAG = 'h2'
    H3_TAG = 'h3'
    ITALIC_TAG = 'italic'
    BOLD_TAG = 'bold'
    CENTER_TAG = 'center'
    BULLET_TAG = 'bullet'

    H1_SIZE = 1.2
    H2_SIZE = 1.1
    H3_SIZE = 1.0
    H1_SPACING = 2
    H2_SPACING = 2
    H3_SPACING = 1.5
    CENTER_SPACING = 1.5

    def __init__(self, master=None, **kw):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        defaultFont = tkFont.nametofont(self.cget('font'))

        em = defaultFont.measure('m')
        defaultSize = defaultFont.cget('size')
        boldFont = tkFont.Font(**defaultFont.configure())
        italicFont = tkFont.Font(**defaultFont.configure())
        h1Font = tkFont.Font(**defaultFont.configure())
        h2Font = tkFont.Font(**defaultFont.configure())
        h3Font = tkFont.Font(**defaultFont.configure())

        boldFont.configure(weight='bold')
        italicFont.configure(slant='italic')
        h1Font.configure(size=int(defaultSize * self.H1_SIZE), weight='bold')
        h2Font.configure(size=int(defaultSize * self.H2_SIZE), weight='bold')
        h3Font.configure(size=int(defaultSize * self.H3_SIZE), slant='italic')

        self.tag_configure(self.BOLD_TAG, font=boldFont)
        self.tag_configure(self.ITALIC_TAG, font=italicFont)
        self.tag_configure(self.H1_TAG, font=h1Font, spacing3=defaultSize,
                           justify='center', spacing1=defaultSize * self.H1_SPACING)
        self.tag_configure(self.H2_TAG, font=h2Font, spacing3=defaultSize,
                           justify='center', spacing1=defaultSize * self.H2_SPACING)
        self.tag_configure(self.H3_TAG, font=h3Font, spacing3=defaultSize,
                           justify='center', spacing1=defaultSize * self.H3_SPACING)
        self.tag_configure(self.CENTER_TAG, justify='center', spacing1=defaultSize * self.CENTER_SPACING)

        lmargin2 = em + defaultFont.measure('\u2022 ')
        self.tag_configure(self.BULLET_TAG, lmargin1=em, lmargin2=lmargin2)

    def insert_bullet(self, index, text):
        self.insert(index, f'\u2022 {text}', self.BULLET_TAG)


class RichTextYw(RichTextTk):
    H1_NOTES_TAG = 'h1Notes'
    H1_TODO_TAG = 'h1Todo'
    H1_UNUSED_TAG = 'h1Unused'
    H2_NOTES_TAG = 'h2Notes'
    H2_TODO_TAG = 'h2Todo'
    H2_UNUSED_TAG = 'h2Unused'
    H3_NOTES_TAG = 'h3Notes'
    H3_TODO_TAG = 'h3Todo'
    H3_UNUSED_TAG = 'h3Unused'
    TODO_TAG = 'todo'
    NOTES_TAG = 'notes'
    UNUSED_TAG = 'unused'

    def __init__(self, *args, **kwargs):
        super().__init__(*args,
                height=20,
                width=60,
                spacing1=10,
                spacing2=2,
                wrap='word',
                padx=10,
                bg=kwargs['color_text_bg'],
                fg=kwargs['color_text_fg'],
                )
        defaultFont = tkFont.nametofont(self.cget('font'))

        defaultSize = defaultFont.cget('size')
        boldFont = tkFont.Font(**defaultFont.configure())
        italicFont = tkFont.Font(**defaultFont.configure())
        h1Font = tkFont.Font(**defaultFont.configure())
        h2Font = tkFont.Font(**defaultFont.configure())
        h3Font = tkFont.Font(**defaultFont.configure())

        boldFont.configure(weight='bold')
        italicFont.configure(slant='italic')
        h1Font.configure(size=int(defaultSize * self.H1_SIZE),
                         weight='bold',
                         )
        h2Font.configure(size=int(defaultSize * self.H2_SIZE),
                         weight='bold',
                         )
        h3Font.configure(size=int(defaultSize * self.H3_SIZE),
                         slant='italic',
                         )
        self.tag_configure(self.H1_TAG,
                           font=h1Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_chapter'],
                           justify='center',
                           spacing1=defaultSize * self.H1_SPACING,
                           )
        self.tag_configure(self.H1_NOTES_TAG,
                           font=h1Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_notes'],
                           justify='center',
                           spacing1=defaultSize * self.H1_SPACING,
                           )
        self.tag_configure(self.H1_TODO_TAG,
                           font=h1Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_todo'],
                           justify='center',
                           spacing1=defaultSize * self.H1_SPACING,
                           )
        self.tag_configure(self.H1_UNUSED_TAG,
                           font=h1Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_unused'],
                           justify='center',
                           spacing1=defaultSize * self.H1_SPACING,
                           )
        self.tag_configure(self.H2_TAG,
                           font=h2Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_chapter'],
                           justify='center',
                           spacing1=defaultSize * self.H2_SPACING,
                           )
        self.tag_configure(self.H2_NOTES_TAG,
                           font=h2Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_notes'],
                           justify='center',
                           spacing1=defaultSize * self.H2_SPACING,
                           )
        self.tag_configure(self.H2_TODO_TAG,
                           font=h2Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_todo'],
                           justify='center',
                           spacing1=defaultSize * self.H2_SPACING,
                           )
        self.tag_configure(self.H2_UNUSED_TAG,
                           font=h2Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_unused'],
                           justify='center',
                           spacing1=defaultSize * self.H2_SPACING,
                           )
        self.tag_configure(self.H3_NOTES_TAG,
                           font=h3Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_notes'],
                           justify='center',
                           spacing1=defaultSize * self.H3_SPACING,
                           )
        self.tag_configure(self.H3_TODO_TAG,
                           font=h3Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_todo'],
                           justify='center',
                           spacing1=defaultSize * self.H3_SPACING,
                           )
        self.tag_configure(self.H3_UNUSED_TAG,
                           font=h3Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_unused'],
                           justify='center',
                           spacing1=defaultSize * self.H3_SPACING,
                           )
        self.tag_configure(self.NOTES_TAG,
                           foreground=kwargs['color_notes'],
                           )
        self.tag_configure(self.TODO_TAG,
                           foreground=kwargs['color_todo'],
                           )
        self.tag_configure(self.UNUSED_TAG,
                           foreground=kwargs['color_unused'],
                           )



class ContentsViewer(RichTextYw):

    def __init__(self, ui, parent, **kwargs):
        self._ui = ui

        super().__init__(parent, **kwargs)
        self.showMarkup = tk.BooleanVar(parent, value=kwargs['show_markup'])
        ttk.Checkbutton(parent, text=_('Show markup'), variable=self.showMarkup).pack(anchor='w')
        self.showMarkup.trace('w', self.update)
        self._textMarks = {}
        self._index = '1.0'

    def reset_view(self):
        self.config(state='normal')
        self.delete('1.0', 'end')
        self.config(state='disabled')

    def see(self, idStr):
        try:
            self._index = self._textMarks[idStr]
            super().see(self._index)
        except KeyError:
            pass

    def update(self, event=None, *args):
        self.reset_view()
        self.view_text()
        try:
            super().see(self._index)
        except KeyError:
            pass

    def view_text(self):

        def convert_from_yw(text):
            if not self.showMarkup.get():
                text = re.sub('\[.+?\]|^\> ', '', text)
            return text

        taggedText = []
        for chId in self._ui.novel.srtChapters:
            chapter = self._ui.novel.chapters[chId]
            taggedText.append(f'ch{chId}')
            if chapter.chLevel == 0:
                if chapter.chType == 0:
                    headingTag = RichTextYw.H2_TAG
                elif chapter.chType == 1:
                    headingTag = RichTextYw.H2_NOTES_TAG
                elif chapter.chType == 2:
                    headingTag = RichTextYw.H2_TODO_TAG
                if chapter.chType == 3:
                    headingTag = RichTextYw.H2_UNUSED_TAG
            else:
                if chapter.chType == 0:
                    headingTag = RichTextYw.H1_TAG
                elif chapter.chType == 1:
                    headingTag = RichTextYw.H1_NOTES_TAG
                elif chapter.chType == 2:
                    headingTag = RichTextYw.H1_TODO_TAG
                if chapter.chType == 3:
                    headingTag = RichTextYw.H1_UNUSED_TAG

            if chapter.title:
                heading = f'{chapter.title}\n'
            else:
                    heading = f"[{_('Unnamed')}]\n"
            taggedText.append((heading, headingTag))

            for scId in self._ui.novel.chapters[chId].srtScenes:
                scene = self._ui.novel.scenes[scId]
                if scene.doNotExport:
                    continue

                taggedText.append(f'sc{scId}')
                textTag = ''
                if scene.scType == 2:
                    headingTag = RichTextYw.H3_TODO_TAG
                    textTag = RichTextYw.TODO_TAG
                elif scene.scType == 1:
                    headingTag = RichTextYw.H3_NOTES_TAG
                    textTag = RichTextYw.NOTES_TAG
                elif scene.scType == 3:
                    headingTag = RichTextYw.H3_UNUSED_TAG
                    textTag = RichTextYw.UNUSED_TAG
                else:
                    headingTag = RichTextYw.H3_TAG
                if scene.title:
                    heading = f'[{scene.title}]\n'
                else:
                    heading = f"[{_('Unnamed')}]\n"
                taggedText.append((heading, headingTag))

                if scene.sceneContent:
                    taggedText.append((convert_from_yw(f'{scene.sceneContent}\n'), textTag))

        if not taggedText:
            taggedText.append(('(No text available)', RichTextYw.ITALIC_TAG))
        self._textMarks = {}
        self.config(state='normal')
        self.delete('1.0', 'end')
        for entry in taggedText:
            if len(entry) == 2:
                text, tag = entry
                self.insert('end', text, tag)
            else:
                index = f"{self.count('1.0', 'end', 'lines')[0]}.0"
                self._textMarks[entry] = index
        self.config(state='disabled')

from tkinter import ttk
from tkinter import ttk


class TextBox(tk.Text):

    def __init__(self, master=None, scrollbar=True, **kw):
        if kw.get('font', None) is None:
            kw['font'] = 'Courier 10'
        if scrollbar:
            self.frame = ttk.Frame(master)
            self.vbar = ttk.Scrollbar(self.frame)
            self.vbar.pack(side='right', fill='y')

            kw.update({'yscrollcommand': self.vbar.set})
            tk.Text.__init__(self, self.frame, **kw)
            self.pack(side='left', fill='both', expand=True)
            self.vbar['command'] = self.yview

            text_meths = vars(tk.Text).keys()
            methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
            methods = methods.difference(text_meths)

            for m in methods:
                if m[0] != '_' and m != 'config' and m != 'configure':
                    setattr(self, m, getattr(self.frame, m))
        else:
            tk.Text.__init__(self, master, **kw)

        self.hasChanged = False
        self.bind('<KeyRelease>', self._on_edit)

    def clear(self):
        self.delete('1.0', 'end')
        self.hasChanged = False

    def get_text(self):
        return self.get('1.0', 'end').strip(' \n')

    def set_text(self, text):
        self.clear()
        if text:
            self.insert('end', text)
            self.edit_reset()

    def _on_edit(self, event=None):
        self.hasChanged = True



class IndexCard(tk.Frame):

    def __init__(self, master=None, cnf={}, fg='black', bg='white', font=None, scrollbar=True, **kw):
        super().__init__(master=master, cnf=cnf, **kw)
        self.title = tk.StringVar(value='')
        titleEntry = tk.Entry(self,
                              bg=bg,
                              bd=0,
                              textvariable=self.title,
                              relief='flat',
                              font=font,
                              )
        titleEntry.config({'background': bg,
                           'foreground': fg,
                           'insertbackground': fg,
                           })
        titleEntry.pack(fill='x', ipady=6)

        tk.Frame(self, bg='red', height=1, bd=0).pack(fill='x')
        tk.Frame(self, bg=bg, height=1, bd=0).pack(fill='x')

        self.bodyBox = TextBox(self,
                scrollbar=scrollbar,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                padx=5,
                pady=5,
                bg=bg,
                fg=fg,
                insertbackground=fg,
                font=font,
                )
        self.bodyBox.pack(fill='both', expand=True)



class BasicView(ttk.Frame):

    _LBL_X = 10

    def __init__(self, ui, parent):
        super().__init__(parent)

        self._ui = ui
        self._element = None
        self._tagsStr = ''
        self._parent = parent

        self._propertiesFrame = ttk.Frame(self)
        self._propertiesFrame.pack(expand=True, fill='both')

        self._create_frames()

    def apply_changes(self):
        if self._element is not None:

            title = self._indexCard.title.get()
            if title or self._element.title:
                if self._element.title != title:
                    self._element.title = title.strip()
                    self._ui.isModified = True

            if self._indexCard.bodyBox.hasChanged:
                desc = self._indexCard.bodyBox.get_text()
                if desc or self._element.desc:
                    if self._element.desc != desc:
                        self._element.desc = desc
                        self._ui.isModified = True

            if hasattr(self._element, 'notes') and self._notesWindow.hasChanged:
                notes = self._notesWindow.get_text()
                if hasattr(self._element, 'notes'):
                    if notes or self._element.notes:
                        if self._element.notes != notes:
                            self._element.notes = notes
                            self._ui.isModified = True

        if self._ui.isModified:
            self._ui.tv.update_prj_structure()

    def hide(self):
        self.pack_forget()

    def set_data(self, element):
        self._tagsStr = ''
        self._element = element
        if self._element is not None:

            if self._element.title is not None:
                self._indexCard.title.set(self._element.title)
            else:
                self._indexCard.title.set('')

            self._indexCard.bodyBox.clear()
            self._indexCard.bodyBox.set_text(self._element.desc)

            if hasattr(self._element, 'notes'):
                self._notesWindow.clear()
                self._notesWindow.set_text(self._element.notes)

    def show(self):
        self.pack(expand=True, fill='both')

    def _create_button_bar(self):
        self._buttonBar = ttk.Frame(self)
        self._buttonBar.pack(fill='x')

        ttk.Button(self._buttonBar, text=_('Previous'), command=self._load_prev).pack(side='left', fill='x', expand=True)

        ttk.Button(self._buttonBar, text=_('Apply changes'), command=self.apply_changes).pack(side='left', fill='x', expand=True)

        ttk.Button(self._buttonBar, text=_('Next'), command=self._load_next).pack(side='left', fill='x', expand=True)

    def _create_element_info_window(self):
        self._elementInfoWindow = ttk.Frame(self._propertiesFrame)
        self._elementInfoWindow.pack(fill='x')

    def _create_frames(self):
        pass

    def _create_index_card(self):
        self._indexCard = IndexCard(self._propertiesFrame,
                                    bd=2,
                                    fg=self._ui.kwargs['color_text_fg'],
                                    bg=self._ui.kwargs['color_text_bg'],
                                    relief='ridge'
                                    )
        self._indexCard.bodyBox['height'] = self._ui.kwargs['index_card_height']
        self._indexCard.pack(expand=False, fill='both')

    def _create_notes_window(self):
        self._notesWindow = TextBox(self._propertiesFrame,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                height=0,
                width=10,
                padx=5,
                pady=5,
                bg=self._ui.kwargs['color_notes_bg'],
                fg=self._ui.kwargs['color_notes_fg'],
                insertbackground=self._ui.kwargs['color_notes_fg'],
                )
        self._notesWindow.pack(expand=True, fill='both')

    def _load_next(self):
        thisNode = self._ui.tv.tree.selection()[0]
        nextNode = self._ui.tv.next_node(thisNode, '')
        if nextNode:
            self._ui.tv.tree.see(nextNode)
            self._ui.tv.tree.selection_set(nextNode)

    def _load_prev(self):
        thisNode = self._ui.tv.tree.selection()[0]
        prevNode = self._ui.tv.prev_node(thisNode, '')
        if prevNode:
            self._ui.tv.tree.see(prevNode)
            self._ui.tv.tree.selection_set(prevNode)

    def _update_field_bool(self, tkValue, fieldname):
        entry = tkValue.get()
        if entry:
            value = '1'
        else:
            value = None
        if self._element.kwVar.get(fieldname, None) or value:
            if self._element.kwVar.get(fieldname, None) != value:
                self._element.kwVar[fieldname] = value
                return True
        return False

    def _update_field_str(self, tkValue, fieldname):
        entry = tkValue.get()
        if self._element.kwVar.get(fieldname, None) or entry:
            if self._element.kwVar.get(fieldname, None) != entry:
                self._element.kwVar[fieldname] = entry
                return True
        return False

from tkinter import ttk
from shutil import copyfile
from tkinter import filedialog


def open_document(document):
    try:
        os.startfile(norm_path(document))
    except:
        try:
            os.system('xdg-open "%s"' % norm_path(document))
        except:
            try:
                os.system('open "%s"' % norm_path(document))
            except:
                pass
from tkinter import ttk


class LabelEntry(ttk.Frame):

    def __init__(self, parent, text, textvariable, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._label = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._label.pack(side='left')
        self._entry = ttk.Entry(self, textvariable=textvariable)
        self._entry.pack(side='left', fill='x', expand=True)

    def set(self, value):
        if value is None:
            value = ''
        self._entry.set(value)

    def configure(self, text=None):
        if text is not None:
            self._label['text'] = text


class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)


class WorldElementView(BasicView):

    def __init__(self, ui, parent):
        super(). __init__(ui, parent)

        self._fullNameFrame = ttk.Frame(self._elementInfoWindow)
        self._fullNameFrame.pack(anchor='w', fill='x')

        self._aka = MyStringVar()
        self._akaEntry = LabelEntry(self._elementInfoWindow, text=_('AKA'), textvariable=self._aka, lblWidth=self._LBL_X).pack(anchor='w', pady=2)

        self._tags = MyStringVar()
        LabelEntry(self._elementInfoWindow, text=_('Tags'), textvariable=self._tags, lblWidth=self._LBL_X).pack(anchor='w', pady=2)

    def apply_changes(self):

        aka = self._aka.get()
        if aka or self._element.aka:
            if self._element.aka != aka:
                self._element.aka = aka.strip()
                self._ui.isModified = True
        if self._ui.isModified:
            self._ui.tv.update_prj_structure()

        newTags = self._tags.get()
        if self._tagsStr or newTags:
            if newTags != self._tagsStr:
                self._element.tags = string_to_list(newTags)
                self._ui.isModified = True

        super().apply_changes()

    def set_data(self, element):
        super().set_data(element)

        self._aka.set(self._element.aka)

        if self._element.tags is not None:
            self._tagsStr = list_to_string(self._element.tags)
        else:
            self._tagsStr = ''
        self._tags.set(self._tagsStr)

        if self._element.image:
            self._img_show_button.state(['!disabled'])
            self._img_clear_button.state(['!disabled'])
        else:
            self._img_show_button.state(['disabled'])
            self._img_clear_button.state(['disabled'])

    def _create_image_window(self):
        self._imageWindow = ttk.Frame(self._propertiesFrame)
        self._imageWindow.pack(fill='x')
        ttk.Separator(self._imageWindow, orient='horizontal').pack(fill='x')
        self._img_show_button = ttk.Button(self._imageWindow, text=_('Show image'), command=self._show_image)
        self._img_show_button.pack(side='left')
        self._img_select_button = ttk.Button(self._imageWindow, text=_('Select image'), command=self._select_image)
        self._img_select_button.pack(side='left')
        self._img_clear_button = ttk.Button(self._imageWindow, text=_('Clear image'), command=self._clear_image)
        self._img_clear_button.pack(side='left')

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_image_window()
        self._create_button_bar()

    def _clear_image(self):
        if self._element.image is not None:
            self._element.image = None
            self._img_show_button.state(['disabled'])
            self._img_clear_button.state(['disabled'])
            self._ui.isModified = True

    def _select_image(self):
        fileType = _('Image file')
        fileTypes = [(fileType, '.jpg'),
                     (fileType, '.jpeg'),
                     (fileType, '.png'),
                     (fileType, '.gif'),
                     (_('All files'), '.*')]
        selectedPath = filedialog.askopenfilename(filetypes=fileTypes)
        if selectedPath:
            __, imageFile = os.path.split(selectedPath)
            projectDir, __ = os.path.split(self._ui.prjFile.filePath)
            imagePath = f'{projectDir}/Images/{imageFile}'
            if not selectedPath == imagePath:
                try:
                    os.makedirs(f'{projectDir}/Images', exist_ok=True)
                    copyfile(selectedPath, imagePath)
                    self._ui.show_info(f"{_('Image for')} {self._element.title}: {norm_path(imagePath)}", title=_('Image copied'))
                except Exception as ex:
                    self._ui.show_error(str(ex), title=_('Cannot copy image'))
                    return
            self._element.image = imageFile
            self._img_show_button.state(['!disabled'])
            self._img_clear_button.state(['!disabled'])
            self._ui.isModified = True

    def _show_image(self):
        if self._element.image:
            projectDir, __ = os.path.split(self._ui.prjFile.filePath)
            imagePath = f'{projectDir}/Images/{self._element.image}'
            if os.path.isfile(imagePath):
                open_document(imagePath)
            else:
                self._ui.show_error(f"{_('File not found')}: {norm_path(imagePath)}", title=_('Cannot show image'))
                self._clear_image()

from tkinter import ttk
from tkinter import ttk


class LabelCombo(ttk.Frame):

    def __init__(self, parent, text, textvariable, values, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._label = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._label.pack(side='left')
        self._combo = ttk.Combobox(self, textvariable=textvariable, values=values)
        self._combo.pack(side='left', fill='x', expand=True)

    def current(self):
        return self._combo.current()

    def configure(self, text=None, values=None):
        if text is not None:
            self._label['text'] = text
        if values is not None:
            self._combo['values'] = values
from tkinter import ttk


class LabelDisp(ttk.Frame):

    def __init__(self, parent, text, textvariable, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._leftLabel = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._leftLabel.pack(side='left')
        self._rightLabel = ttk.Label(self, textvariable=textvariable, anchor='w')
        self._rightLabel.pack(side='left', fill='x', expand=True)

    def configure(self, text=None):
        if text is not None:
            self._leftLabel['text'] = text
from tkinter import ttk


class FoldingFrame(ttk.Frame):
    _PREFIX_SHOW = '▽  '
    _PREFIX_HIDE = '▷  '

    def __init__(self, parent, buttonText, command, **kw):
        super().__init__(parent, **kw)
        self.buttonText = buttonText
        self._toggleButton = ttk.Label(parent)
        self._toggleButton['text'] = f'{self._PREFIX_HIDE}{self.buttonText}'
        self._toggleButton.pack(fill='x', pady=2)
        self._toggleButton.bind('<Button-1>', command)

    def show(self, event=None):
        self._toggleButton['text'] = f'{self._PREFIX_SHOW}{self.buttonText}'
        self.pack(after=self._toggleButton, fill='x', pady=5)

    def hide(self, event=None):
        self._toggleButton['text'] = f'{self._PREFIX_HIDE}{self.buttonText}'
        self.pack_forget()



class ProjectView(BasicView):

    def __init__(self, ui, parent):
        super(). __init__(ui, parent)

        self._authorName = MyStringVar()
        LabelEntry(self._elementInfoWindow, text=_('Author'), textvariable=self._authorName, lblWidth=20).pack(anchor='w')

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._languageFrame = FoldingFrame(self._elementInfoWindow, _('Document language'), self._toggle_languageFrame)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._languageCode = MyStringVar()
        LabelEntry(self._languageFrame, text=_('Language code'),
                   textvariable=self._languageCode, lblWidth=20).pack(anchor='w')
        self._countryCode = MyStringVar()
        LabelEntry(self._languageFrame, text=_('Country code'),
                   textvariable=self._countryCode, lblWidth=20).pack(anchor='w')

        self._numberingFrame = FoldingFrame(self._elementInfoWindow, _('Auto numbering'), self._toggle_numberingFrame)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._renChapters = tk.BooleanVar(value=False)
        ttk.Checkbutton(self._numberingFrame, text=_('Auto number chapters when refreshing the tree'),
                        variable=self._renChapters, onvalue=True, offvalue=False).pack(anchor='w')

        self._chHdPrefix = MyStringVar()
        LabelEntry(self._numberingFrame, text=_('Chapter number prefix'),
                   textvariable=self._chHdPrefix, lblWidth=20).pack(anchor='w')

        self._chHdSuffix = MyStringVar()
        LabelEntry(self._numberingFrame, text=_('Chapter number suffix'),
                   textvariable=self._chHdSuffix, lblWidth=20).pack(anchor='w')

        self._romanChapters = tk.BooleanVar()
        ttk.Checkbutton(self._numberingFrame, text=_('Use Roman chapter numbers'),
                        variable=self._romanChapters, onvalue=True, offvalue=False).pack(anchor='w')

        self._renWithinParts = tk.BooleanVar()
        ttk.Checkbutton(self._numberingFrame, text=_('Reset chapter number when starting a new part'),
                        variable=self._renWithinParts, onvalue=True, offvalue=False).pack(anchor='w')

        self._renParts = tk.BooleanVar()
        ttk.Checkbutton(self._numberingFrame, text=_('Auto number parts when refreshing the tree'),
                        variable=self._renParts, onvalue=True, offvalue=False).pack(anchor='w')

        self._ptHdPrefix = MyStringVar()
        LabelEntry(self._numberingFrame, text=_('Part number prefix'),
                   textvariable=self._ptHdPrefix, lblWidth=20).pack(anchor='w')

        self._ptHdSuffix = MyStringVar()
        LabelEntry(self._numberingFrame, text=_('Part number suffix'),
                   textvariable=self._ptHdSuffix, lblWidth=20).pack(anchor='w')

        self._romanParts = tk.BooleanVar()
        ttk.Checkbutton(self._numberingFrame, text=_('Use Roman part numbers'), variable=self._romanParts, onvalue=True, offvalue=False).pack(anchor='w')

        self._renamingsFrame = FoldingFrame(self._elementInfoWindow, _('Renamings'), self._toggle_renamingsFrame)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._customGoal = MyStringVar()
        LabelEntry(self._renamingsFrame, text=_('Custom Goal'),
                   textvariable=self._customGoal, lblWidth=20).pack(anchor='w')

        self._customConflict = MyStringVar()
        LabelEntry(self._renamingsFrame, text=_('Custom Conflict'),
                   textvariable=self._customConflict, lblWidth=20).pack(anchor='w')

        self._customOutcome = MyStringVar()
        LabelEntry(self._renamingsFrame, text=_('Custom Outcome'),
                   textvariable=self._customOutcome, lblWidth=20).pack(anchor='w')

        ttk.Separator(self._renamingsFrame, orient='horizontal').pack(fill='x')

        self._customChrBio = MyStringVar()
        LabelEntry(self._renamingsFrame, text=_('Custom chara Bio'),
                   textvariable=self._customChrBio, lblWidth=20).pack(anchor='w')

        self._customChrGoals = MyStringVar()
        LabelEntry(self._renamingsFrame, text=_('Custom chara Goals'),
                   textvariable=self._customChrGoals, lblWidth=20).pack(anchor='w')

        self._progressFrame = FoldingFrame(self._elementInfoWindow, _('Writing progress'), self._toggle_progressFrame)

        self._saveWordCount = tk.BooleanVar()
        ttk.Checkbutton(self._progressFrame, text=_('Log writing progress'),
                        variable=self._saveWordCount, onvalue=True, offvalue=False).pack(anchor='w')

        ttk.Separator(self._progressFrame, orient='horizontal').pack(fill='x')

        self._wordTarget = tk.IntVar()
        LabelEntry(self._progressFrame, text=_('Words to write'),
                   textvariable=self._wordTarget, lblWidth=20).pack(anchor='w')

        self._wordCountStart = tk.IntVar()
        LabelEntry(self._progressFrame, text=_('Starting count'),
                   textvariable=self._wordCountStart, lblWidth=20).pack(anchor='w')

        ttk.Button(self._progressFrame, text=_('Set actual wordcount as start'),
                  command=self._set_initial_wc).pack(pady=2)

        self._wordsWritten = MyStringVar()
        self._wordTarget.trace_add('write', self._update_wordsWritten)
        self._wordCountStart.trace_add('write', self._update_wordsWritten)
        LabelDisp(self._progressFrame, text=_('Words written'),
                  textvariable=self._wordsWritten, lblWidth=20).pack(anchor='w')

        ttk.Separator(self._progressFrame, orient='horizontal').pack(fill='x')

        self._totalUsed = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Used'),
                  textvariable=self._totalUsed, lblWidth=20).pack(anchor='w')
        self._totalOutline = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Outline'),
                  textvariable=self._totalOutline, lblWidth=20).pack(anchor='w')
        self._totalDraft = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Draft'),
                  textvariable=self._totalDraft, lblWidth=20).pack(anchor='w')
        self._total1stEdit = MyStringVar()
        LabelDisp(self._progressFrame, text=_('1st Edit'),
                  textvariable=self._total1stEdit, lblWidth=20).pack(anchor='w')
        self._total2ndEdit = MyStringVar()
        LabelDisp(self._progressFrame, text=_('2nd Edit'),
                  textvariable=self._total2ndEdit, lblWidth=20).pack(anchor='w')
        self._totalDone = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Done'),
                  textvariable=self._totalDone, lblWidth=20).pack(anchor='w')
        self._totalUnused = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Unused'),
                  textvariable=self._totalUnused, lblWidth=20).pack(anchor='w')
        self._totalWords = MyStringVar()
        LabelDisp(self._progressFrame, text=_('All'),
                  textvariable=self._totalWords, lblWidth=20).pack(anchor='w')

        self._phase = MyStringVar()
        self._phaseCombobox = LabelCombo(self._progressFrame, lblWidth=20, text=_('Work phase'), textvariable=self._phase, values=[])
        self._phaseCombobox.pack(anchor='w')

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        ttk.Button(self._elementInfoWindow, text=_('Apply changes'), command=self.apply_changes).pack(pady=5, padx=5, fill='x', expand=True)

        self._coverFile = None
        self._cover = tk.Label(self._elementInfoWindow)
        self._cover.pack()

    def apply_changes(self):
        title = self._indexCard.title.get()
        if title or self._element.title:
            if self._element.title != title:
                self._element.title = title.strip()
                self._ui.isModified = True
                self._ui.set_title()

        authorName = self._authorName.get()
        if authorName or self._element.authorName:
            if self._element.authorName != authorName:
                self._element.authorName = authorName.strip()
                self._ui.isModified = True
                self._ui.set_title()

        language = self._element.languageCode
        newLanguage = self._languageCode.get()
        if self._element.languageCode or newLanguage:
            if self._element.languageCode != newLanguage:
                self._element.languageCode = newLanguage
        country = self._element.countryCode
        newCountry = self._countryCode.get()
        if self._element.countryCode or newCountry:
            if self._element.countryCode != newCountry:
                self._element.countryCode = newCountry
        self._element.check_locale()
        if language != self._element.languageCode:
            self._ui.isModified = True
        else:
            self._languageCode.set(self._element.languageCode)
        if country != self._element.countryCode:
            self._ui.isModified = True
        else:
            self._countryCode.set(self._element.countryCode)

        if self._update_field_bool(self._renChapters, 'Field_RenumberChapters'):
            self._ui.isModified = True

        if self._update_field_str(self._chHdPrefix, 'Field_ChapterHeadingPrefix'):
            self._ui.isModified = True

        if self._update_field_str(self._chHdSuffix, 'Field_ChapterHeadingSuffix'):
            self._ui.isModified = True

        if self._update_field_bool(self._romanChapters, 'Field_RomanChapterNumbers'):
            self._ui.isModified = True

        if self._update_field_bool(self._renWithinParts, 'Field_RenumberWithinParts'):
            self._ui.isModified = True

        if self._update_field_bool(self._renParts, 'Field_RenumberParts'):
            self._ui.isModified = True

        if self._update_field_str(self._ptHdPrefix, 'Field_PartHeadingPrefix'):
            self._ui.isModified = True

        if self._update_field_str(self._ptHdSuffix, 'Field_PartHeadingSuffix'):
            self._ui.isModified = True

        if self._update_field_bool(self._romanParts, 'Field_RomanPartNumbers'):
            self._ui.isModified = True

        if self._update_field_str(self._customGoal, 'Field_CustomGoal'):
            self._ui.isModified = True

        if self._update_field_str(self._customConflict, 'Field_CustomConflict'):
            self._ui.isModified = True

        if self._update_field_str(self._customOutcome, 'Field_CustomOutcome'):
            self._ui.isModified = True

        if self._update_field_str(self._customChrBio, 'Field_CustomChrBio'):
            self._ui.isModified = True

        if self._update_field_str(self._customChrGoals, 'Field_CustomChrGoals'):
            self._ui.isModified = True

        if self._update_field_bool(self._saveWordCount, 'Field_SaveWordCount'):
            self._ui.isModified = True

        try:
            entry = self._wordTarget.get()
            if self._element.wordTarget or entry:
                if self._element.wordTarget != entry:
                    self._element.wordTarget = entry
                    self._ui.isModified = True
        except:
            pass
        try:
            entry = self._wordCountStart.get()
            if self._element.wordCountStart or entry:
                if self._element.wordCountStart != entry:
                    self._element.wordCountStart = entry
                    self._ui.isModified = True
        except:
            pass

        if not self._phaseCombobox.current():
            entry = None
        else:
            entry = str(self._phaseCombobox.current())
        if self._ui.novel.kwVar['Field_WorkPhase'] != entry:
            self._ui.novel.kwVar['Field_WorkPhase'] = entry
            self._ui.isModified = True
            self._ui.tv.refresh_tree()

        super().apply_changes()

    def set_data(self, element):
        super().set_data(element)

        self._authorName.set(self._element.authorName)

        if self._ui.kwargs['show_language_settings']:
            self._languageFrame.show()
        else:
            self._languageFrame.hide()

        self._languageCode.set(self._element.languageCode)

        self._countryCode.set(self._element.countryCode)

        renChapters = self._element.kwVar.get('Field_RenumberChapters', None) == '1'
        self._renChapters.set(renChapters)

        self._chHdPrefix.set(self._element.kwVar.get('Field_ChapterHeadingPrefix', ''))

        self._chHdSuffix = MyStringVar(value=self._element.kwVar.get('Field_ChapterHeadingSuffix', ''))

        romanChapters = self._element.kwVar.get('Field_RomanChapterNumbers', None) == '1'
        self._romanChapters.set(romanChapters)

        renWithinParts = self._element.kwVar.get('Field_RenumberWithinParts', None) == '1'
        self._renWithinParts.set(renWithinParts)

        renParts = self._element.kwVar.get('Field_RenumberParts', None) == '1'
        self._renParts.set(renParts)

        self._ptHdPrefix.set(self._element.kwVar.get('Field_PartHeadingPrefix', ''))

        self._ptHdSuffix.set(self._element.kwVar.get('Field_PartHeadingSuffix', ''))

        romanParts = self._element.kwVar.get('Field_RomanPartNumbers', None) == 1
        self._romanParts.set(romanParts)

        self._customGoal.set(self._element.kwVar.get('Field_CustomGoal', _('Goal')))

        self._customConflict.set(self._element.kwVar.get('Field_CustomConflict', _('Conflict')))

        self._customOutcome.set(self._element.kwVar.get('Field_CustomOutcome', _('Outcome')))

        self._customChrBio.set(self._element.kwVar.get('Field_CustomChrBio', _('Bio')))

        self._customChrGoals.set(self._element.kwVar.get('Field_CustomChrGoals', _('Goals')))

        saveWordCount = self._element.kwVar.get('Field_SaveWordCount', None) == '1'
        self._saveWordCount.set(saveWordCount)

        if self._ui.kwargs['show_writing_progress']:
            self._progressFrame.show()
        else:
            self._progressFrame.hide()

        self._wordTarget.set(self._element.wordTarget)

        self._wordCountStart.set(self._element.wordCountStart)

        normalWordsTotal, allWordsTotal = self._ui.prjFile.count_words()
        self._totalWords.set(allWordsTotal)
        self._totalUsed.set(normalWordsTotal)
        self._totalUnused.set(allWordsTotal - normalWordsTotal)
        statusCounts = self._ui.prjFile.get_status_counts()
        self._totalOutline.set(statusCounts[1])
        self._totalDraft.set(statusCounts[2])
        self._total1stEdit.set(statusCounts[3])
        self._total2ndEdit.set(statusCounts[4])
        self._totalDone.set(statusCounts[5])

        phases = [_('Undefined'), _('Outline'), _('Draft'), _('1st Edit'), _('2nd Edit'), _('Done')]
        self._phaseCombobox.configure(values=phases)
        try:
            workPhase = int(self._ui.novel.kwVar['Field_WorkPhase'])
        except:
            workPhase = 0
        self._phase.set(value=phases[workPhase])

    def show(self):
        try:
            coverFile = f'{os.path.splitext(self._ui.prjFile.filePath)[0]}.png'
            if self._coverFile != coverFile:
                self._coverFile = coverFile
                coverPic = tk.PhotoImage(file=coverFile)
                self._cover.configure(image=coverPic)
                self._cover.image = coverPic
        except:
            self._cover.configure(image=None)
            self._cover.image = None
        super().show()

    def _set_initial_wc(self):
        self._wordCountStart.set(self._ui.wordCount)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()

    def _toggle_languageFrame(self, event=None):
        if self._ui.kwargs['show_language_settings']:
            self._languageFrame.hide()
            self._ui.kwargs['show_language_settings'] = False
        else:
            self._languageFrame.show()
            self._ui.kwargs['show_language_settings'] = True

    def _toggle_numberingFrame(self, event=None):
        if self._ui.kwargs['show_auto_numbering']:
            self._numberingFrame.hide()
            self._ui.kwargs['show_auto_numbering'] = False
        else:
            self._numberingFrame.show()
            self._ui.kwargs['show_auto_numbering'] = True

    def _toggle_progressFrame(self, event=None):
        if self._ui.kwargs['show_writing_progress']:
            self._progressFrame.hide()
            self._ui.kwargs['show_writing_progress'] = False
        else:
            self._progressFrame.show()
            self._ui.kwargs['show_writing_progress'] = True

    def _toggle_renamingsFrame(self, event=None):
        if self._ui.kwargs['show_renamings']:
            self._renamingsFrame.hide()
            self._ui.kwargs['show_renamings'] = False
        else:
            self._renamingsFrame.show()
            self._ui.kwargs['show_renamings'] = True

    def _update_wordsWritten(self, n, m, x):
        try:
            ww = self._ui.wordCount - self._wordCountStart.get()
            wt = self._wordTarget.get()
            try:
                wp = f'({round(100*ww/wt)}%)'
            except ZeroDivisionError:
                wp = ''
            self._wordsWritten.set(f'{ww} {wp}')
        except:
            pass

from tkinter import ttk


class ChapterView(BasicView):

    def __init__(self, ui, parent):
        super(). __init__(ui, parent)

        self._noNumber = tk.BooleanVar()
        self._noNumberButton = ttk.Checkbutton(self._elementInfoWindow, variable=self._noNumber, onvalue=True, offvalue=False)

    def apply_changes(self):
        if self._element.isTrash:
            return

        if self._update_field_bool(self._noNumber, 'Field_NoNumber'):
            self._ui.isModified = True
        super().apply_changes()

    def set_data(self, element):
        super().set_data(element)

        noNumber = self._element.kwVar.get('Field_NoNumber', '') == '1'
        self._noNumber.set(noNumber)

        if self._element.isTrash:
            self._elementInfoWindow.pack_forget()
            return

        if not self._elementInfoWindow.winfo_manager():
            self._elementInfoWindow.pack(fill='x')

        if self._element.chType == 0:
            if self._element.chLevel == 1:
                labelText = _('Do not auto-number this part')
            else:
                labelText = _('Do not auto-number this chapter')
            self._noNumberButton.configure(text=labelText)
            if not self._noNumberButton.winfo_manager():
                self._noNumberButton.pack(anchor='w', pady=2)
        elif self._noNumberButton.winfo_manager():
            self._noNumberButton.pack_forget()

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_button_bar()

from tkinter import ttk


class TodoChapterView(BasicView):

    def __init__(self, ui, parent):
        super(). __init__(ui, parent)

        self._lastSelected = ''

        self._arcs = MyStringVar()
        self._arcsEntry = LabelEntry(self._elementInfoWindow, text=_('Arc name'), textvariable=self._arcs, lblWidth=22)
        self._arcsEntry.pack(anchor='w')

        self._arcFrame = ttk.Frame(self._elementInfoWindow)
        self._nrScenes = ttk.Label(self._arcFrame)
        self._nrScenes.pack(side='left')
        ttk.Button(self._arcFrame, text=_('Clear scene assignments'), command=self._removeArcRef).pack(padx=1, pady=2)

    def apply_changes(self):
        oldArc = self._element.kwVar['Field_ArcDefinition']
        newArc = self._arcs.get().replace(';', '')
        if oldArc or newArc:
            if oldArc != newArc:
                for scId in self._element.srtScenes:
                    self._ui.novel.scenes[scId].scnArcs = newArc

                if oldArc:
                    for scId in self._ui.novel.scenes:
                        if self._ui.novel.scenes[scId].scType == 0:
                            scnArcs = string_to_list(self._ui.novel.scenes[scId].scnArcs)
                            try:
                                scnArcs.remove(oldArc)
                            except ValueError:
                                pass
                            else:
                                scnArcs.append(newArc)
                                self._ui.novel.scenes[scId].scnArcs = list_to_string(scnArcs)

                self._element.kwVar['Field_ArcDefinition'] = newArc

                newTitle = f'{self._element.kwVar["Field_ArcDefinition"]} - {self._indexCard.title.get()}'
                self._indexCard.title.set(newTitle)
                self._ui.isModified = True

        super().apply_changes()

    def set_data(self, element):
        super().set_data(element)

        self._scenesAssigned = []
        arc = self._element.kwVar['Field_ArcDefinition']
        if arc:
            for scId in self._ui.novel.scenes:
                if self._ui.novel.scenes[scId].scType == 0:
                    if arc in string_to_list(self._ui.novel.scenes[scId].scnArcs):
                        self._scenesAssigned.append(scId)
        else:
            arc = ''

        self._arcs.set(arc)

        if len(self._scenesAssigned) > 0:
            self._nrScenes['text'] = f'{_("Number of scenes")}: {len(self._scenesAssigned)}'
            if not self._arcFrame.winfo_manager():
                self._arcFrame.pack(after=self._arcsEntry, fill='x')
        else:
            if self._arcFrame.winfo_manager():
                self._arcFrame.pack_forget()

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_button_bar()

    def _removeArcRef(self):
        self._lastSelected = self._ui.tv.tree.selection()[0]
        arc = self._arcs.get()
        if arc and self._ui.ask_yes_no(f'{_("Remove all scenes from the story arc")} "{arc}"?'):
            for scId in self._scenesAssigned:
                if self._ui.novel.scenes[scId].scnArcs is not None:
                    newArcs = []
                    arcs = string_to_list(self._ui.novel.scenes[scId].scnArcs)
                    for scArc in arcs:
                        if not scArc == arc:
                            newArcs.append(scArc)
                        else:
                            self._ui.isModified = True
                    self._ui.novel.scenes[scId].scnArcs = list_to_string(newArcs)
            self._scenesAssigned = []
            self._arcFrame.pack_forget()

            for scId in self._element.srtScenes:
                self._ui.novel.scenes[scId].kwVar['Field_SceneAssoc'] = None

            if self._ui.isModified:
                self._ui.tv.update_prj_structure()
                self._ui.tv.refresh_tree()
                self._ui.tv.tree.see(self._lastSelected)
                self._ui.tv.tree.selection_set(self._lastSelected)

from tkinter import ttk
from tkinter import ttk
from datetime import datetime
from datetime import date
from datetime import time
from datetime import timedelta
from tkinter import ttk


class SceneView(BasicView):
    _REL_Y = 2

    def __init__(self, ui, parent):
        super(). __init__(ui, parent)

        self._tags = MyStringVar()
        LabelEntry(self._elementInfoWindow, text=_('Tags'), textvariable=self._tags, lblWidth=self._LBL_X).pack(anchor='w', pady=2)

        self._sceneExtraFrame = ttk.Frame(self._elementInfoWindow)
        self._sceneExtraFrame.pack(anchor='w', fill='x')

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._relationFrame = FoldingFrame(self._elementInfoWindow, _('Relationships'), self._toggle_relationFrame)

        self._crTitles = ''
        self._characterLabel = ttk.Label(self._relationFrame, text=_('Characters'))
        self._characterLabel.pack(anchor='w')
        self._characterWindow = TextBox(self._relationFrame,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                height=self._REL_Y,
                padx=5,
                pady=5,
                bg=ui.kwargs['color_text_bg'],
                fg=ui.kwargs['color_text_fg'],
                insertbackground=ui.kwargs['color_text_fg'],
                )
        self._characterWindow.pack(fill='x')

        self._lcTitles = ''
        self._locationLabel = ttk.Label(self._relationFrame, text=_('Locations'))
        self._locationLabel.pack(anchor='w')
        self._locationWindow = TextBox(self._relationFrame,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                height=self._REL_Y,
                padx=5,
                pady=5,
                bg=ui.kwargs['color_text_bg'],
                fg=ui.kwargs['color_text_fg'],
                insertbackground=ui.kwargs['color_text_fg'],
                )
        self._locationWindow.pack(fill='x')

        self._itTitles = ''
        self._itemLabel = ttk.Label(self._relationFrame, text=_('Items'))
        self._itemLabel.pack(anchor='w')
        self._itemWindow = TextBox(self._relationFrame,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                height=self._REL_Y,
                padx=5,
                pady=5,
                bg=ui.kwargs['color_text_bg'],
                fg=ui.kwargs['color_text_fg'],
                insertbackground=ui.kwargs['color_text_fg'],
                )
        self._itemWindow.pack(fill='x')

    def apply_changes(self):

        newTags = self._tags.get()
        if self._tagsStr or newTags:
            if newTags != self._tagsStr:
                self._element.tags = string_to_list(newTags)
                self._ui.isModified = True

        if self._characterWindow.hasChanged:
            newCharacters = self._get_relation_id_list(self._characterWindow.get_text().strip(';'), self._crTitles, self._ui.novel.characters)
            if newCharacters is not None:
                if self._element.characters != newCharacters:
                    self._element.characters = newCharacters
                    self._ui.isModified = True

        if self._locationWindow.hasChanged:
            newLocations = self._get_relation_id_list(self._locationWindow.get_text().strip(';'), self._lcTitles, self._ui.novel.locations)
            if newLocations is not None:
                if self._element.locations != newLocations:
                    self._element.locations = newLocations
                    self._ui.isModified = True

        if self._itemWindow.hasChanged:
            newItems = self._get_relation_id_list(self._itemWindow.get_text().strip(';'), self._itTitles, self._ui.novel.items)
            if newItems is not None:
                if self._element.items != newItems:
                    self._element.items = newItems
                    self._ui.isModified = True

        super().apply_changes()

    def set_data(self, element):
        super().set_data(element)

        if self._element.tags is not None:
            self._tagsStr = list_to_string(self._element.tags)
        else:
            self._tagsStr = ''
        self._tags.set(self._tagsStr)

        if self._ui.kwargs['show_relationships']:
            self._relationFrame.show()
        else:
            self._relationFrame.hide()

        self._crTitles = self._get_relation_title_string(element.characters, self._ui.novel.characters)
        self._characterWindow.set_text(self._crTitles)

        self._lcTitles = self._get_relation_title_string(element.locations, self._ui.novel.locations)
        self._locationWindow.set_text(self._lcTitles)

        self._itTitles = self._get_relation_title_string(element.items, self._ui.novel.items)
        self._itemWindow.set_text(self._itTitles)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_notes_window()
        self._create_button_bar()

    def _get_relation_id_list(self, newTitleStr, oldTitleStr, elements):
        if newTitleStr or oldTitleStr:
            if oldTitleStr != newTitleStr:
                elemIds = []
                for elemTitle in string_to_list(newTitleStr):
                    for elemId in elements:
                        if elements[elemId].title == elemTitle:
                            elemIds.append(elemId)
                            break
                    else:
                        self._ui.show_error(f'{_("Wrong name")}: "{elemTitle}"', title=_('Input rejected'))
                return elemIds

        return None

    def _get_relation_title_string(self, elemIds, elements):
        elemTitles = []
        if elemIds:
            for elemId in elemIds:
                try:
                    elemTitles.append(elements[elemId].title)
                except:
                    pass
        titleStr = list_to_string(elemTitles)
        return titleStr

    def _toggle_relationFrame(self, event=None):
        if self._ui.kwargs['show_relationships']:
            self._relationFrame.hide()
            self._ui.kwargs['show_relationships'] = False
        else:
            self._relationFrame.show()
            self._ui.kwargs['show_relationships'] = True



class NotesSceneView(SceneView):
    _DATE_TIME_LBL_X = 15

    def __init__(self, ui, parent):
        super(). __init__(ui, parent)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._dateTimeFrame = FoldingFrame(self._elementInfoWindow, _('Date/Time'), self._toggle_dateTimeFrame)
        sceneStartFrame = ttk.Frame(self._dateTimeFrame)
        sceneStartFrame.pack(fill='x')
        ttk.Label(sceneStartFrame, text=_('Start')).pack(anchor='w')

        self._startDate = MyStringVar()
        LabelEntry(sceneStartFrame,
                   text=_('Date'),
                   textvariable=self._startDate,
                   lblWidth=self._DATE_TIME_LBL_X).pack(anchor='w')

        self._startTime = MyStringVar()
        LabelEntry(sceneStartFrame,
                   text=_('Time'),
                   textvariable=self._startTime,
                   lblWidth=self._DATE_TIME_LBL_X).pack(anchor='w')

        self._startDay = MyStringVar()
        LabelEntry(sceneStartFrame,
                   text=_('Day'),
                   textvariable=self._startDay,
                   lblWidth=self._DATE_TIME_LBL_X).pack(anchor='w')

        ttk.Button(sceneStartFrame,
                   text=_('Clear date/time'),
                   command=self._clear_start).pack(side='left', padx=1)

        ttk.Button(sceneStartFrame,
                   text=_('Generate'),
                   command=self._auto_set).pack(side='left', padx=1, pady=2)

        ttk.Separator(self._dateTimeFrame, orient='horizontal').pack(fill='x', pady=2)

        sceneDurationFrame = ttk.Frame(self._dateTimeFrame)
        sceneDurationFrame.pack(fill='x')
        ttk.Label(sceneDurationFrame, text=_('Duration')).pack(anchor='w')

        self._lastsDays = MyStringVar()
        LabelEntry(sceneDurationFrame,
                   text=_('Days'),
                   textvariable=self._lastsDays,
                   lblWidth=self._DATE_TIME_LBL_X).pack(anchor='w')

        self._lastsHours = MyStringVar()
        LabelEntry(sceneDurationFrame,
                   text=_('Hours'),
                   textvariable=self._lastsHours,
                   lblWidth=self._DATE_TIME_LBL_X).pack(anchor='w')

        self._lastsMinutes = MyStringVar()
        LabelEntry(sceneDurationFrame,
                   text=_('Minutes'),
                   textvariable=self._lastsMinutes,
                   lblWidth=self._DATE_TIME_LBL_X).pack(anchor='w')

        ttk.Button(sceneDurationFrame,
                   text=_('Clear duration'),
                   command=self._clear_duration).pack(side='left', padx=1, pady=2)

    def apply_changes(self):

        switchTimeMode = False

        newStartDate = self._startDate.get()
        if newStartDate or self._element.date:
            if newStartDate != self._element.date:
                try:
                    date.fromisoformat(newStartDate)
                except ValueError:
                    self._startDate.set(self._element.date)
                else:
                    self._element.date = newStartDate
                    if self._element.day and self._element.date:
                        switchTimeMode = True
                    self._ui.isModified = True

        newStartTime = self._startTime.get()
        if self._element.time is not None:
            dispTime = self._element.time.rsplit(':', 1)[0]
        else:
            dispTime = None
        if newStartTime or dispTime:
            if newStartTime != dispTime:
                try:
                    time.fromisoformat(newStartTime)
                except ValueError:
                    pass
                else:
                    while newStartTime.count(':') < 2:
                        newStartTime = f'{newStartTime}:00'
                    self._element.time = newStartTime
                    self._ui.isModified = True
                    dispTime = self._element.time.rsplit(':', 1)[0]
                finally:
                    self._startTime.set(dispTime)

        if not switchTimeMode:
            newStartDay = self._startDay.get()
            if newStartDay or self._element.day:
                if newStartDay != self._element.day:
                    try:
                        int(newStartDay)
                    except ValueError:
                        self._startDay.set(self._element.day)
                    else:
                        self._element.day = newStartDay
                        if self._element.date:
                            self._element.date = None
                            switchTimeMode = True
                        self._ui.isModified = True
        else:
            self._element.day = None

        wrongEntry = False
        newEntry = False

        hoursLeft = 0
        newLastsMinutes = self._lastsMinutes.get()
        if newLastsMinutes or self._element.lastsMinutes:
            if newLastsMinutes != self._element.lastsMinutes:
                if not newLastsMinutes:
                    newLastsMinutes = 0
                try:
                    minutes = int(newLastsMinutes)
                except ValueError:
                    wrongEntry = True
                else:
                    hoursLeft, minutes = divmod(minutes, 60)
                    if minutes > 0:
                        newLastsMinutes = str(minutes)
                    else:
                        newLastsMinutes = None
                    self._lastsMinutes.set(newLastsMinutes)
                    newEntry = True

        daysLeft = 0
        newLastsHours = self._lastsHours.get()
        if hoursLeft or newLastsHours or self._element.lastsHours:
            if hoursLeft or newLastsHours != self._element.lastsHours:
                try:
                    if newLastsHours:
                        hoursLeft += int(newLastsHours)
                    daysLeft, hoursLeft = divmod(hoursLeft, 24)
                    if hoursLeft > 0:
                        newLastsHours = str(hoursLeft)
                    else:
                        newLastsHours = None
                    self._lastsHours.set(newLastsHours)
                except ValueError:
                    wrongEntry = True
                else:
                    newEntry = True

        newLastsDays = self._lastsDays.get()
        if daysLeft or newLastsDays or self._element.lastsDays:
            if daysLeft or newLastsDays != self._element.lastsDays:
                try:
                    if newLastsDays:
                        daysLeft += int(newLastsDays)
                    if daysLeft > 0:
                        newLastsDays = str(daysLeft)
                    else:
                        newLastsDays = None
                    self._lastsDays.set(newLastsDays)
                except ValueError:
                    wrongEntry = True
                else:
                    newEntry = True

        if wrongEntry:
            self._lastsMinutes.set(self._element.lastsMinutes)
            self._lastsHours.set(self._element.lastsHours)
            self._lastsDays.set(self._element.lastsDays)
        elif newEntry:
            self._element.lastsMinutes = newLastsMinutes
            self._element.lastsHours = newLastsHours
            self._element.lastsDays = newLastsDays
            self._ui.isModified = True

        super().apply_changes()
        if switchTimeMode:
            self.set_data(self._element)

    def set_data(self, element):
        super().set_data(element)

        self._startDate.set(self._element.date)

        if self._element.time is not None:
            dispTime = self._element.time.rsplit(':', 1)[0]
        else:
            dispTime = None
        self._startTime.set(dispTime)

        self._startDay.set(self._element.day)
        self._lastsDays.set(self._element.lastsDays)
        self._lastsHours.set(self._element.lastsHours)
        self._lastsMinutes.set(self._element.lastsMinutes)

        if self._ui.kwargs['show_date_time']:
            self._dateTimeFrame.show()
        else:
            self._dateTimeFrame.hide()

    def _auto_set(self):

        def get_scene_end(scene):
            endDate = None
            endTime = None
            endDay = None
            if scene.lastsDays:
                lastsDays = int(scene.lastsDays)
            else:
                lastsDays = 0
            if scene.lastsHours:
                lastsSeconds = int(scene.lastsHours) * 3600
            else:
                lastsSeconds = 0
            if scene.lastsMinutes:
                lastsSeconds += int(scene.lastsMinutes) * 60
            sceneDuration = timedelta(days=lastsDays, seconds=lastsSeconds)
            if scene.time:
                if scene.date:
                    try:
                        sceneStart = datetime.fromisoformat(f'{scene.date} {scene.time}')
                        sceneEnd = sceneStart + sceneDuration
                        endDate, endTime = sceneEnd.isoformat().split('T')
                    except:
                        pass
                else:
                    try:
                        if scene.day:
                            dayInt = int(scene.day)
                        else:
                            dayInt = 0
                        startDate = (date.min + timedelta(days=dayInt)).isoformat()
                        sceneStart = datetime.fromisoformat(f'{startDate} {scene.time}')
                        sceneEnd = sceneStart + sceneDuration
                        endDate, endTime = sceneEnd.isoformat().split('T')
                        endDay = str((date.fromisoformat(endDate) - date.min).days)
                        endDate = None
                    except:
                        pass
            return endDate, endTime, endDay

        thisNode = self._ui.tv.tree.selection()[0]
        prevNode = self._ui.tv.prev_node(thisNode, '')
        if prevNode:
            scId = prevNode[2:]
            newDate, newTime, newDay = get_scene_end(self._ui.novel.scenes[scId])
            if newTime is not None:
                self._startTime.set(newTime.rsplit(':', 1)[0])
                self._startDate.set(newDate)
                self._startDay.set(newDay)
                self.apply_changes()
            else:
                self._ui.show_error(_('The previous scene has no date/time set.'), title=_('Cannot generate date/time'))

    def _clear_duration(self):
        durationData = [
            self._element.lastsDays,
            self._element.lastsHours,
            self._element.lastsMinutes,
            ]
        hasData = False
        for dataElement in durationData:
            if dataElement:
                hasData = True
        if hasData and self._ui.ask_yes_no(_('Clear duration from this scene?')):
            self._element.lastsDays = None
            self._element.lastsHours = None
            self._element.lastsMinutes = None
            self.set_data(self._element)
            self._ui.isModified = True

    def _clear_start(self):
        startData = [
            self._element.date,
            self._element.time,
            self._element.day,
            ]
        hasData = False
        for dataElement in startData:
            if dataElement:
                hasData = True
        if hasData and self._ui.ask_yes_no(_('Clear date/time from this scene?')):
            self._element.date = None
            self._element.time = None
            self._element.day = None
            self.set_data(self._element)
            self._ui.isModified = True

    def _toggle_dateTimeFrame(self, event=None):
        if self._ui.kwargs['show_date_time']:
            self._dateTimeFrame.hide()
            self._ui.kwargs['show_date_time'] = False
        else:
            self._dateTimeFrame.show()
            self._ui.kwargs['show_date_time'] = True



class NormalSceneView(NotesSceneView):

    def __init__(self, ui, parent):
        super(). __init__(ui, parent)

        self._viewpoint = MyStringVar()
        self._characterCombobox = LabelCombo(self._sceneExtraFrame, text=_('Viewpoint'), textvariable=self._viewpoint, values=[])
        self._characterCombobox.pack(anchor='w', pady=2)

        self._appendToPrev = tk.BooleanVar()
        self._appendToPrevCheckbox = ttk.Checkbutton(self._sceneExtraFrame, text=_('Append to previous scene'),
                                         variable=self._appendToPrev, onvalue=True, offvalue=False)
        self._appendToPrevCheckbox.pack(anchor='w', pady=2)

        ttk.Separator(self._sceneExtraFrame, orient='horizontal').pack(fill='x')

        self._arcFrame = FoldingFrame(self._sceneExtraFrame, _('Plot'), self._toggle_arcFrame)

        self._arcs = MyStringVar()
        LabelEntry(self._arcFrame, text=_('Arcs'), textvariable=self._arcs).pack(anchor='w')

        self._arcPointsDisplay = tk.Label(self._arcFrame, anchor='w', bg='white')
        self._arcPointsDisplay.pack(anchor='w', fill='x')

        ttk.Separator(self._sceneExtraFrame, orient='horizontal').pack(fill='x')

        self._pacingFrame = FoldingFrame(self._sceneExtraFrame, _('Action/Reaction'), self._toggle_pacingFrame)

        selectionFrame = ttk.Frame(self._pacingFrame)
        self._customGoal = ''
        self._customConflict = ''
        self._customOutcome = ''
        self._scenePacingType = tk.IntVar()
        ttk.Radiobutton(selectionFrame, text=_('Action'),
                                         variable=self._scenePacingType, value=0, command=self._set_action_scene).pack(side='left', anchor='w')
        ttk.Radiobutton(selectionFrame, text=_('Reaction'),
                                         variable=self._scenePacingType, value=1, command=self._set_reaction_scene).pack(side='left', anchor='w')
        ttk.Radiobutton(selectionFrame, text=_('Custom'),
                                         variable=self._scenePacingType, value=2, command=self._set_custom_ar_scene).pack(anchor='w')
        selectionFrame.pack(fill='x')

        self._goalLabel = ttk.Label(self._pacingFrame)
        self._goalLabel.pack(anchor='w')
        self._goalWindow = TextBox(self._pacingFrame,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                height=self._ui.kwargs['gco_height'],
                padx=5,
                pady=5,
                bg=ui.kwargs['color_text_bg'],
                fg=ui.kwargs['color_text_fg'],
                insertbackground=ui.kwargs['color_text_fg'],
                )
        self._goalWindow.pack(fill='x')

        self._conflictLabel = ttk.Label(self._pacingFrame)
        self._conflictLabel.pack(anchor='w')
        self._conflictWindow = TextBox(self._pacingFrame,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                height=self._ui.kwargs['gco_height'],
                padx=5,
                pady=5,
                bg=ui.kwargs['color_text_bg'],
                fg=ui.kwargs['color_text_fg'],
                insertbackground=ui.kwargs['color_text_fg'],
                )
        self._conflictWindow.pack(fill='x')

        self._outcomeLabel = ttk.Label(self._pacingFrame)
        self._outcomeLabel.pack(anchor='w')
        self._outcomeWindow = TextBox(self._pacingFrame,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                height=self._ui.kwargs['gco_height'],
                padx=5,
                pady=5,
                bg=ui.kwargs['color_text_bg'],
                fg=ui.kwargs['color_text_fg'],
                insertbackground=ui.kwargs['color_text_fg'],
                )
        self._outcomeWindow.pack(fill='x')

    def apply_changes(self):
        option = self._characterCombobox.current()
        if self._element.characters:
            oldVpId = self._element.characters[0]
        else:
            oldVpId = None
        if option >= 0:
            newVpId = self._ui.novel.srtCharacters[option]
            if oldVpId:
                if newVpId != oldVpId:
                    try:
                        self._element.characters.remove(newVpId)
                    except:
                        pass
                    self._element.characters.insert(0, newVpId)
                    self._ui.isModified = True
            else:
                self._element.characters = []
                self._element.characters.append(newVpId)
                self._ui.isModified = True

        newArcs = self._arcs.get()
        if self._element.scnArcs or newArcs:
            if self._element.scnArcs != newArcs:
                self._element.scnArcs = newArcs
                self._ui.isModified = True

                self._ui.tv.update_prj_structure()
                self.set_data(self._element)

        appendToPrev = self._appendToPrev.get()
        if self._element.appendToPrev or appendToPrev:
            if self._element.appendToPrev != appendToPrev:
                self._element.appendToPrev = appendToPrev
                self._ui.isModified = True

        isReactionScene = self._scenePacingType.get() == 1
        if self._element.isReactionScene != isReactionScene:
            self._element.isReactionScene = isReactionScene
            self._ui.isModified = True
        if self._scenePacingType.get() == 2:
            value = '1'
        else:
            value = None
        if self._element.kwVar.get('Field_CustomAR', None) or value:
            if self._element.kwVar['Field_CustomAR'] != value:
                self._element.kwVar['Field_CustomAR'] = value
                self._ui.isModified = True

        if self._goalWindow.hasChanged:
            goal = self._goalWindow.get_text()
            if goal or self._element.goal:
                if self._element.goal != goal:
                    self._element.goal = goal
                    self._ui.isModified = True

        if self._conflictWindow.hasChanged:
            conflict = self._conflictWindow.get_text()
            if conflict or self._element.conflict:
                if self._element.conflict != conflict:
                    self._element.conflict = conflict
                    self._ui.isModified = True

        if self._outcomeWindow.hasChanged:
            outcome = self._outcomeWindow.get_text()
            if outcome or self._element.outcome:
                if self._element.outcome != outcome:
                    self._element.outcome = outcome
                    self._ui.isModified = True

        super().apply_changes()

    def set_data(self, element):
        super().set_data(element)

        charList = []
        for crId in self._ui.novel.srtCharacters:
            charList.append(self._ui.novel.characters[crId].title)
        self._characterCombobox.configure(values=charList)
        if self._element.characters:
            vp = self._ui.novel.characters[self._element.characters[0]].title
        else:
            vp = ''
        self._viewpoint.set(value=vp)

        if self._element.scnArcs is not None:
            arcs = self._element.scnArcs
        else:
            arcs = ''
        self._arcs.set(arcs)

        arcPoints = []
        arcPointIds = string_to_list(self._element.kwVar.get('Field_SceneAssoc', None))
        for scId in arcPointIds:
            arcPoints.append(self._ui.novel.scenes[scId].title)
        self._arcPointsDisplay.config(text=list_to_string(arcPoints))

        self._appendToPrev.set(self._element.appendToPrev)

        if self._ui.novel.kwVar.get('Field_CustomGoal', None):
            self._customGoal = self._ui.novel.kwVar['Field_CustomGoal']
        else:
            self._customGoal = _('N/A')

        if self._ui.novel.kwVar.get('Field_CustomConflict', None):
            self._customConflict = self._ui.novel.kwVar['Field_CustomConflict']
        else:
            self._customConflict = _('N/A')

        if self._ui.novel.kwVar.get('Field_CustomOutcome', None):
            self._customOutcome = self._ui.novel.kwVar['Field_CustomOutcome']
        else:
            self._customOutcome = _('N/A')

        if self._ui.kwargs['show_arcs']:
            self._arcFrame.show()
        else:
            self._arcFrame.hide()

        if self._ui.kwargs['show_action_reaction']:
            self._pacingFrame.show()
        else:
            self._pacingFrame.hide()

        if self._element.kwVar.get('Field_CustomAR', None):
            pacingType = 2
        elif self._element.isReactionScene:
            pacingType = 1
        else:
            pacingType = 0
        self._scenePacingType.set(pacingType)

        self._goalWindow.set_text(self._element.goal)

        self._conflictWindow.set_text(self._element.conflict)

        self._outcomeWindow.set_text(self._element.outcome)

        if pacingType == 2:
            self._set_custom_ar_scene()
        elif pacingType == 1:
            self._set_reaction_scene()
        else:
            self._set_action_scene()

    def _get_relation_id_list(self, newTitleStr, oldTitleStr, elements):
        if newTitleStr or oldTitleStr:
            if oldTitleStr != newTitleStr:
                elemIds = []
                for elemTitle in string_to_list(newTitleStr):
                    for elemId in elements:
                        if elements[elemId].title == elemTitle:
                            elemIds.append(elemId)
                            break
                    else:
                        self._ui.show_error(f'{_("Wrong name")}: "{elemTitle}"', title=_('Input rejected'))
                return elemIds

        return None

    def _set_action_scene(self, event=None):
        self._goalLabel.config(text=_('Goal'))
        self._conflictLabel.config(text=_('Conflict'))
        self._outcomeLabel.config(text=_('Outcome'))

    def _set_custom_ar_scene(self, event=None):
        self._goalLabel.config(text=self._customGoal)
        self._conflictLabel.config(text=self._customConflict)
        self._outcomeLabel.config(text=self._customOutcome)

    def _set_reaction_scene(self, event=None):
        self._goalLabel.config(text=_('Reaction'))
        self._conflictLabel.config(text=_('Dilemma'))
        self._outcomeLabel.config(text=_('Choice'))

    def _toggle_arcFrame(self, event=None):
        if self._ui.kwargs['show_arcs']:
            self._arcFrame.hide()
            self._ui.kwargs['show_arcs'] = False
        else:
            self._arcFrame.show()
            self._ui.kwargs['show_arcs'] = True

    def _toggle_pacingFrame(self, event=None):
        if self._ui.kwargs['show_action_reaction']:
            self._pacingFrame.hide()
            self._ui.kwargs['show_action_reaction'] = False
        else:
            self._pacingFrame.show()
            self._ui.kwargs['show_action_reaction'] = True

from tkinter import ttk


class TodoSceneView(SceneView):

    def __init__(self, ui, parent):
        super(). __init__(ui, parent)

        self._associatedScene = None
        self._lastSelected = ''
        self._treeSelectBinding = None
        self._uiEscBinding = None

        ttk.Separator(self._sceneExtraFrame, orient='horizontal').pack(fill='x')

        self._arcFrame = FoldingFrame(self._sceneExtraFrame, _('Arc'), self._toggle_arcFrame)
        self._arcInnerFrame = ttk.Frame(self._arcFrame)

        self._arc = ttk.Label(self._arcInnerFrame)
        self._arc.pack(anchor='w')

        self._sceneFrame = ttk.Frame(self._arcInnerFrame)
        self._sceneFrame.pack(anchor='w', fill='x')
        self._associatedSceneTitle = tk.Label(self._sceneFrame, anchor='w', bg='white')
        self._associatedSceneTitle.pack(anchor='w', pady=2, fill='x')
        ttk.Button(self._sceneFrame, text=_('Assign scene'), command=self._pick_scene).pack(side='left', fill='x', expand=True)
        ttk.Button(self._sceneFrame, text=_('Clear assignment'), command=self._clear_assignment).pack(side='left', fill='x', expand=True)
        ttk.Button(self._sceneFrame, text=_('Go to scene'), command=self._select_assigned_scene).pack(side='left', fill='x', expand=True)

    def apply_changes(self):
        if self._element.kwVar.get('Field_SceneAssoc', None) != self._associatedScene:
            self._element.kwVar['Field_SceneAssoc'] = self._associatedScene
            self._ui.isModified = True

        super().apply_changes()

    def set_data(self, element):
        super().set_data(element)

        if self._ui.kwargs['show_arcs']:
            self._arcFrame.show()
        else:
            self._arcFrame.hide()

        self._associatedScene = None
        if self._element.scnArcs:
            self._arc.config(text=self._element.scnArcs)

            try:
                self._associatedScene = self._element.kwVar.get('Field_SceneAssoc', None)
                sceneTitle = self._ui.novel.scenes[self._associatedScene].title
            except:
                sceneTitle = ''
            self._associatedSceneTitle['text'] = sceneTitle

            if not self._arcInnerFrame.winfo_manager():
                self._arcInnerFrame.pack(pady=2, fill='x')
        else:
            if self._arcInnerFrame.winfo_manager():
                self._arcInnerFrame.pack_forget()

    def _assign_scene(self, event=None):
        self._ui.tv.tree.bind('<<TreeviewSelect>>', self._treeSelectBinding)
        self._ui.root.bind('<Escape>', self._uiEscBinding)
        self._ui.tv.config(cursor='arrow')

        nodeId = self._ui.tv.tree.selection()[0]
        if nodeId.startswith(self._ui.tv.SCENE_PREFIX):
            scId = nodeId[2:]
            if self._ui.novel.scenes[scId].scType == 0:

                scnArcs = string_to_list(self._ui.novel.scenes[scId].scnArcs)
                if not self._element.scnArcs in scnArcs:
                    scnArcs.append(self._element.scnArcs)
                    self._ui.novel.scenes[scId].scnArcs = list_to_string(scnArcs)

                self._associatedScene = scId

                self.apply_changes()
                self.set_data(self._element)
        self._ui.tv.tree.see(self._lastSelected)
        self._ui.tv.tree.selection_set(self._lastSelected)

    def _clear_assignment(self):
        if self._associatedScene is not None:
            self._associatedScene = None
            self.apply_changes()
            self.set_data(self._element)
            self._ui.tv.tree.see(self._lastSelected)
            self._ui.tv.tree.selection_set(self._lastSelected)

    def _select_assigned_scene(self):
        if self._associatedScene is not None:
            targetNode = f'{self._ui.tv.SCENE_PREFIX}{self._associatedScene}'
            self._ui.tv.tree.see(targetNode)
            self._ui.tv.tree.selection_set(targetNode)

    def _pick_scene(self):
        self._lastSelected = self._ui.tv.tree.selection()[0]
        self._ui.tv.config(cursor='plus')
        self._ui.tv.open_children('')
        self._ui.tv.tree.see(self._ui.tv.NV_ROOT)
        self._treeSelectBinding = self._ui.tv.tree.bind('<<TreeviewSelect>>')
        self._ui.tv.tree.bind('<<TreeviewSelect>>', self._assign_scene)
        self._uiEscBinding = self._ui.root.bind('<Esc>')
        self._ui.root.bind('<Escape>', self._assign_scene)

    def _toggle_arcFrame(self, event=None):
        if self._ui.kwargs['show_arcs']:
            self._arcFrame.hide()
            self._ui.kwargs['show_arcs'] = False
        else:
            self._arcFrame.show()
            self._ui.kwargs['show_arcs'] = True

from tkinter import ttk


class CharacterView(WorldElementView):
    _LBL_X = 15

    def __init__(self, ui, parent):
        super(). __init__(ui, parent)

        self._fullName = MyStringVar()
        LabelEntry(self._fullNameFrame, text=_('Full name'), textvariable=self._fullName, lblWidth=self._LBL_X).pack(anchor='w', pady=2)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._bioFrame = FoldingFrame(self._elementInfoWindow, '', self._toggle_bioWindow)
        self._bioEntry = TextBox(self._bioFrame,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                height=10,
                width=10,
                padx=5,
                pady=5,
                bg=ui.kwargs['color_text_bg'],
                fg=ui.kwargs['color_text_fg'],
                insertbackground=ui.kwargs['color_text_fg'],
                )
        self._bioEntry.pack(fill='x')

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._goalsFrame = FoldingFrame(self._elementInfoWindow, '', self._toggle_goalsWindow)
        self._goalsEntry = TextBox(self._goalsFrame,
                wrap='word',
                undo=True,
                autoseparators=True,
                maxundo=-1,
                height=10,
                width=10,
                padx=5,
                pady=5,
                bg=ui.kwargs['color_text_bg'],
                fg=ui.kwargs['color_text_fg'],
                insertbackground=ui.kwargs['color_text_fg'],
                )
        self._goalsEntry.pack(fill='x')

    def apply_changes(self):

        fullName = self._fullName.get()
        if fullName or self._element.fullName:
            if self._element.fullName != fullName:
                self._element.fullName = fullName.strip()
                self._ui.isModified = True

        if self._bioEntry.hasChanged:
            bio = self._bioEntry.get_text()
            if bio or self._element.bio:
                if self._element.bio != bio:
                    self._element.bio = bio
                    self._ui.isModified = True

        if self._goalsEntry.hasChanged:
            goals = self._goalsEntry.get_text()
            if goals or self._element.goals:
                if self._element.goals != goals:
                    self._element.goals = goals
                    self._ui.isModified = True

        if self._ui.isModified:
            self._ui.tv.update_prj_structure()

        super().apply_changes()

    def set_data(self, element):
        super().set_data(element)

        self._fullName.set(self._element.fullName)

        if self._ui.novel.kwVar.get('Field_CustomChrBio', None):
            self._bioFrame.buttonText = self._ui.novel.kwVar['Field_CustomChrBio']
        else:
            self._bioFrame.buttonText = _('Bio')
        if self._ui.kwargs['show_cr_bio']:
            self._bioFrame.show()
        else:
            self._bioFrame.hide()
        self._bioEntry.set_text(self._element.bio)

        if self._ui.novel.kwVar.get('Field_CustomChrGoals', None):
            self._goalsFrame.buttonText = self._ui.novel.kwVar['Field_CustomChrGoals']
        else:
            self._goalsFrame.buttonText = _('Goals')
        if self._ui.kwargs['show_cr_goals']:
            self._goalsFrame.show()
        else:
            self._goalsFrame.hide()
        self._goalsEntry.set_text(self._element.goals)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_image_window()
        self._create_notes_window()
        self._create_button_bar()

    def _toggle_bioWindow(self, event=None):
        if self._ui.kwargs['show_cr_bio']:
            self._bioFrame.hide()
            self._ui.kwargs['show_cr_bio'] = False
        else:
            self._bioFrame.show()
            self._ui.kwargs['show_cr_bio'] = True

    def _toggle_goalsWindow(self, event=None):
        if self._ui.kwargs['show_cr_goals']:
            self._goalsFrame.hide()
            self._ui.kwargs['show_cr_goals'] = False
        else:
            self._goalsFrame.show()
            self._ui.kwargs['show_cr_goals'] = True



class ProjectnoteView(BasicView):

    def _create_frames(self):
        self._create_index_card()
        self._create_button_bar()
from tkinter import ttk


class DragDropListbox(tk.Listbox):

    def __init__(self, master, **kw):
        kw['selectmode'] = 'single'
        tk.Listbox.__init__(self, master, kw)
        self.bind('<Button-1>', self._set_current)
        self.bind('<B1-Motion>', self._shift_selection)
        self.curIndex = None

    def _set_current(self, event):
        self.curIndex = self.nearest(event.y)

    def _shift_selection(self, event):
        i = self.nearest(event.y)
        if i < self.curIndex:
            x = self.get(i)
            self.delete(i)
            self.insert(i + 1, x)
            self.curIndex = i
        elif i > self.curIndex:
            x = self.get(i)
            self.delete(i)
            self.insert(i - 1, x)
            self.curIndex = i


class SettingsWindow(tk.Toplevel):

    def __init__(self, tv, ui, size, **kw):
        self._tv = tv
        self._ui = ui
        super().__init__(**kw)
        self.title(_('Program settings'))
        self.geometry(size)
        self.grab_set()
        self.focus()
        window = ttk.Frame(self)
        window.pack(fill='both',
                    padx=5,
                    pady=5
                    )
        frame1 = ttk.Frame(window)
        frame1.pack(fill='both', side='left')
        ttk.Separator(window, orient='vertical').pack(fill='y', padx=10, side='left')
        frame2 = ttk.Frame(window)
        frame2.pack(fill='both', side='left')

        self._coloringModeStr = tk.StringVar(value=self._ui.COLORING_MODES[self._ui.coloringMode])
        self._coloringModeStr.trace('w', self._change_colors)
        ttk.Label(frame1,
                  text=_('Coloring mode')
                  ).pack(padx=5, pady=5, anchor='w')
        ttk.Combobox(frame1,
                   textvariable=self._coloringModeStr,
                   values=self._ui.COLORING_MODES,
                   width=20
                   ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(frame1, orient='horizontal').pack(fill='x', pady=10)

        self._cleanUpYw = tk.BooleanVar(frame1, value=self._ui.cleanUpYw)
        ttk.Checkbutton(frame1, text=_('Delete yWriter-only data on save'), variable=self._cleanUpYw).pack(anchor='w')
        self._cleanUpYw.trace('w', self._update_cleanup)

        ttk.Label(frame2,
                  text=_('Columns')
                  ).pack(padx=5, pady=5, anchor='w')
        self._coIdsByTitle = {}
        for coId, title, __ in self._tv.columns:
            self._coIdsByTitle[title] = coId
        self._colEntries = tk.Variable(value=list(self._coIdsByTitle))
        DragDropListbox(frame2,
                        listvariable=self._colEntries,
                        width=20
                        ).pack(padx=5, pady=5, anchor='w')
        ttk.Button(frame2,
                   text=_('Apply'),
                   command=self._change_column_order
                   ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(self,
                   text=_('Exit'),
                   command=self.destroy
                   ).pack(padx=5, pady=5, anchor='e')

    def _change_colors(self, *args, **kwargs):
        cmStr = self._coloringModeStr.get()
        self._ui.coloringMode = self._ui.COLORING_MODES.index(cmStr)
        self._tv.refresh_tree()

    def _change_column_order(self, *args, **kwargs):
        srtColumns = []
        titles = self._colEntries.get()
        for title in titles:
            srtColumns.append(self._coIdsByTitle[title])
        self._ui.kwargs['column_order'] = list_to_string(srtColumns)
        self._tv.configure_columns()
        self._tv.build_tree()

    def _update_cleanup(self, *args, **kwargs):
        self._ui.cleanUpYw = self._cleanUpYw.get()
from tkinter import ttk


class PluginManager(tk.Toplevel):

    def __init__(self, ui, size, **kw):
        self._ui = ui
        super().__init__(**kw)
        self.title(f'{_("Installed plugins")} - novelyst 4.38.0')
        self.geometry(size)
        self.grab_set()
        self.focus()
        window = ttk.Frame(self)
        window.pack(fill='both', expand=True)

        columns = 'Module', 'Version', 'novelyst API', 'Description'
        self._moduleCollection = ttk.Treeview(window, columns=columns, show='headings', selectmode='browse')
        self._moduleCollection.pack(fill='both', expand=True)
        self._moduleCollection.bind('<<TreeviewSelect>>', self._on_select_module)
        self._moduleCollection.tag_configure('rejected', foreground='red')
        self._moduleCollection.tag_configure('inactive', foreground='gray')

        self._moduleCollection.column('Module', width=150, minwidth=120, stretch=False)
        self._moduleCollection.heading('Module', text=_('Module'), anchor='w')
        self._moduleCollection.column('Version', width=100, minwidth=100, stretch=False)
        self._moduleCollection.heading('Version', text=_('Version'), anchor='w')
        self._moduleCollection.column('novelyst API', width=100, minwidth=100, stretch=False)
        self._moduleCollection.heading('novelyst API', text=_('novelyst API'), anchor='w')
        self._moduleCollection.column('Description', width=400, stretch=True)
        self._moduleCollection.heading('Description', text=_('Description'), anchor='w')

        for moduleName in self._ui.plugins:
            nodeTags = []
            try:
                version = self._ui.plugins[moduleName].VERSION
            except:
                version = _('unknown')
            try:
                description = self._ui.plugins[moduleName].DESCRIPTION
            except:
                description = _('No description')
            try:
                apiRequired = self._ui.plugins[moduleName].NOVELYST_API
            except:
                apiRequired = _('unknown')
            columns = [moduleName, version, apiRequired, description]
            if self._ui.plugins[moduleName].isRejected:
                nodeTags.append('rejected')
            elif not self._ui.plugins[moduleName].isActive:
                nodeTags.append('inactive')
            self._moduleCollection.insert('', 'end', moduleName, values=columns, tags=tuple(nodeTags))

        self._homeButton = ttk.Button(window, text=_('Home page'), command=self._open_home_page, state='disabled')
        self._homeButton.pack(padx=5, pady=5, side='left')

        self._deleteButton = ttk.Button(window, text=_('Delete'), command=self._delete_module, state='disabled')
        self._deleteButton.pack(padx=5, pady=5, side='left')

        ttk.Button(window, text=_('Exit'), command=self.destroy).pack(padx=5, pady=5, side='left')

    def _delete_module(self, event=None):
        moduleName = self._moduleCollection.selection()[0]
        if moduleName:
            if self._ui.plugins.delete_file(moduleName):
                self._deleteButton.configure(state='disabled')
                if self._ui.plugins[moduleName].isActive:
                    self._ui.show_info(_('The plugin remains active until next start.'), title=f'{moduleName} {_("deleted")}')
                else:
                    self._moduleCollection.delete(moduleName)

    def _on_select_module(self, event):
        moduleName = self._moduleCollection.selection()[0]
        homeButtonState = 'disabled'
        deleteButtonState = 'disabled'
        if moduleName:
            try:
                if self._ui.plugins[moduleName].URL:
                    homeButtonState = 'normal'
            except:
                pass
            try:
                if self._ui.plugins[moduleName].filePath:
                    deleteButtonState = 'normal'
            except:
                pass
        self._homeButton.configure(state=homeButtonState)
        self._deleteButton.configure(state=deleteButtonState)

    def _open_home_page(self, event=None):
        moduleName = self._moduleCollection.selection()[0]
        if moduleName:
            try:
                url = self._ui.plugins[moduleName].URL
                if url:
                    webbrowser.open(url)
            except:
                pass

from tkinter import ttk
from datetime import datetime
from abc import ABC, abstractmethod


class FileFactory(ABC):

    def __init__(self, fileClasses=[]):
        self._fileClasses = fileClasses

    @abstractmethod
    def make_file_objects(self, sourcePath, **kwargs):
        pass


class ExportTargetFactory(FileFactory):

    def make_file_objects(self, sourcePath, **kwargs):
        fileName, __ = os.path.splitext(sourcePath)
        suffix = kwargs['suffix']
        for fileClass in self._fileClasses:
            if fileClass.SUFFIX == suffix:
                if suffix is None:
                    suffix = ''
                targetFile = fileClass(f'{fileName}{suffix}{fileClass.EXTENSION}', **kwargs)
                return None, targetFile

        raise Error(f'{_("Export type is not supported")}: "{suffix}".')
from string import Template
from string import Template
import zipfile
import tempfile
from shutil import rmtree
from datetime import datetime
from string import Template
from string import Template


class Filter:

    def accept(self, source, eId):
        return True


class FileExport(File):
    SUFFIX = ''
    _fileHeader = ''
    _partTemplate = ''
    _chapterTemplate = ''
    _notesPartTemplate = ''
    _todoPartTemplate = ''
    _notesChapterTemplate = ''
    _todoChapterTemplate = ''
    _unusedChapterTemplate = ''
    _notExportedChapterTemplate = ''
    _sceneTemplate = ''
    _firstSceneTemplate = ''
    _appendedSceneTemplate = ''
    _notesSceneTemplate = ''
    _todoSceneTemplate = ''
    _unusedSceneTemplate = ''
    _notExportedSceneTemplate = ''
    _sceneDivider = ''
    _chapterEndTemplate = ''
    _unusedChapterEndTemplate = ''
    _notExportedChapterEndTemplate = ''
    _notesChapterEndTemplate = ''
    _todoChapterEndTemplate = ''
    _characterSectionHeading = ''
    _characterTemplate = ''
    _locationSectionHeading = ''
    _locationTemplate = ''
    _itemSectionHeading = ''
    _itemTemplate = ''
    _fileFooter = ''
    _projectNoteTemplate = ''

    _DIVIDER = ', '

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._sceneFilter = Filter()
        self._chapterFilter = Filter()
        self._characterFilter = Filter()
        self._locationFilter = Filter()
        self._itemFilter = Filter()

    def write(self):
        text = self._get_text()
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(self.filePath)}".')
            else:
                backedUp = True
        try:
            with open(self.filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')

    def _get_fileHeaderMapping(self):
        projectTemplateMapping = dict(
            Title=self._convert_from_yw(self.novel.title, True),
            Desc=self._convert_from_yw(self.novel.desc),
            AuthorName=self._convert_from_yw(self.novel.authorName, True),
            AuthorBio=self._convert_from_yw(self.novel.authorBio, True),
            FieldTitle1=self._convert_from_yw(self.novel.fieldTitle1, True),
            FieldTitle2=self._convert_from_yw(self.novel.fieldTitle2, True),
            FieldTitle3=self._convert_from_yw(self.novel.fieldTitle3, True),
            FieldTitle4=self._convert_from_yw(self.novel.fieldTitle4, True),
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
        )
        return projectTemplateMapping

    def _convert_from_yw(self, text, quick=False):
        if text is None:
            text = ''
        return(text)

    def _get_chapterMapping(self, chId, chapterNumber):
        if chapterNumber == 0:
            chapterNumber = ''

        chapterMapping = dict(
            ID=chId,
            ChapterNumber=chapterNumber,
            Title=self._convert_from_yw(self.novel.chapters[chId].title, True),
            Desc=self._convert_from_yw(self.novel.chapters[chId].desc),
            ProjectName=self._convert_from_yw(self.projectName, True),
            ProjectPath=self.projectPath,
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
        )
        return chapterMapping

    def _get_chapters(self):
        lines = []
        chapterNumber = 0
        sceneNumber = 0
        wordsTotal = 0
        lettersTotal = 0
        for chId in self.novel.srtChapters:
            dispNumber = 0
            if not self._chapterFilter.accept(self, chId):
                continue

            sceneCount = 0
            notExportCount = 0
            doNotExport = False
            template = None
            for scId in self.novel.chapters[chId].srtScenes:
                sceneCount += 1
                if self.novel.scenes[scId].doNotExport:
                    notExportCount += 1
            if sceneCount > 0 and notExportCount == sceneCount:
                doNotExport = True
            if self.novel.chapters[chId].chType == 2:
                if self.novel.chapters[chId].chLevel == 1:
                    if self._todoPartTemplate:
                        template = Template(self._todoPartTemplate)
                elif self._todoChapterTemplate:
                    template = Template(self._todoChapterTemplate)
            elif self.novel.chapters[chId].chType == 1:
                if self.novel.chapters[chId].chLevel == 1:
                    if self._notesPartTemplate:
                        template = Template(self._notesPartTemplate)
                elif self._notesChapterTemplate:
                    template = Template(self._notesChapterTemplate)
            elif self.novel.chapters[chId].chType == 3:
                if self._unusedChapterTemplate:
                    template = Template(self._unusedChapterTemplate)
            elif doNotExport:
                if self._notExportedChapterTemplate:
                    template = Template(self._notExportedChapterTemplate)
            elif self.novel.chapters[chId].chLevel == 1 and self._partTemplate:
                template = Template(self._partTemplate)
            else:
                template = Template(self._chapterTemplate)
                chapterNumber += 1
                dispNumber = chapterNumber
            if template is not None:
                lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))

            sceneLines, sceneNumber, wordsTotal, lettersTotal = self._get_scenes(
                chId, sceneNumber, wordsTotal, lettersTotal, doNotExport)
            lines.extend(sceneLines)

            template = None
            if self.novel.chapters[chId].chType == 2:
                if self._todoChapterEndTemplate:
                    template = Template(self._todoChapterEndTemplate)
            elif self.novel.chapters[chId].chType == 1:
                if self._notesChapterEndTemplate:
                    template = Template(self._notesChapterEndTemplate)
            elif self.novel.chapters[chId].chType == 3:
                if self._unusedChapterEndTemplate:
                    template = Template(self._unusedChapterEndTemplate)
            elif doNotExport:
                if self._notExportedChapterEndTemplate:
                    template = Template(self._notExportedChapterEndTemplate)
            elif self._chapterEndTemplate:
                template = Template(self._chapterEndTemplate)
            if template is not None:
                lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))
        return lines

    def _get_characterMapping(self, crId):
        if self.novel.characters[crId].tags is not None:
            tags = list_to_string(self.novel.characters[crId].tags, divider=self._DIVIDER)
        else:
            tags = ''
        if self.novel.characters[crId].isMajor:
            characterStatus = Character.MAJOR_MARKER
        else:
            characterStatus = Character.MINOR_MARKER

        characterMapping = dict(
            ID=crId,
            Title=self._convert_from_yw(self.novel.characters[crId].title, True),
            Desc=self._convert_from_yw(self.novel.characters[crId].desc),
            Tags=self._convert_from_yw(tags),
            Image=self.novel.characters[crId].image,
            AKA=self._convert_from_yw(self.novel.characters[crId].aka, True),
            Notes=self._convert_from_yw(self.novel.characters[crId].notes),
            Bio=self._convert_from_yw(self.novel.characters[crId].bio),
            Goals=self._convert_from_yw(self.novel.characters[crId].goals),
            FullName=self._convert_from_yw(self.novel.characters[crId].fullName, True),
            Status=characterStatus,
            ProjectName=self._convert_from_yw(self.projectName),
            ProjectPath=self.projectPath,
        )
        return characterMapping

    def _get_characters(self):
        if self._characterSectionHeading:
            lines = [self._characterSectionHeading]
        else:
            lines = []
        template = Template(self._characterTemplate)
        for crId in self.novel.srtCharacters:
            if self._characterFilter.accept(self, crId):
                lines.append(template.safe_substitute(self._get_characterMapping(crId)))
        return lines

    def _get_fileHeader(self):
        lines = []
        template = Template(self._fileHeader)
        lines.append(template.safe_substitute(self._get_fileHeaderMapping()))
        return lines

    def _get_itemMapping(self, itId):
        if self.novel.items[itId].tags is not None:
            tags = list_to_string(self.novel.items[itId].tags, divider=self._DIVIDER)
        else:
            tags = ''

        itemMapping = dict(
            ID=itId,
            Title=self._convert_from_yw(self.novel.items[itId].title, True),
            Desc=self._convert_from_yw(self.novel.items[itId].desc),
            Tags=self._convert_from_yw(tags, True),
            Image=self.novel.items[itId].image,
            AKA=self._convert_from_yw(self.novel.items[itId].aka, True),
            ProjectName=self._convert_from_yw(self.projectName, True),
            ProjectPath=self.projectPath,
        )
        return itemMapping

    def _get_items(self):
        if self._itemSectionHeading:
            lines = [self._itemSectionHeading]
        else:
            lines = []
        template = Template(self._itemTemplate)
        for itId in self.novel.srtItems:
            if self._itemFilter.accept(self, itId):
                lines.append(template.safe_substitute(self._get_itemMapping(itId)))
        return lines

    def _get_locationMapping(self, lcId):
        if self.novel.locations[lcId].tags is not None:
            tags = list_to_string(self.novel.locations[lcId].tags, divider=self._DIVIDER)
        else:
            tags = ''

        locationMapping = dict(
            ID=lcId,
            Title=self._convert_from_yw(self.novel.locations[lcId].title, True),
            Desc=self._convert_from_yw(self.novel.locations[lcId].desc),
            Tags=self._convert_from_yw(tags, True),
            Image=self.novel.locations[lcId].image,
            AKA=self._convert_from_yw(self.novel.locations[lcId].aka, True),
            ProjectName=self._convert_from_yw(self.projectName, True),
            ProjectPath=self.projectPath,
        )
        return locationMapping

    def _get_locations(self):
        if self._locationSectionHeading:
            lines = [self._locationSectionHeading]
        else:
            lines = []
        template = Template(self._locationTemplate)
        for lcId in self.novel.srtLocations:
            if self._locationFilter.accept(self, lcId):
                lines.append(template.safe_substitute(self._get_locationMapping(lcId)))
        return lines

    def _get_sceneMapping(self, scId, sceneNumber, wordsTotal, lettersTotal):

        if sceneNumber == 0:
            sceneNumber = ''
        if self.novel.scenes[scId].tags is not None:
            tags = list_to_string(self.novel.scenes[scId].tags, divider=self._DIVIDER)
        else:
            tags = ''

        try:
            sChList = []
            for crId in self.novel.scenes[scId].characters:
                sChList.append(self.novel.characters[crId].title)
            sceneChars = list_to_string(sChList, divider=self._DIVIDER)
            viewpointChar = sChList[0]
        except:
            sceneChars = ''
            viewpointChar = ''

        if self.novel.scenes[scId].locations is not None:
            sLcList = []
            for lcId in self.novel.scenes[scId].locations:
                sLcList.append(self.novel.locations[lcId].title)
            sceneLocs = list_to_string(sLcList, divider=self._DIVIDER)
        else:
            sceneLocs = ''

        if self.novel.scenes[scId].items is not None:
            sItList = []
            for itId in self.novel.scenes[scId].items:
                sItList.append(self.novel.items[itId].title)
            sceneItems = list_to_string(sItList, divider=self._DIVIDER)
        else:
            sceneItems = ''

        if self.novel.scenes[scId].isReactionScene:
            reactionScene = Scene.REACTION_MARKER
        else:
            reactionScene = Scene.ACTION_MARKER

        if self.novel.scenes[scId].date is not None and self.novel.scenes[scId].date != Scene.NULL_DATE:
            scDay = ''
            scDate = self.novel.scenes[scId].date
            cmbDate = self.novel.scenes[scId].date
        else:
            scDate = ''
            if self.novel.scenes[scId].day is not None:
                scDay = self.novel.scenes[scId].day
                cmbDate = f'Day {self.novel.scenes[scId].day}'
            else:
                scDay = ''
                cmbDate = ''

        if self.novel.scenes[scId].time is not None:
            scTime = self.novel.scenes[scId].time.rsplit(':', 1)[0]
        else:
            scTime = ''

        if self.novel.scenes[scId].lastsDays is not None and self.novel.scenes[scId].lastsDays != '0':
            lastsDays = self.novel.scenes[scId].lastsDays
            days = f'{self.novel.scenes[scId].lastsDays}d '
        else:
            lastsDays = ''
            days = ''
        if self.novel.scenes[scId].lastsHours is not None and self.novel.scenes[scId].lastsHours != '0':
            lastsHours = self.novel.scenes[scId].lastsHours
            hours = f'{self.novel.scenes[scId].lastsHours}h '
        else:
            lastsHours = ''
            hours = ''
        if self.novel.scenes[scId].lastsMinutes is not None and self.novel.scenes[scId].lastsMinutes != '0':
            lastsMinutes = self.novel.scenes[scId].lastsMinutes
            minutes = f'{self.novel.scenes[scId].lastsMinutes}min'
        else:
            lastsMinutes = ''
            minutes = ''
        duration = f'{days}{hours}{minutes}'

        sceneMapping = dict(
            ID=scId,
            SceneNumber=sceneNumber,
            Title=self._convert_from_yw(self.novel.scenes[scId].title, True),
            Desc=self._convert_from_yw(self.novel.scenes[scId].desc),
            WordCount=str(self.novel.scenes[scId].wordCount),
            WordsTotal=wordsTotal,
            LetterCount=str(self.novel.scenes[scId].letterCount),
            LettersTotal=lettersTotal,
            Status=Scene.STATUS[self.novel.scenes[scId].status],
            SceneContent=self._convert_from_yw(self.novel.scenes[scId].sceneContent),
            FieldTitle1=self._convert_from_yw(self.novel.fieldTitle1, True),
            FieldTitle2=self._convert_from_yw(self.novel.fieldTitle2, True),
            FieldTitle3=self._convert_from_yw(self.novel.fieldTitle3, True),
            FieldTitle4=self._convert_from_yw(self.novel.fieldTitle4, True),
            Field1=self.novel.scenes[scId].field1,
            Field2=self.novel.scenes[scId].field2,
            Field3=self.novel.scenes[scId].field3,
            Field4=self.novel.scenes[scId].field4,
            Date=scDate,
            Time=scTime,
            Day=scDay,
            ScDate=cmbDate,
            LastsDays=lastsDays,
            LastsHours=lastsHours,
            LastsMinutes=lastsMinutes,
            Duration=duration,
            ReactionScene=reactionScene,
            Goal=self._convert_from_yw(self.novel.scenes[scId].goal),
            Conflict=self._convert_from_yw(self.novel.scenes[scId].conflict),
            Outcome=self._convert_from_yw(self.novel.scenes[scId].outcome),
            Tags=self._convert_from_yw(tags, True),
            Image=self.novel.scenes[scId].image,
            Characters=sceneChars,
            Viewpoint=viewpointChar,
            Locations=sceneLocs,
            Items=sceneItems,
            Notes=self._convert_from_yw(self.novel.scenes[scId].notes),
            ProjectName=self._convert_from_yw(self.projectName, True),
            ProjectPath=self.projectPath,
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
        )
        return sceneMapping

    def _get_scenes(self, chId, sceneNumber, wordsTotal, lettersTotal, doNotExport):
        lines = []
        firstSceneInChapter = True
        for scId in self.novel.chapters[chId].srtScenes:
            dispNumber = 0
            if not self._sceneFilter.accept(self, scId):
                continue

            sceneContent = self.novel.scenes[scId].sceneContent
            if sceneContent is None:
                sceneContent = ''

            if self.novel.scenes[scId].scType == 2:
                if self._todoSceneTemplate:
                    template = Template(self._todoSceneTemplate)
                else:
                    continue

            elif self.novel.scenes[scId].scType == 1:
                if self._notesSceneTemplate:
                    template = Template(self._notesSceneTemplate)
                else:
                    continue

            elif self.novel.scenes[scId].scType == 3 or self.novel.chapters[chId].chType == 3:
                if self._unusedSceneTemplate:
                    template = Template(self._unusedSceneTemplate)
                else:
                    continue

            elif self.novel.scenes[scId].doNotExport or doNotExport:
                if self._notExportedSceneTemplate:
                    template = Template(self._notExportedSceneTemplate)
                else:
                    continue

            elif sceneContent.startswith('<HTML>'):
                continue

            elif sceneContent.startswith('<TEX>'):
                continue

            else:
                sceneNumber += 1
                dispNumber = sceneNumber
                wordsTotal += self.novel.scenes[scId].wordCount
                lettersTotal += self.novel.scenes[scId].letterCount
                template = Template(self._sceneTemplate)
                if not firstSceneInChapter and self.novel.scenes[scId].appendToPrev and self._appendedSceneTemplate:
                    template = Template(self._appendedSceneTemplate)
            if not (firstSceneInChapter or self.novel.scenes[scId].appendToPrev):
                lines.append(self._sceneDivider)
            if firstSceneInChapter and self._firstSceneTemplate:
                template = Template(self._firstSceneTemplate)
            lines.append(template.safe_substitute(self._get_sceneMapping(
                        scId, dispNumber, wordsTotal, lettersTotal)))
            firstSceneInChapter = False
        return lines, sceneNumber, wordsTotal, lettersTotal

    def _get_prjNoteMapping(self, pnId):
        itemMapping = dict(
            ID=pnId,
            Title=self._convert_from_yw(self.novel.projectNotes[pnId].title, True),
            Desc=self._convert_from_yw(self.novel.projectNotes[pnId].desc, True),
            ProjectName=self._convert_from_yw(self.projectName, True),
            ProjectPath=self.projectPath,
        )
        return itemMapping

    def _get_projectNotes(self):
        lines = []
        template = Template(self._projectNoteTemplate)
        for pnId in self.novel.srtPrjNotes:
            map = self._get_prjNoteMapping(pnId)
            lines.append(template.safe_substitute(map))
        return lines

    def _get_text(self):
        lines = self._get_fileHeader()
        lines.extend(self._get_chapters())
        lines.extend(self._get_characters())
        lines.extend(self._get_locations())
        lines.extend(self._get_items())
        lines.extend(self._get_projectNotes())
        lines.append(self._fileFooter)
        return ''.join(lines)

    def _remove_inline_code(self, text):
        if text:
            text = text.replace('<RTFBRK>', '')
            YW_SPECIAL_CODES = ('HTM', 'TEX', 'RTF', 'epub', 'mobi', 'rtfimg')
            for specialCode in YW_SPECIAL_CODES:
                text = re.sub(f'\<{specialCode} .+?\/{specialCode}\>', '', text)
        else:
            text = ''
        return text


class OdfFile(FileExport):
    _ODF_COMPONENTS = []
    _MIMETYPE = ''
    _SETTINGS_XML = ''
    _MANIFEST_XML = ''
    _STYLES_XML = ''
    _META_XML = ''

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._tempDir = tempfile.mkdtemp(suffix='.tmp', prefix='odf_')
        self._originalPath = self._filePath

    def __del__(self):
        self._tear_down()

    def write(self):

        self._set_up()

        self._originalPath = self._filePath
        self._filePath = f'{self._tempDir}/content.xml'
        super().write()
        self._filePath = self._originalPath

        workdir = os.getcwd()
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(self.filePath)}".')
            else:
                backedUp = True
        try:
            with zipfile.ZipFile(self.filePath, 'w') as odfTarget:
                os.chdir(self._tempDir)
                for file in self._ODF_COMPONENTS:
                    odfTarget.write(file, compress_type=zipfile.ZIP_DEFLATED)
        except:
            os.chdir(workdir)
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise Error(f'{_("Cannot create file")}: "{norm_path(self.filePath)}".')

        os.chdir(workdir)
        self._tear_down()
        return f'{_("File written")}: "{norm_path(self.filePath)}".'

    def _set_up(self):

        try:
            self._tear_down()
            os.mkdir(self._tempDir)
            os.mkdir(f'{self._tempDir}/META-INF')
        except:
            raise Error(f'{_("Cannot create directory")}: "{norm_path(self._tempDir)}".')

        try:
            with open(f'{self._tempDir}/mimetype', 'w', encoding='utf-8') as f:
                f.write(self._MIMETYPE)
        except:
            raise Error(f'{_("Cannot write file")}: "mimetype"')

        try:
            with open(f'{self._tempDir}/settings.xml', 'w', encoding='utf-8') as f:
                f.write(self._SETTINGS_XML)
        except:
            raise Error(f'{_("Cannot write file")}: "settings.xml"')

        try:
            with open(f'{self._tempDir}/META-INF/manifest.xml', 'w', encoding='utf-8') as f:
                f.write(self._MANIFEST_XML)
        except:
            raise Error(f'{_("Cannot write file")}: "manifest.xml"')

        self.novel.check_locale()
        localeMapping = dict(
            Language=self.novel.languageCode,
            Country=self.novel.countryCode,
            )
        template = Template(self._STYLES_XML)
        text = template.safe_substitute(localeMapping)
        try:
            with open(f'{self._tempDir}/styles.xml', 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            raise Error(f'{_("Cannot write file")}: "styles.xml"')

        metaMapping = dict(
            Author=self.novel.authorName,
            Title=self.novel.title,
            Summary=f'<![CDATA[{self.novel.desc}]]>',
            Datetime=datetime.today().replace(microsecond=0).isoformat(),
        )
        template = Template(self._META_XML)
        text = template.safe_substitute(metaMapping)
        try:
            with open(f'{self._tempDir}/meta.xml', 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            raise Error(f'{_("Cannot write file")}: "meta.xml".')

    def _tear_down(self):
        try:
            rmtree(self._tempDir)
        except:
            pass



class OdtWriter(OdfFile):

    EXTENSION = '.odt'

    _ODF_COMPONENTS = ['manifest.rdf', 'META-INF', 'content.xml', 'meta.xml', 'mimetype',
                      'settings.xml', 'styles.xml', 'META-INF/manifest.xml']

    _CONTENT_XML_HEADER = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:ooow="http://openoffice.org/2004/writer" xmlns:oooc="http://openoffice.org/2004/calc" xmlns:dom="http://www.w3.org/2001/xml-events" xmlns:xforms="http://www.w3.org/2002/xforms" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:rpt="http://openoffice.org/2005/report" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:grddl="http://www.w3.org/2003/g/data-view#" xmlns:tableooo="http://openoffice.org/2009/table" xmlns:field="urn:openoffice:names:experimental:ooo-ms-interop:xmlns:field:1.0" office:version="1.2">
 <office:scripts/>
 <office:font-face-decls>
  <style:font-face style:name="StarSymbol" svg:font-family="StarSymbol" style:font-charset="x-symbol"/>
  <style:font-face style:name="Consolas" svg:font-family="Consolas" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
  <style:font-face style:name="Courier New" svg:font-family="&apos;Courier New&apos;" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
 </office:font-face-decls>
 <office:automatic-styles/>
 <office:body>
  <office:text text:use-soft-page-breaks="true">

'''

    _CONTENT_XML_FOOTER = '''  </office:text>
 </office:body>
</office:document-content>
'''

    _META_XML = '''<?xml version="1.0" encoding="utf-8"?>
<office:document-meta xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:grddl="http://www.w3.org/2003/g/data-view#" office:version="1.2">
  <office:meta>
    <meta:generator>PyWriter</meta:generator>
    <dc:title>$Title</dc:title>
    <dc:description>$Summary</dc:description>
    <dc:subject></dc:subject>
    <meta:keyword></meta:keyword>
    <meta:initial-creator>$Author</meta:initial-creator>
    <dc:creator></dc:creator>
    <meta:creation-date>${Datetime}Z</meta:creation-date>
    <dc:date></dc:date>
  </office:meta>
</office:document-meta>
'''
    _MANIFEST_XML = '''<?xml version="1.0" encoding="utf-8"?>
<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">
  <manifest:file-entry manifest:media-type="application/vnd.oasis.opendocument.text" manifest:full-path="/" />
  <manifest:file-entry manifest:media-type="application/xml" manifest:full-path="content.xml" manifest:version="1.2" />
  <manifest:file-entry manifest:media-type="application/rdf+xml" manifest:full-path="manifest.rdf" manifest:version="1.2" />
  <manifest:file-entry manifest:media-type="application/xml" manifest:full-path="styles.xml" manifest:version="1.2" />
  <manifest:file-entry manifest:media-type="application/xml" manifest:full-path="meta.xml" manifest:version="1.2" />
  <manifest:file-entry manifest:media-type="application/xml" manifest:full-path="settings.xml" manifest:version="1.2" />
</manifest:manifest>    
'''
    _MANIFEST_RDF = '''<?xml version="1.0" encoding="utf-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about="styles.xml">
    <rdf:type rdf:resource="http://docs.oasis-open.org/ns/office/1.2/meta/odf#StylesFile"/>
  </rdf:Description>
  <rdf:Description rdf:about="">
    <ns0:hasPart xmlns:ns0="http://docs.oasis-open.org/ns/office/1.2/meta/pkg#" rdf:resource="styles.xml"/>
  </rdf:Description>
  <rdf:Description rdf:about="content.xml">
    <rdf:type rdf:resource="http://docs.oasis-open.org/ns/office/1.2/meta/odf#ContentFile"/>
  </rdf:Description>
  <rdf:Description rdf:about="">
    <ns0:hasPart xmlns:ns0="http://docs.oasis-open.org/ns/office/1.2/meta/pkg#" rdf:resource="content.xml"/>
  </rdf:Description>
  <rdf:Description rdf:about="">
    <rdf:type rdf:resource="http://docs.oasis-open.org/ns/office/1.2/meta/pkg#Document"/>
  </rdf:Description>
</rdf:RDF>
'''
    _SETTINGS_XML = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-settings xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:config="urn:oasis:names:tc:opendocument:xmlns:config:1.0" xmlns:ooo="http://openoffice.org/2004/office" office:version="1.2">
 <office:settings>
  <config:config-item-set config:name="ooo:view-settings">
   <config:config-item config:name="ViewAreaTop" config:type="int">0</config:config-item>
   <config:config-item config:name="ViewAreaLeft" config:type="int">0</config:config-item>
   <config:config-item config:name="ViewAreaWidth" config:type="int">30508</config:config-item>
   <config:config-item config:name="ViewAreaHeight" config:type="int">27783</config:config-item>
   <config:config-item config:name="ShowRedlineChanges" config:type="boolean">true</config:config-item>
   <config:config-item config:name="InBrowseMode" config:type="boolean">false</config:config-item>
   <config:config-item-map-indexed config:name="Views">
    <config:config-item-map-entry>
     <config:config-item config:name="ViewId" config:type="string">view2</config:config-item>
     <config:config-item config:name="ViewLeft" config:type="int">8079</config:config-item>
     <config:config-item config:name="ViewTop" config:type="int">3501</config:config-item>
     <config:config-item config:name="VisibleLeft" config:type="int">0</config:config-item>
     <config:config-item config:name="VisibleTop" config:type="int">0</config:config-item>
     <config:config-item config:name="VisibleRight" config:type="int">30506</config:config-item>
     <config:config-item config:name="VisibleBottom" config:type="int">27781</config:config-item>
     <config:config-item config:name="ZoomType" config:type="short">0</config:config-item>
     <config:config-item config:name="ViewLayoutColumns" config:type="short">0</config:config-item>
     <config:config-item config:name="ViewLayoutBookMode" config:type="boolean">false</config:config-item>
     <config:config-item config:name="ZoomFactor" config:type="short">100</config:config-item>
     <config:config-item config:name="IsSelectedFrame" config:type="boolean">false</config:config-item>
    </config:config-item-map-entry>
   </config:config-item-map-indexed>
  </config:config-item-set>
  <config:config-item-set config:name="ooo:configuration-settings">
   <config:config-item config:name="AddParaSpacingToTableCells" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrintPaperFromSetup" config:type="boolean">false</config:config-item>
   <config:config-item config:name="IsKernAsianPunctuation" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintReversed" config:type="boolean">false</config:config-item>
   <config:config-item config:name="LinkUpdateMode" config:type="short">1</config:config-item>
   <config:config-item config:name="DoNotCaptureDrawObjsOnPage" config:type="boolean">false</config:config-item>
   <config:config-item config:name="SaveVersionOnClose" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintEmptyPages" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrintSingleJobs" config:type="boolean">false</config:config-item>
   <config:config-item config:name="AllowPrintJobCancel" config:type="boolean">true</config:config-item>
   <config:config-item config:name="AddFrameOffsets" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintLeftPages" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrintTables" config:type="boolean">true</config:config-item>
   <config:config-item config:name="ProtectForm" config:type="boolean">false</config:config-item>
   <config:config-item config:name="ChartAutoUpdate" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrintControls" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrinterSetup" config:type="base64Binary">8gT+/0hQIExhc2VySmV0IFAyMDE0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASFAgTGFzZXJKZXQgUDIwMTQAAAAAAAAAAAAAAAAAAAAWAAEAGAQAAAAAAAAEAAhSAAAEdAAAM1ROVwIACABIAFAAIABMAGEAcwBlAHIASgBlAHQAIABQADIAMAAxADQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQQDANwANAMPnwAAAQAJAJoLNAgAAAEABwBYAgEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAU0RETQAGAAAABgAASFAgTGFzZXJKZXQgUDIwMTQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAAAAAEAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAAAAAABAAAAAQAAABoEAAAAAAAAAAAAAAAAAAAPAAAALQAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAgICAAP8AAAD//wAAAP8AAAD//wAAAP8A/wD/AAAAAAAAAAAAAAAAAAAAAAAoAAAAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADeAwAA3gMAAAAAAAAAAAAAAIAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABrjvBgNAMAAAAAAAAAAAAABIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABIAQ09NUEFUX0RVUExFWF9NT0RFCgBEVVBMRVhfT0ZG</config:config-item>
   <config:config-item config:name="CurrentDatabaseDataSource" config:type="string"/>
   <config:config-item config:name="LoadReadonly" config:type="boolean">false</config:config-item>
   <config:config-item config:name="CurrentDatabaseCommand" config:type="string"/>
   <config:config-item config:name="ConsiderTextWrapOnObjPos" config:type="boolean">false</config:config-item>
   <config:config-item config:name="ApplyUserData" config:type="boolean">true</config:config-item>
   <config:config-item config:name="AddParaTableSpacing" config:type="boolean">true</config:config-item>
   <config:config-item config:name="FieldAutoUpdate" config:type="boolean">true</config:config-item>
   <config:config-item config:name="IgnoreFirstLineIndentInNumbering" config:type="boolean">false</config:config-item>
   <config:config-item config:name="TabsRelativeToIndent" config:type="boolean">true</config:config-item>
   <config:config-item config:name="IgnoreTabsAndBlanksForLineCalculation" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintAnnotationMode" config:type="short">0</config:config-item>
   <config:config-item config:name="AddParaTableSpacingAtStart" config:type="boolean">true</config:config-item>
   <config:config-item config:name="UseOldPrinterMetrics" config:type="boolean">false</config:config-item>
   <config:config-item config:name="TableRowKeep" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrinterName" config:type="string">HP LaserJet P2014</config:config-item>
   <config:config-item config:name="PrintFaxName" config:type="string"/>
   <config:config-item config:name="UnxForceZeroExtLeading" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintTextPlaceholder" config:type="boolean">false</config:config-item>
   <config:config-item config:name="DoNotJustifyLinesWithManualBreak" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintRightPages" config:type="boolean">true</config:config-item>
   <config:config-item config:name="CharacterCompressionType" config:type="short">0</config:config-item>
   <config:config-item config:name="UseFormerTextWrapping" config:type="boolean">false</config:config-item>
   <config:config-item config:name="IsLabelDocument" config:type="boolean">false</config:config-item>
   <config:config-item config:name="AlignTabStopPosition" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrintHiddenText" config:type="boolean">false</config:config-item>
   <config:config-item config:name="DoNotResetParaAttrsForNumFont" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintPageBackground" config:type="boolean">true</config:config-item>
   <config:config-item config:name="CurrentDatabaseCommandType" config:type="int">0</config:config-item>
   <config:config-item config:name="OutlineLevelYieldsNumbering" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintProspect" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintGraphics" config:type="boolean">true</config:config-item>
   <config:config-item config:name="SaveGlobalDocumentLinks" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintProspectRTL" config:type="boolean">false</config:config-item>
   <config:config-item config:name="UseFormerLineSpacing" config:type="boolean">false</config:config-item>
   <config:config-item config:name="AddExternalLeading" config:type="boolean">true</config:config-item>
   <config:config-item config:name="UseFormerObjectPositioning" config:type="boolean">false</config:config-item>
   <config:config-item config:name="RedlineProtectionKey" config:type="base64Binary"/>
   <config:config-item config:name="MathBaselineAlignment" config:type="boolean">false</config:config-item>
   <config:config-item config:name="ClipAsCharacterAnchoredWriterFlyFrames" config:type="boolean">false</config:config-item>
   <config:config-item config:name="UseOldNumbering" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintDrawings" config:type="boolean">true</config:config-item>
   <config:config-item config:name="PrinterIndependentLayout" config:type="string">disabled</config:config-item>
   <config:config-item config:name="TabAtLeftIndentForParagraphsInList" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrintBlackFonts" config:type="boolean">false</config:config-item>
   <config:config-item config:name="UpdateFromTemplate" config:type="boolean">true</config:config-item>
  </config:config-item-set>
 </office:settings>
</office:document-settings>
'''
    _STYLES_XML = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:ooow="http://openoffice.org/2004/writer" xmlns:oooc="http://openoffice.org/2004/calc" xmlns:dom="http://www.w3.org/2001/xml-events" xmlns:rpt="http://openoffice.org/2005/report" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:grddl="http://www.w3.org/2003/g/data-view#" xmlns:tableooo="http://openoffice.org/2009/table" xmlns:loext="urn:org:documentfoundation:names:experimental:office:xmlns:loext:1.0">
 <office:font-face-decls>
  <style:font-face style:name="StarSymbol" svg:font-family="StarSymbol" style:font-charset="x-symbol"/>
  <style:font-face style:name="Segoe UI" svg:font-family="&apos;Segoe UI&apos;"/>
  <style:font-face style:name="Courier New" svg:font-family="&apos;Courier New&apos;" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
  <style:font-face style:name="Consolas" svg:font-family="Consolas" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
  </office:font-face-decls>
 <office:styles>
  <style:default-style style:family="graphic">
   <style:graphic-properties svg:stroke-color="#3465a4" draw:fill-color="#729fcf" fo:wrap-option="no-wrap" draw:shadow-offset-x="0.3cm" draw:shadow-offset-y="0.3cm" draw:start-line-spacing-horizontal="0.283cm" draw:start-line-spacing-vertical="0.283cm" draw:end-line-spacing-horizontal="0.283cm" draw:end-line-spacing-vertical="0.283cm" style:flow-with-text="true"/>
   <style:paragraph-properties style:text-autospace="ideograph-alpha" style:line-break="strict" style:writing-mode="lr-tb" style:font-independent-line-spacing="false">
    <style:tab-stops/>
   </style:paragraph-properties>
   <style:text-properties fo:color="#000000" fo:font-size="10pt" fo:language="$Language" fo:country="$Country" style:font-size-asian="10pt" style:language-asian="zxx" style:country-asian="none" style:font-size-complex="1pt" style:language-complex="zxx" style:country-complex="none"/>
  </style:default-style>
  <style:default-style style:family="paragraph">
   <style:paragraph-properties fo:hyphenation-ladder-count="no-limit" style:text-autospace="ideograph-alpha" style:punctuation-wrap="hanging" style:line-break="strict" style:tab-stop-distance="1.251cm" style:writing-mode="lr-tb"/>
   <style:text-properties fo:color="#000000" style:font-name="Segoe UI" fo:font-size="10pt" fo:language="$Language" fo:country="$Country" style:font-name-asian="Segoe UI" style:font-size-asian="10pt" style:language-asian="zxx" style:country-asian="none" style:font-name-complex="Segoe UI" style:font-size-complex="1pt" style:language-complex="zxx" style:country-complex="none" fo:hyphenate="false" fo:hyphenation-remain-char-count="2" fo:hyphenation-push-char-count="2"/>
  </style:default-style>
  <style:style style:name="Standard" style:family="paragraph" style:class="text" style:master-page-name="">
   <style:paragraph-properties fo:line-height="0.73cm" style:page-number="auto"/>
   <style:text-properties style:font-name="Courier New" fo:font-size="12pt" fo:font-weight="normal"/>
  </style:style>
  <style:style style:name="Text_20_body" style:display-name="Text body" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="First_20_line_20_indent" style:class="text" style:master-page-name="">
   <style:paragraph-properties style:page-number="auto">
    <style:tab-stops/>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="First_20_line_20_indent" style:display-name="First line indent" style:family="paragraph" style:parent-style-name="Text_20_body" style:class="text" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin="100%" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="0.499cm" style:auto-text-indent="false" style:page-number="auto"/>
  </style:style>
  <style:style style:name="Hanging_20_indent" style:display-name="Hanging indent" style:family="paragraph" style:parent-style-name="Text_20_body" style:class="text">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin="100%" fo:margin-left="1cm" fo:margin-right="0cm" fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="-0.499cm" style:auto-text-indent="false">
    <style:tab-stops>
     <style:tab-stop style:position="0cm"/>
    </style:tab-stops>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Text_20_body_20_indent" style:display-name="Text body indent" style:family="paragraph" style:parent-style-name="Text_20_body" style:class="text">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin="100%" fo:margin-left="0.499cm" fo:margin-right="0cm" fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="0cm" style:auto-text-indent="false"/>
  </style:style>
  <style:style style:name="Heading" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Text_20_body" style:class="text" style:master-page-name="">
   <style:paragraph-properties fo:line-height="0.73cm" fo:text-align="center" style:justify-single-word="false" style:page-number="auto" fo:keep-with-next="always">
    <style:tab-stops/>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Heading_20_1" style:display-name="Heading 1" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="1" style:list-style-name="" style:class="text" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin-top="1.461cm" fo:margin-bottom="0.73cm" style:page-number="auto">
    <style:tab-stops/>
   </style:paragraph-properties>
   <style:text-properties fo:text-transform="uppercase" fo:font-weight="bold"/>
  </style:style>
  <style:style style:name="Heading_20_2" style:display-name="Heading 2" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="2" style:list-style-name="" style:class="text" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin-top="1.461cm" fo:margin-bottom="0.73cm" style:page-number="auto"/>
   <style:text-properties fo:font-weight="bold"/>
  </style:style>
  <style:style style:name="Heading_20_3" style:display-name="Heading 3" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="3" style:list-style-name="" style:class="text" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin-top="0.73cm" fo:margin-bottom="0.73cm" style:page-number="auto"/>
   <style:text-properties fo:font-style="italic"/>
  </style:style>
  <style:style style:name="Heading_20_4" style:display-name="Heading 4" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text" style:master-page-name="">
   <style:paragraph-properties fo:margin-top="0.73cm" fo:margin-bottom="0.73cm" style:page-number="auto"/>
  </style:style>
  <style:style style:name="Heading_20_5" style:display-name="Heading 5" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text" style:master-page-name="">
   <style:paragraph-properties style:page-number="auto"/>
  </style:style>
  <style:style style:name="Heading_20_6" style:display-name="Heading 6" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text"/>
  <style:style style:name="Heading_20_7" style:display-name="Heading 7" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text"/>
  <style:style style:name="Heading_20_8" style:display-name="Heading 8" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text"/>
  <style:style style:name="Heading_20_9" style:display-name="Heading 9" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="" style:list-style-name="" style:class="text"/>
  <style:style style:name="Heading_20_10" style:display-name="Heading 10" style:family="paragraph" style:parent-style-name="Heading" style:next-style-name="Text_20_body" style:default-outline-level="10" style:list-style-name="" style:class="text">
   <style:text-properties fo:font-size="75%" fo:font-weight="bold"/>
  </style:style>
  <style:style style:name="Header" style:family="paragraph" style:parent-style-name="Standard" style:class="extra" style:master-page-name="">
   <style:paragraph-properties fo:text-align="end" style:justify-single-word="false" style:page-number="auto" fo:padding="0.049cm" fo:border-left="none" fo:border-right="none" fo:border-top="none" fo:border-bottom="0.002cm solid #000000" style:shadow="none">
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
   <style:text-properties fo:font-variant="normal" fo:text-transform="none" fo:font-style="italic"/>
  </style:style>
  <style:style style:name="Header_20_left" style:display-name="Header left" style:family="paragraph" style:parent-style-name="Standard" style:class="extra">
   <style:paragraph-properties>
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Header_20_right" style:display-name="Header right" style:family="paragraph" style:parent-style-name="Standard" style:class="extra">
   <style:paragraph-properties>
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Footer" style:family="paragraph" style:parent-style-name="Standard" style:class="extra" style:master-page-name="">
   <style:paragraph-properties fo:text-align="center" style:justify-single-word="false" style:page-number="auto" text:number-lines="false" text:line-number="0">
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
   <style:text-properties fo:font-size="11pt"/>
  </style:style>
  <style:style style:name="Footer_20_left" style:display-name="Footer left" style:family="paragraph" style:parent-style-name="Standard" style:class="extra">
   <style:paragraph-properties>
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Footer_20_right" style:display-name="Footer right" style:family="paragraph" style:parent-style-name="Standard" style:class="extra">
   <style:paragraph-properties>
    <style:tab-stops>
     <style:tab-stop style:position="8.5cm" style:type="center"/>
     <style:tab-stop style:position="17.002cm" style:type="right"/>
    </style:tab-stops>
   </style:paragraph-properties>
  </style:style>
  <style:style style:name="Title" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Subtitle" style:class="chapter" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin="100%" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="0.000cm" fo:margin-bottom="0cm" fo:line-height="200%" fo:text-align="center" style:justify-single-word="false" fo:text-indent="0cm" style:auto-text-indent="false" style:page-number="auto" fo:background-color="transparent" fo:padding="0cm" fo:border="none" text:number-lines="false" text:line-number="0">
    <style:tab-stops/>
    <style:background-image/>
   </style:paragraph-properties>
   <style:text-properties fo:text-transform="uppercase" fo:font-weight="normal" style:letter-kerning="false"/>
  </style:style>
  <style:style style:name="Subtitle" style:family="paragraph" style:parent-style-name="Title" style:class="chapter" style:master-page-name="">
   <style:paragraph-properties loext:contextual-spacing="false" fo:margin-top="0cm" fo:margin-bottom="0cm" style:page-number="auto"/>
   <style:text-properties fo:font-variant="normal" fo:text-transform="none" fo:letter-spacing="normal" fo:font-style="italic" fo:font-weight="normal"/>
  </style:style>
  <style:style style:name="Quotations" style:family="paragraph" style:parent-style-name="Text_20_body" style:class="html">
   <style:paragraph-properties fo:margin="100%" fo:margin-left="1cm" fo:margin-right="0cm" fo:margin-top="0cm" fo:margin-bottom="0cm" fo:text-indent="0cm" style:auto-text-indent="false"/>
   <style:text-properties style:font-name="Consolas"/>
  </style:style>
  <style:style style:name="scene_20_mark" style:display-name="Scene mark" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Standard" style:class="text">
   <style:text-properties fo:color="#008000" fo:font-size="10pt" fo:language="zxx" fo:country="none"/>
  </style:style>
  <style:style style:name="scene_20_mark_20_unused" style:display-name="Scene mark (unused type)" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Standard" style:class="text">
   <style:text-properties fo:color="#808080" fo:font-size="10pt" fo:language="zxx" fo:country="none"/>
  </style:style>
  <style:style style:name="scene_20_mark_20_notes" style:display-name="Scene mark (notes type)" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Standard" style:class="text">
   <style:text-properties fo:color="#0000FF" fo:font-size="10pt" fo:language="zxx" fo:country="none"/>
  </style:style>
  <style:style style:name="scene_20_mark_20_todo" style:display-name="Scene mark (todo type)" style:family="paragraph" style:parent-style-name="Standard" style:next-style-name="Standard" style:class="text">
   <style:text-properties fo:color="#B22222" fo:font-size="10pt" fo:language="zxx" fo:country="none"/>
  </style:style>
  <style:style style:name="Emphasis" style:family="text">
   <style:text-properties fo:font-style="italic" fo:background-color="transparent"/>
  </style:style>
  <style:style style:name="Strong_20_Emphasis" style:display-name="Strong Emphasis" style:family="text">
   <style:text-properties fo:text-transform="uppercase"/>
  </style:style>
 </office:styles>
 <office:automatic-styles>
  <style:page-layout style:name="Mpm1">
   <style:page-layout-properties fo:page-width="21.001cm" fo:page-height="29.7cm" style:num-format="1" style:paper-tray-name="[From printer settings]" style:print-orientation="portrait" fo:margin-top="3.2cm" fo:margin-bottom="2.499cm" fo:margin-left="2.701cm" fo:margin-right="3cm" style:writing-mode="lr-tb" style:layout-grid-color="#c0c0c0" style:layout-grid-lines="20" style:layout-grid-base-height="0.706cm" style:layout-grid-ruby-height="0.353cm" style:layout-grid-mode="none" style:layout-grid-ruby-below="false" style:layout-grid-print="false" style:layout-grid-display="false" style:footnote-max-height="0cm">
    <style:columns fo:column-count="1" fo:column-gap="0cm"/>
    <style:footnote-sep style:width="0.018cm" style:distance-before-sep="0.101cm" style:distance-after-sep="0.101cm" style:adjustment="left" style:rel-width="25%" style:color="#000000"/>
   </style:page-layout-properties>
   <style:header-style/>
   <style:footer-style>
    <style:header-footer-properties fo:min-height="1.699cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="1.199cm" style:shadow="none" style:dynamic-spacing="false"/>
   </style:footer-style>
  </style:page-layout>
 </office:automatic-styles>
 <office:master-styles>
  <style:master-page style:name="Standard" style:page-layout-name="Mpm1">
   <style:footer>
    <text:p text:style-name="Footer"><text:page-number text:select-page="current"/></text:p>
   </style:footer>
  </style:master-page>
 </office:master-styles>
</office:document-styles>
'''
    _MIMETYPE = 'application/vnd.oasis.opendocument.text'

    def _convert_from_yw(self, text, quick=False):
        if text:
            ODT_REPLACEMENTS = [
                ('&', '&amp;'),
                ('>', '&gt;'),
                ('<', '&lt;'),
                ("'", '&apos;'),
                ('"', '&quot;'),
                ]
            if not quick:
                ODT_REPLACEMENTS.extend([
                    ('\n\n', '</text:p>\r<text:p text:style-name="First_20_line_20_indent" />\r<text:p text:style-name="Text_20_body">'),
                    ('\n', '</text:p>\r<text:p text:style-name="First_20_line_20_indent">'),
                    ('\r', '\n'),
                    ])
            for yw, od in ODT_REPLACEMENTS:
                text = text.replace(yw, od)
        else:
            text = ''
        return text

    def _get_sceneMapping(self, scId, sceneNumber, wordsTotal, lettersTotal):
        sceneMapping = super()._get_sceneMapping(scId, sceneNumber, wordsTotal, lettersTotal)
        sceneMapping['sceneTitle'] = _('Scene')
        return sceneMapping

    def _set_up(self):

        super()._set_up()

        try:
            with open(f'{self._tempDir}/manifest.rdf', 'w', encoding='utf-8') as f:
                f.write(self._MANIFEST_RDF)
        except:
            raise Error(f'{_("Cannot write file")}: "manifest.rdf"')



class OdtWFormatted(OdtWriter):
    _CONTENT_XML_HEADER = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:ooow="http://openoffice.org/2004/writer" xmlns:oooc="http://openoffice.org/2004/calc" xmlns:dom="http://www.w3.org/2001/xml-events" xmlns:xforms="http://www.w3.org/2002/xforms" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:rpt="http://openoffice.org/2005/report" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:grddl="http://www.w3.org/2003/g/data-view#" xmlns:tableooo="http://openoffice.org/2009/table" xmlns:field="urn:openoffice:names:experimental:ooo-ms-interop:xmlns:field:1.0" office:version="1.2">
 <office:scripts/>
 <office:font-face-decls>
  <style:font-face style:name="StarSymbol" svg:font-family="StarSymbol" style:font-charset="x-symbol"/>
  <style:font-face style:name="Consolas" svg:font-family="Consolas" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
  <style:font-face style:name="Courier New" svg:font-family="&apos;Courier New&apos;" style:font-adornments="Standard" style:font-family-generic="modern" style:font-pitch="fixed"/>
 </office:font-face-decls>
 $automaticStyles
 <office:body>
  <office:text text:use-soft-page-breaks="true">

'''

    def write(self):
        if self.novel.languages is None:
            self.novel.get_languages()
        return super().write()

    def _convert_from_yw(self, text, quick=False):
        if text:
            odtReplacements = [
                ('&', '&amp;'),
                ('>', '&gt;'),
                ('<', '&lt;'),
                ("'", '&apos;'),
                ('"', '&quot;'),
                ]
            if not quick:
                tags = ['i', 'b']
                odtReplacements.extend(self._get_replacements())
                for i, language in enumerate(self.novel.languages, 1):
                    tags.append(f'lang={language}')
                    odtReplacements.append((f'[lang={language}]', f'<text:span text:style-name="T{i}">'))
                    odtReplacements.append((f'[/lang={language}]', '</text:span>'))

                newlines = []
                lines = text.split('\n')
                isOpen = {}
                opening = {}
                closing = {}
                for tag in tags:
                    isOpen[tag] = False
                    opening[tag] = f'[{tag}]'
                    closing[tag] = f'[/{tag}]'
                for line in lines:
                    for tag in tags:
                        if isOpen[tag]:
                            if line.startswith('&gt; '):
                                line = f"&gt; {opening[tag]}{line.lstrip('&gt; ')}"
                            else:
                                line = f'{opening[tag]}{line}'
                            isOpen[tag] = False
                        while line.count(opening[tag]) > line.count(closing[tag]):
                            line = f'{line}{closing[tag]}'
                            isOpen[tag] = True
                        while line.count(closing[tag]) > line.count(opening[tag]):
                            line = f'{opening[tag]}{line}'
                        line = line.replace(f'{opening[tag]}{closing[tag]}', '')
                    newlines.append(line)
                text = '\n'.join(newlines).rstrip()

            for yw, od in odtReplacements:
                text = text.replace(yw, od)

            text = re.sub('\[\/*[h|c|r|s|u]\d*\]', '', text)
        else:
            text = ''
        return text

    def _get_fileHeaderMapping(self):
        styleMapping = {}
        if self.novel.languages:
            lines = ['<office:automatic-styles>']
            for i, language in enumerate(self.novel.languages, 1):
                try:
                    lngCode, ctrCode = language.split('-')
                except:
                    lngCode = 'zxx'
                    ctrCode = 'none'
                lines.append((f'  <style:style style:name="T{i}" style:family="text">\n'
                              f'   <style:text-properties fo:language="{lngCode}" fo:country="{ctrCode}" '
                              f'style:language-asian="{lngCode}" style:country-asian="{ctrCode}" '
                              f'style:language-complex="{lngCode}" style:country-complex="{ctrCode}"/>\n'
                              '  </style:style>'))
            lines.append(' </office:automatic-styles>')
            styleMapping['automaticStyles'] = '\n'.join(lines)
        else:
            styleMapping['automaticStyles'] = '<office:automatic-styles/>'
        template = Template(self._CONTENT_XML_HEADER)
        projectTemplateMapping = super()._get_fileHeaderMapping()
        projectTemplateMapping['ContentHeader'] = template.safe_substitute(styleMapping)
        return projectTemplateMapping

    def _get_replacements(self):
        return [
                ('\n\n', ('</text:p>\r<text:p text:style-name="First_20_line_20_indent" />\r'
                          '<text:p text:style-name="Text_20_body">')),
                ('\n', '</text:p>\r<text:p text:style-name="First_20_line_20_indent">'),
                ('\r', '\n'),
                ('[i]', '<text:span text:style-name="Emphasis">'),
                ('[/i]', '</text:span>'),
                ('[b]', '<text:span text:style-name="Strong_20_Emphasis">'),
                ('[/b]', '</text:span>'),
                ('/*', f'<office:annotation><dc:creator>{self.novel.authorName}</dc:creator><text:p>'),
                ('*/', '</text:p></office:annotation>'),
                ]

    def _get_text(self):
        lines = self._get_fileHeader()
        lines.extend(self._get_chapters())
        lines.append(self._fileFooter)
        text = ''.join(lines)

        if '&gt; ' in text:
            quotMarks = ('"First_20_line_20_indent">&gt; ',
                         '"Text_20_body">&gt; ',
                         )
            for quotMark in quotMarks:
                text = text.replace(quotMark, '"Quotations">')
            text = re.sub('"Text_20_body"\>(\<office\:annotation\>.+?\<\/office\:annotation\>)\&gt\; ',
                          '"Quotations">\\1', text)
        return text



class OdtWProof(OdtWFormatted):
    DESCRIPTION = _('Tagged manuscript for proofing')
    SUFFIX = '_proof'

    _fileHeader = f'''$ContentHeader<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _partTemplate = '''<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _chapterTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title</text:h>
'''

    _sceneTemplate = '''<text:h text:style-name="Heading_20_3" text:outline-level="3">$Title</text:h>
<text:p text:style-name="scene_20_mark">[ScID:$ID]</text:p>
<text:p text:style-name="Text_20_body">$SceneContent</text:p>
<text:p text:style-name="scene_20_mark">[/ScID]</text:p>
'''

    _fileFooter = OdtWFormatted._CONTENT_XML_FOOTER

    def _convert_from_yw(self, text, quick=False):
        if text:
            odtReplacements = [
                ('&', '&amp;'),
                ('>', '&gt;'),
                ('<', '&lt;'),
                ("'", '&apos;'),
                ('"', '&quot;'),
                ]
            tags = ['i', 'b']
            odtReplacements.extend([
                ('\n\n', '</text:p>\r<text:p text:style-name="First_20_line_20_indent" />\r<text:p text:style-name="Text_20_body">'),
                ('\n', '</text:p>\r<text:p text:style-name="First_20_line_20_indent">'),
                ('\r', '\n'),
                ('[/i]', '</text:span>'),
                ('[/b]', '</text:span>'),
                ('/*', f'<office:annotation><dc:creator>{self.novel.authorName}</dc:creator><text:p>'),
                ('*/', '</text:p></office:annotation>'),
            ])
            i = 0
            for i, language in enumerate(self.novel.languages, 1):
                tags.append(f'lang={language}')
                odtReplacements.append((f'[lang={language}]', f'<text:span text:style-name="T{i}">'))
                odtReplacements.append((f'[/lang={language}]', '</text:span>'))
            odtReplacements.extend([
                ('[i]', f'<text:span text:style-name="T{i+1}">'),
                ('[b]', f'<text:span text:style-name="T{i+2}">'),
            ])

            newlines = []
            lines = text.split('\n')
            isOpen = {}
            opening = {}
            closing = {}
            for tag in tags:
                isOpen[tag] = False
                opening[tag] = f'[{tag}]'
                closing[tag] = f'[/{tag}]'
            for line in lines:
                for tag in tags:
                    if isOpen[tag]:
                        if line.startswith('&gt; '):
                            line = f"&gt; {opening[tag]}{line.lstrip('&gt; ')}"
                        else:
                            line = f'{opening[tag]}{line}'
                        isOpen[tag] = False
                    while line.count(opening[tag]) > line.count(closing[tag]):
                        line = f'{line}{closing[tag]}'
                        isOpen[tag] = True
                    while line.count(closing[tag]) > line.count(opening[tag]):
                        line = f'{opening[tag]}{line}'
                    line = line.replace(f'{opening[tag]}{closing[tag]}', '')
                newlines.append(line)
            text = '\n'.join(newlines).rstrip()

            for yw, od in odtReplacements:
                text = text.replace(yw, od)

            text = re.sub('\[\/*[h|c|r|s|u]\d*\]', '', text)
        else:
            text = ''
        return text

    def _get_fileHeaderMapping(self):
        styleMapping = {}
        i = 0
        lines = ['<office:automatic-styles>']
        for i, language in enumerate(self.novel.languages, 1):
            try:
                lngCode, ctrCode = language.split('-')
            except:
                lngCode = 'zxx'
                ctrCode = 'none'
            lines.append(f'''  <style:style style:name="T{i}" style:family="text">
   <style:text-properties fo:language="{lngCode}" fo:country="{ctrCode}" style:language-asian="{lngCode}" style:country-asian="{ctrCode}" style:language-complex="{lngCode}" style:country-complex="{ctrCode}"/>
  </style:style>''')
        lines.append(f'''  <style:style style:name="T{i+1}" style:family="text">
   <style:text-properties fo:font-style="italic" style:font-style-asian="italic" style:font-style-complex="italic"/>
  </style:style>''')
        lines.append(f'''  <style:style style:name="T{i+2}" style:family="text">
   <style:text-properties fo:font-weight="bold" style:font-weight-asian="bold" style:font-weight-complex="bold"/>
  </style:style>''')
        lines.append(' </office:automatic-styles>')
        styleMapping['automaticStyles'] = '\n'.join(lines)
        template = Template(self._CONTENT_XML_HEADER)
        projectTemplateMapping = super()._get_fileHeaderMapping()
        projectTemplateMapping['ContentHeader'] = template.safe_substitute(styleMapping)
        return projectTemplateMapping

    def _get_text(self):
        lines = self._get_fileHeader()
        lines.extend(self._get_chapters())
        lines.append(self._fileFooter)
        text = ''.join(lines)
        return text


class OdtWManuscript(OdtWFormatted):
    DESCRIPTION = _('Editable manuscript')
    SUFFIX = '_manuscript'

    _fileHeader = f'''$ContentHeader<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _partTemplate = '''<text:section text:style-name="Sect1" text:name="ChID:$ID">
<text:h text:style-name="Heading_20_1" text:outline-level="1"><text:a xlink:href="../${ProjectName}_parts.odt#ChID:$ID%7Cregion">$Title</text:a></text:h>
'''

    _chapterTemplate = '''<text:section text:style-name="Sect1" text:name="ChID:$ID">
<text:h text:style-name="Heading_20_2" text:outline-level="2"><text:a xlink:href="../${ProjectName}_chapters.odt#ChID:$ID%7Cregion">$Title</text:a></text:h>
'''

    _sceneTemplate = '''<text:section text:style-name="Sect1" text:name="ScID:$ID">
<text:p text:style-name="Text_20_body"><office:annotation><dc:creator>$sceneTitle</dc:creator><text:p>~ ${Title} ~</text:p><text:p/><text:p><text:a xlink:href="../${ProjectName}_scenes.odt#ScID:$ID%7Cregion">→$Summary</text:a></text:p></office:annotation>$SceneContent</text:p>
</text:section>
'''

    _appendedSceneTemplate = '''<text:section text:style-name="Sect1" text:name="ScID:$ID">
<text:p text:style-name="First_20_line_20_indent"><office:annotation>
<dc:creator>$sceneTitle</dc:creator>
<text:p>~ ${Title} ~</text:p>
<text:p/>
<text:p><text:a xlink:href="../${ProjectName}_scenes.odt#ScID:$ID%7Cregion">→$Summary</text:a></text:p>
</office:annotation>$SceneContent</text:p>
</text:section>
'''

    _sceneDivider = '<text:p text:style-name="Heading_20_4">* * *</text:p>\n'

    _chapterEndTemplate = '''</text:section>
'''

    _fileFooter = OdtWFormatted._CONTENT_XML_FOOTER

    def _get_chapterMapping(self, chId, chapterNumber):
        chapterMapping = super()._get_chapterMapping(chId, chapterNumber)
        if self.novel.chapters[chId].suppressChapterTitle:
            chapterMapping['Title'] = ''
        return chapterMapping

    def _get_sceneMapping(self, scId, sceneNumber, wordsTotal, lettersTotal):
        sceneMapping = super()._get_sceneMapping(scId, sceneNumber, wordsTotal, lettersTotal)
        sceneMapping['Summary'] = _('Summary')
        return sceneMapping



class OdtWSceneDesc(OdtWriter):
    DESCRIPTION = _('Scene descriptions')
    SUFFIX = '_scenes'

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _partTemplate = '''<text:section text:style-name="Sect1" text:name="ChID:$ID">
<text:h text:style-name="Heading_20_1" text:outline-level="1"><text:a xlink:href="../${ProjectName}_parts.odt#ChID:$ID%7Cregion">$Title</text:a></text:h>
'''

    _chapterTemplate = '''<text:section text:style-name="Sect1" text:name="ChID:$ID">
<text:h text:style-name="Heading_20_2" text:outline-level="2"><text:a xlink:href="../${ProjectName}_chapters.odt#ChID:$ID%7Cregion">$Title</text:a></text:h>
'''

    _sceneTemplate = '''<text:section text:style-name="Sect1" text:name="ScID:$ID">
<text:p text:style-name="Text_20_body"><office:annotation>
<dc:creator>$sceneTitle</dc:creator>
<text:p>~ ${Title} ~</text:p>
<text:p/>
<text:p><text:a xlink:href="../${ProjectName}_manuscript.odt#ScID:$ID%7Cregion">→$Manuscript</text:a></text:p>
</office:annotation>$Desc</text:p>
</text:section>
'''

    _appendedSceneTemplate = '''<text:section text:style-name="Sect1" text:name="ScID:$ID">
<text:p text:style-name="First_20_line_20_indent"><office:annotation>
<dc:creator>$sceneTitle</dc:creator>
<text:p>~ ${Title} ~</text:p>
<text:p/>
<text:p><text:a xlink:href="../${ProjectName}_manuscript.odt#ScID:$ID%7Cregion">→$Manuscript</text:a></text:p>
</office:annotation>$Desc</text:p>
</text:section>
'''

    _sceneDivider = '''<text:p text:style-name="Heading_20_4">* * *</text:p>
'''

    _chapterEndTemplate = '''</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_sceneMapping(self, scId, sceneNumber, wordsTotal, lettersTotal):
        sceneMapping = super()._get_sceneMapping(scId, sceneNumber, wordsTotal, lettersTotal)
        sceneMapping['Manuscript'] = _('Manuscript')
        return sceneMapping


class OdtWChapterDesc(OdtWriter):
    DESCRIPTION = _('Chapter descriptions')
    SUFFIX = '_chapters'

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _partTemplate = '''<text:h text:style-name="Heading_20_1" text:outline-level="1"><text:a xlink:href="../${ProjectName}_parts.odt#ChID:$ID%7Cregion">$Title</text:a></text:h>
'''

    _chapterTemplate = '''<text:section text:style-name="Sect1" text:name="ChID:$ID">
<text:h text:style-name="Heading_20_2" text:outline-level="2"><text:a xlink:href="../${ProjectName}_manuscript.odt#ChID:$ID%7Cregion">$Title</text:a></text:h>
<text:p text:style-name="Text_20_body">$Desc</text:p>
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER


class OdtWPartDesc(OdtWriter):
    DESCRIPTION = _('Part descriptions')
    SUFFIX = '_parts'

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _partTemplate = '''<text:section text:style-name="Sect1" text:name="ChID:$ID">
<text:h text:style-name="Heading_20_1" text:outline-level="1"><text:a xlink:href="../${ProjectName}_manuscript.odt#ChID:$ID%7Cregion">$Title</text:a></text:h>
<text:p text:style-name="Text_20_body">$Desc</text:p>
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER


class OdtWBriefSynopsis(OdtWriter):
    DESCRIPTION = _('Brief synopsis')
    SUFFIX = '_brf_synopsis'

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _partTemplate = '''<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _chapterTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title</text:h>
'''

    _sceneTemplate = '''<text:p text:style-name="Text_20_body">$Title</text:p>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER


class OdtWExport(OdtWFormatted):
    DESCRIPTION = _('manuscript')
    _fileHeader = f'''$ContentHeader<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _partTemplate = '''<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _chapterTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title</text:h>
'''

    _sceneTemplate = ''''<text:p text:style-name="Text_20_body"><office:annotation><dc:creator>$sceneTitle</dc:creator><text:p>~ ${Title} ~</text:p></office:annotation>$SceneContent</text:p>
    '''

    _appendedSceneTemplate = '''<text:p text:style-name="First_20_line_20_indent"><office:annotation>
<dc:creator>$sceneTitle</dc:creator>
<text:p>~ ${Title} ~</text:p>
</office:annotation>$SceneContent</text:p>
'''

    _sceneDivider = '<text:p text:style-name="Heading_20_4">* * *</text:p>\n'
    _fileFooter = OdtWFormatted._CONTENT_XML_FOOTER

    def _convert_from_yw(self, text, quick=False):
        if not quick:
            text = self._remove_inline_code(text)
        text = super()._convert_from_yw(text, quick)
        return(text)

    def _get_chapterMapping(self, chId, chapterNumber):
        chapterMapping = super()._get_chapterMapping(chId, chapterNumber)
        if self.novel.chapters[chId].suppressChapterTitle:
            chapterMapping['Title'] = ''
        return chapterMapping

    def _get_replacements(self):
        return [
                ('\n\n', ('</text:p>\r<text:p text:style-name="First_20_line_20_indent" />\r'
                          '<text:p text:style-name="Text_20_body">')),
                ('\n', '</text:p>\r<text:p text:style-name="First_20_line_20_indent">'),
                ('\r', '\n'),
                ('[i]', '<text:span text:style-name="Emphasis">'),
                ('[/i]', '</text:span>'),
                ('[b]', '<text:span text:style-name="Strong_20_Emphasis">'),
                ('[/b]', '</text:span>'),
                ]

    def _get_text(self):

        def replace_note(match):
            noteType = match.group(1)
            self._noteCounter += 1
            self._noteNumber += 1
            noteLabel = f'{self._noteNumber}'
            if noteType.startswith('fn'):
                noteClass = 'footnote'
                noteStyle = 'Footnote'
                if noteType.endswith('*'):
                    self._noteNumber -= 1
                    noteLabel = '*'
            elif noteType.startswith('en'):
                noteClass = 'endnote'
                noteStyle = 'Endnote'
            text = match.group(2).replace('text:style-name="First_20_line_20_indent"',
                                          f'text:style-name="{noteStyle}"')
            return (f'<text:note text:id="ftn{self._noteCounter}" '
                    f'text:note-class="{noteClass}"><text:note-citation '
                    f'text:label="{noteLabel}">*</text:note-citation><text:note-body>'
                    f'<text:p text:style-name="{noteStyle}">{text}</text:p></text:note-body></text:note>')

        text = super()._get_text()

        if text.find('/*') > 0:
            text = text.replace('\r', '@r@').replace('\n', '@n@')
            self._noteCounter = 0
            self._noteNumber = 0
            simpleComment = (f'<office:annotation><dc:creator>{self.novel.authorName}'
                             '</dc:creator><text:p>\\1</text:p></office:annotation>'
                             )
            text = re.sub('\/\* *@([ef]n\**) (.*?)\*\/', replace_note, text)
            text = re.sub('\/\*(.*?)\*\/', simpleComment, text)
            text = text.replace('@r@', '\r').replace('@n@', '\n')
        return text



class OdtWItems(OdtWriter):
    DESCRIPTION = _('Item descriptions')
    SUFFIX = '_items'

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _itemTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title$AKA</text:h>
<text:section text:style-name="Sect1" text:name="ItID:$ID">
<text:p text:style-name="Text_20_body">$Desc</text:p>
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_itemMapping(self, itId):
        itemMapping = super()._get_itemMapping(itId)
        if self.novel.items[itId].aka:
            itemMapping['AKA'] = f' ("{self.novel.items[itId].aka}")'
        return itemMapping


class OdtWLocations(OdtWriter):
    DESCRIPTION = _('Location descriptions')
    SUFFIX = '_locations'

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _locationTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title$AKA</text:h>
<text:section text:style-name="Sect1" text:name="LcID:$ID">
<text:p text:style-name="Text_20_body">$Desc</text:p>
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_locationMapping(self, lcId):
        locationMapping = super()._get_locationMapping(lcId)
        if self.novel.locations[lcId].aka:
            locationMapping['AKA'] = f' ("{self.novel.locations[lcId].aka}")'
        return locationMapping
from string import Template


class CrossReferences:

    def __init__(self):


        self.scnPerChr: dict[str, list[str]] = {}

        self.scnPerLoc: dict[str, list[str]] = {}

        self.scnPerItm: dict[str, list[str]] = {}

        self.scnPerTag: dict[str, list[str]] = {}

        self.chrPerTag: dict[str, list[str]] = {}

        self.locPerTag: dict[str, list[str]] = {}

        self.itmPerTag: dict[str, list[str]] = {}

        self.chpPerScn: dict[str, str] = {}

        self.srtScenes: list[str] = None

    def generate_xref(self, novel: Novel):
        self.scnPerChr = {}
        self.scnPerLoc = {}
        self.scnPerItm = {}
        self.scnPerTag = {}
        self.chrPerTag = {}
        self.locPerTag = {}
        self.itmPerTag = {}
        self.chpPerScn = {}
        self.srtScenes = []

        for crId in novel.srtCharacters:
            self.scnPerChr[crId] = []
            if novel.characters[crId].tags:
                for tag in novel.characters[crId].tags:
                    if not tag in self.chrPerTag:
                        self.chrPerTag[tag] = []
                    self.chrPerTag[tag].append(crId)

        for lcId in novel.srtLocations:
            self.scnPerLoc[lcId] = []
            if novel.locations[lcId].tags:
                for tag in novel.locations[lcId].tags:
                    if not tag in self.locPerTag:
                        self.locPerTag[tag] = []
                    self.locPerTag[tag].append(lcId)

        for itId in novel.srtItems:
            self.scnPerItm[itId] = []
            if novel.items[itId].tags:
                for tag in novel.items[itId].tags:
                    if not tag in self.itmPerTag:
                        self.itmPerTag[tag] = []
                    self.itmPerTag[tag].append(itId)

        for chId in novel.srtChapters:

            for scId in novel.chapters[chId].srtScenes:
                self.srtScenes.append(scId)
                self.chpPerScn[scId] = chId

                if novel.scenes[scId].characters:
                    for crId in novel.scenes[scId].characters:
                        self.scnPerChr[crId].append(scId)

                if novel.scenes[scId].locations:
                    for lcId in novel.scenes[scId].locations:
                        self.scnPerLoc[lcId].append(scId)

                if novel.scenes[scId].items:
                    for itId in novel.scenes[scId].items:
                        self.scnPerItm[itId].append(scId)

                if novel.scenes[scId].tags:
                    for tag in novel.scenes[scId].tags:
                        if not tag in self.scnPerTag:
                            self.scnPerTag[tag] = []
                        self.scnPerTag[tag].append(scId)


class OdtWXref(OdtWriter):
    DESCRIPTION = _('Cross reference')
    SUFFIX = '_xref'

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''
    _sceneTemplate = '''<text:p text:style-name="scene_20_mark">
<text:a xlink:href="../${ProjectName}_manuscript.odt#ScID:$ID%7Cregion">$SceneNumber</text:a> (Ch $Chapter) $Title
</text:p>
'''
    _unusedSceneTemplate = '''<text:p text:style-name="scene_20_mark_20_unused">
$SceneNumber (Ch $Chapter) $Title (Unused)
</text:p>
'''
    _notesSceneTemplate = '''<text:p text:style-name="scene_20_mark_20_notes">
$SceneNumber (Ch $Chapter) $Title (Notes)
</text:p>
'''
    _todoSceneTemplate = '''<text:p text:style-name="scene_20_mark_20_todo">
$SceneNumber (Ch $Chapter) $Title (ToDo)
</text:p>
'''
    _characterTemplate = '''<text:p text:style-name="Text_20_body">
<text:a xlink:href="../${ProjectName}_characters.odt#CrID:$ID%7Cregion">$Title</text:a> $FullName
</text:p>
'''
    _locationTemplate = '''<text:p text:style-name="Text_20_body">
<text:a xlink:href="../${ProjectName}_locations.odt#LcID:$ID%7Cregion">$Title</text:a>
</text:p>
'''
    _itemTemplate = '''<text:p text:style-name="Text_20_body">
<text:a xlink:href="../${ProjectName}_items.odt#ItrID:$ID%7Cregion">$Title</text:a>
</text:p>
'''
    _scnPerChrTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Scenes with Character $Title:</text:h>
'''
    _scnPerLocTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Scenes with Location $Title:</text:h>
'''
    _scnPerItmTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Scenes with Item $Title:</text:h>
'''
    _chrPerTagTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Characters tagged $Tag:</text:h>
'''
    _locPerTagTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Locations tagged $Tag:</text:h>
'''
    _itmPerTagTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Items tagged $Tag:</text:h>
'''
    _scnPerTagtemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">Scenes tagged $Tag:</text:h>
'''
    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self._xr = CrossReferences()

    def _get_characters(self):
        lines = []
        headerTemplate = Template(self._scnPerChrTemplate)
        for crId in self._xr.scnPerChr:
            if self._xr.scnPerChr[crId]:
                lines.append(headerTemplate.safe_substitute(self._get_characterMapping(crId)))
                lines.extend(self._get_scenes(self._xr.scnPerChr[crId]))
        return lines

    def _get_characterTags(self):
        lines = []
        headerTemplate = Template(self._chrPerTagTemplate)
        template = Template(self._characterTemplate)
        for tag in self._xr.chrPerTag:
            if self._xr.chrPerTag[tag]:
                lines.append(headerTemplate.safe_substitute(self._get_tagMapping(tag)))
                for crId in self._xr.chrPerTag[tag]:
                    lines.append(template.safe_substitute(self._get_characterMapping(crId)))
        return lines

    def _get_items(self):
        lines = []
        headerTemplate = Template(self._scnPerItmTemplate)
        for itId in self._xr.scnPerItm:
            if self._xr.scnPerItm[itId]:
                lines.append(headerTemplate.safe_substitute(self._get_itemMapping(itId)))
                lines.extend(self._get_scenes(self._xr.scnPerItm[itId]))
        return lines

    def _get_itemTags(self):
        lines = []
        headerTemplate = Template(self._itmPerTagTemplate)
        template = Template(self._itemTemplate)
        for tag in self._xr.itmPerTag:
            if self._xr.itmPerTag[tag]:
                lines.append(headerTemplate.safe_substitute(self._get_tagMapping(tag)))
                for itId in self._xr.itmPerTag[tag]:
                    lines.append(template.safe_substitute(self._get_itemMapping(itId)))
        return lines

    def _get_locations(self):
        lines = []
        headerTemplate = Template(self._scnPerLocTemplate)
        for lcId in self._xr.scnPerLoc:
            if self._xr.scnPerLoc[lcId]:
                lines.append(headerTemplate.safe_substitute(self._get_locationMapping(lcId)))
                lines.extend(self._get_scenes(self._xr.scnPerLoc[lcId]))
        return lines

    def _get_locationTags(self):
        lines = []
        headerTemplate = Template(self._locPerTagTemplate)
        template = Template(self._locationTemplate)
        for tag in self._xr.locPerTag:
            if self._xr.locPerTag[tag]:
                lines.append(headerTemplate.safe_substitute(self._get_tagMapping(tag)))
                for lcId in self._xr.locPerTag[tag]:
                    lines.append(template.safe_substitute(self._get_locationMapping(lcId)))
        return lines

    def _get_sceneMapping(self, scId):
        sceneNumber = self._xr.srtScenes.index(scId) + 1
        sceneMapping = super()._get_sceneMapping(scId, sceneNumber, 0, 0)
        chapterNumber = self.novel.srtChapters.index(self._xr.chpPerScn[scId]) + 1
        sceneMapping['Chapter'] = str(chapterNumber)
        return sceneMapping

    def _get_scenes(self, scenes):
        lines = []
        for scId in scenes:
            if self.novel.scenes[scId].scType == 1:
                template = Template(self._notesSceneTemplate)
            elif self.novel.scenes[scId].scType == 2:
                template = Template(self._todoSceneTemplate)
            elif self.novel.scenes[scId].scType == 3:
                template = Template(self._unusedSceneTemplate)
            else:
                template = Template(self._sceneTemplate)
            lines.append(template.safe_substitute(self._get_sceneMapping(scId)))
        return lines

    def _get_sceneTags(self):
        lines = []
        headerTemplate = Template(self._scnPerTagtemplate)
        for tag in self._xr.scnPerTag:
            if self._xr.scnPerTag[tag]:
                lines.append(headerTemplate.safe_substitute(self._get_tagMapping(tag)))
                lines.extend(self._get_scenes(self._xr.scnPerTag[tag]))
        return lines

    def _get_tagMapping(self, tag):
        tagMapping = dict(
            Tag=tag,
        )
        return tagMapping

    def _get_text(self):
        self._xr.generate_xref(self.novel)
        lines = self._get_fileHeader()
        lines.extend(self._get_characters())
        lines.extend(self._get_locations())
        lines.extend(self._get_items())
        lines.extend(self._get_sceneTags())
        lines.extend(self._get_characterTags())
        lines.extend(self._get_locationTags())
        lines.extend(self._get_itemTags())
        lines.append(self._fileFooter)
        return ''.join(lines)
from string import Template


class OdtWNotes(OdtWManuscript):
    DESCRIPTION = _('Notes chapters')
    SUFFIX = '_notes'

    _partTemplate = ''
    _chapterTemplate = ''

    _notesPartTemplate = '''<text:section text:style-name="Sect1" text:name="ChID:$ID">
<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _notesChapterTemplate = '''<text:section text:style-name="Sect1" text:name="ChID:$ID">
<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title</text:h>
'''

    _notesSceneTemplate = '''<text:h text:style-name="Heading_20_3" text:outline-level="3">$Title</text:h>
<text:section text:style-name="Sect1" text:name="ScID:$ID">
<text:p text:style-name="Text_20_body">$SceneContent</text:p>
</text:section>
'''
    _sceneDivider = ''

    _notesChapterEndTemplate = '''</text:section>
'''

    def _get_chapters(self):
        lines = []
        if not self._notesChapterEndTemplate:
            return lines

        chapterNumber = 0
        sceneNumber = 0
        wordsTotal = 0
        lettersTotal = 0
        for chId in self.novel.srtChapters:
            dispNumber = 0
            if not self._chapterFilter.accept(self, chId):
                continue

            doNotExport = False
            template = None
            if self.novel.chapters[chId].chType == 1:
                if self.novel.chapters[chId].chLevel == 1:
                    if self._notesPartTemplate:
                        template = Template(self._notesPartTemplate)
                elif self._notesChapterTemplate:
                    template = Template(self._notesChapterTemplate)
                    chapterNumber += 1
                    dispNumber = chapterNumber
                if template is not None:
                    lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))

                    sceneLines, sceneNumber, wordsTotal, lettersTotal = self._get_scenes(
                        chId, sceneNumber, wordsTotal, lettersTotal, doNotExport)
                    lines.extend(sceneLines)

                    template = Template(self._notesChapterEndTemplate)
                    lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))
        return lines
from string import Template


class OdtWTodo(OdtWManuscript):
    DESCRIPTION = _('Todo chapters')
    SUFFIX = '_todo'

    _partTemplate = ''
    _chapterTemplate = ''

    _todoPartTemplate = '''<text:section text:style-name="Sect1" text:name="ChID:$ID">
<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _todoChapterTemplate = '''<text:section text:style-name="Sect1" text:name="ChID:$ID">
<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title</text:h>
'''

    _todoSceneTemplate = '''<text:h text:style-name="Heading_20_3" text:outline-level="3">$Title</text:h>
<text:section text:style-name="Sect1" text:name="ScID:$ID">
<text:p text:style-name="Text_20_body">$SceneContent</text:p>
</text:section>
'''
    _sceneDivider = ''

    _todoChapterEndTemplate = '''</text:section>
'''

    def _get_chapters(self):
        lines = []
        if not self._todoChapterEndTemplate:
            return lines

        chapterNumber = 0
        sceneNumber = 0
        wordsTotal = 0
        lettersTotal = 0
        for chId in self.novel.srtChapters:
            dispNumber = 0
            if not self._chapterFilter.accept(self, chId):
                continue

            doNotExport = False
            template = None
            if self.novel.chapters[chId].chType == 2:
                if self.novel.chapters[chId].chLevel == 1:
                    if self._todoPartTemplate:
                        template = Template(self._todoPartTemplate)
                elif self._todoChapterTemplate:
                    template = Template(self._todoChapterTemplate)
                    chapterNumber += 1
                    dispNumber = chapterNumber
                if template is not None:
                    lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))

                    sceneLines, sceneNumber, wordsTotal, lettersTotal = self._get_scenes(
                        chId, sceneNumber, wordsTotal, lettersTotal, doNotExport)
                    lines.extend(sceneLines)

                    template = Template(self._todoChapterEndTemplate)
                    lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))
        return lines


class OdsWriter(OdfFile):
    EXTENSION = '.ods'
    _ODF_COMPONENTS = ['META-INF', 'content.xml', 'meta.xml', 'mimetype',
                      'settings.xml', 'styles.xml', 'META-INF/manifest.xml']


    _CONTENT_XML_HEADER = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:ooow="http://openoffice.org/2004/writer" xmlns:oooc="http://openoffice.org/2004/calc" xmlns:dom="http://www.w3.org/2001/xml-events" xmlns:xforms="http://www.w3.org/2002/xforms" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:rpt="http://openoffice.org/2005/report" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:grddl="http://www.w3.org/2003/g/data-view#" xmlns:tableooo="http://openoffice.org/2009/table" xmlns:field="urn:openoffice:names:experimental:ooo-ms-interop:xmlns:field:1.0" office:version="1.2">
 <office:scripts/>
 <office:font-face-decls>
  <style:font-face style:name="Segoe UI" svg:font-family="&apos;Segoe UI&apos;" style:font-adornments="Standard" style:font-family-generic="swiss" style:font-pitch="variable"/>
 </office:font-face-decls>
 <office:automatic-styles>
  <style:style style:name="co1" style:family="table-column">
   <style:table-column-properties fo:break-before="auto" style:column-width="2.000cm"/>
  </style:style>
  <style:style style:name="co2" style:family="table-column">
   <style:table-column-properties fo:break-before="auto" style:column-width="3.000cm"/>
  </style:style>
  <style:style style:name="co3" style:family="table-column">
   <style:table-column-properties fo:break-before="auto" style:column-width="4.000cm"/>
  </style:style>
  <style:style style:name="co4" style:family="table-column">
   <style:table-column-properties fo:break-before="auto" style:column-width="8.000cm"/>
  </style:style>
  <style:style style:name="ro1" style:family="table-row">
   <style:table-row-properties style:row-height="1.157cm" fo:break-before="auto" style:use-optimal-row-height="true"/>
  </style:style>
  <style:style style:name="ro2" style:family="table-row">
   <style:table-row-properties style:row-height="2.053cm" fo:break-before="auto" style:use-optimal-row-height="true"/>
  </style:style>
  <style:style style:name="ta1" style:family="table" style:master-page-name="Default">
   <style:table-properties table:display="true" style:writing-mode="lr-tb"/>
  </style:style>
 </office:automatic-styles>
 <office:body>
  <office:spreadsheet>
   <table:table table:name="'''

    _CONTENT_XML_FOOTER = '''   </table:table>
  </office:spreadsheet>
 </office:body>
</office:document-content>
'''

    _META_XML = '''<?xml version="1.0" encoding="utf-8"?>
<office:document-meta xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:grddl="http://www.w3.org/2003/g/data-view#" office:version="1.2">
  <office:meta>
    <meta:generator>PyWriter</meta:generator>
    <dc:title>$Title</dc:title>
    <dc:description>$Summary</dc:description>
    <dc:subject></dc:subject>
    <meta:keyword></meta:keyword>
    <meta:initial-creator>$Author</meta:initial-creator>
    <dc:creator></dc:creator>
    <meta:creation-date>${Datetime}Z</meta:creation-date>
    <dc:date></dc:date>
  </office:meta>
</office:document-meta>
'''
    _MANIFEST_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">
 <manifest:file-entry manifest:media-type="application/vnd.oasis.opendocument.spreadsheet" manifest:version="1.2" manifest:full-path="/"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="content.xml"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="styles.xml"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="meta.xml"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="settings.xml"/>
</manifest:manifest>    
'''
    _SETTINGS_XML = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-settings xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:config="urn:oasis:names:tc:opendocument:xmlns:config:1.0" xmlns:ooo="http://openoffice.org/2004/office" office:version="1.2">
 <office:settings>
  <config:config-item-set config:name="ooo:view-settings">
   <config:config-item config:name="VisibleAreaTop" config:type="int">0</config:config-item>
   <config:config-item config:name="VisibleAreaLeft" config:type="int">0</config:config-item>
   <config:config-item config:name="VisibleAreaWidth" config:type="int">44972</config:config-item>
   <config:config-item config:name="VisibleAreaHeight" config:type="int">18999</config:config-item>
   <config:config-item-map-indexed config:name="Views">
    <config:config-item-map-entry>
     <config:config-item config:name="ViewId" config:type="string">view1</config:config-item>
     <config:config-item-map-named config:name="Tables">
      <config:config-item-map-entry config:name="Tabelle1">
       <config:config-item config:name="CursorPositionX" config:type="int">5</config:config-item>
       <config:config-item config:name="CursorPositionY" config:type="int">1</config:config-item>
       <config:config-item config:name="HorizontalSplitMode" config:type="short">0</config:config-item>
       <config:config-item config:name="VerticalSplitMode" config:type="short">0</config:config-item>
       <config:config-item config:name="HorizontalSplitPosition" config:type="int">0</config:config-item>
       <config:config-item config:name="VerticalSplitPosition" config:type="int">0</config:config-item>
       <config:config-item config:name="ActiveSplitRange" config:type="short">2</config:config-item>
       <config:config-item config:name="PositionLeft" config:type="int">0</config:config-item>
       <config:config-item config:name="PositionRight" config:type="int">0</config:config-item>
       <config:config-item config:name="PositionTop" config:type="int">0</config:config-item>
       <config:config-item config:name="PositionBottom" config:type="int">0</config:config-item>
       <config:config-item config:name="ZoomType" config:type="short">0</config:config-item>
       <config:config-item config:name="ZoomValue" config:type="int">100</config:config-item>
       <config:config-item config:name="PageViewZoomValue" config:type="int">60</config:config-item>
      </config:config-item-map-entry>
     </config:config-item-map-named>
     <config:config-item config:name="ActiveTable" config:type="string">Tabelle1</config:config-item>
     <config:config-item config:name="HorizontalScrollbarWidth" config:type="int">270</config:config-item>
     <config:config-item config:name="ZoomType" config:type="short">0</config:config-item>
     <config:config-item config:name="ZoomValue" config:type="int">100</config:config-item>
     <config:config-item config:name="PageViewZoomValue" config:type="int">60</config:config-item>
     <config:config-item config:name="ShowPageBreakPreview" config:type="boolean">false</config:config-item>
     <config:config-item config:name="ShowZeroValues" config:type="boolean">true</config:config-item>
     <config:config-item config:name="ShowNotes" config:type="boolean">true</config:config-item>
     <config:config-item config:name="ShowGrid" config:type="boolean">true</config:config-item>
     <config:config-item config:name="GridColor" config:type="long">12632256</config:config-item>
     <config:config-item config:name="ShowPageBreaks" config:type="boolean">true</config:config-item>
     <config:config-item config:name="HasColumnRowHeaders" config:type="boolean">true</config:config-item>
     <config:config-item config:name="HasSheetTabs" config:type="boolean">true</config:config-item>
     <config:config-item config:name="IsOutlineSymbolsSet" config:type="boolean">true</config:config-item>
     <config:config-item config:name="IsSnapToRaster" config:type="boolean">false</config:config-item>
     <config:config-item config:name="RasterIsVisible" config:type="boolean">false</config:config-item>
     <config:config-item config:name="RasterResolutionX" config:type="int">1000</config:config-item>
     <config:config-item config:name="RasterResolutionY" config:type="int">1000</config:config-item>
     <config:config-item config:name="RasterSubdivisionX" config:type="int">1</config:config-item>
     <config:config-item config:name="RasterSubdivisionY" config:type="int">1</config:config-item>
     <config:config-item config:name="IsRasterAxisSynchronized" config:type="boolean">true</config:config-item>
    </config:config-item-map-entry>
   </config:config-item-map-indexed>
  </config:config-item-set>
  <config:config-item-set config:name="ooo:configuration-settings">
   <config:config-item config:name="IsKernAsianPunctuation" config:type="boolean">false</config:config-item>
   <config:config-item config:name="IsRasterAxisSynchronized" config:type="boolean">true</config:config-item>
   <config:config-item config:name="LinkUpdateMode" config:type="short">3</config:config-item>
   <config:config-item config:name="SaveVersionOnClose" config:type="boolean">false</config:config-item>
   <config:config-item config:name="AllowPrintJobCancel" config:type="boolean">true</config:config-item>
   <config:config-item config:name="HasSheetTabs" config:type="boolean">true</config:config-item>
   <config:config-item config:name="ShowPageBreaks" config:type="boolean">true</config:config-item>
   <config:config-item config:name="RasterResolutionX" config:type="int">1000</config:config-item>
   <config:config-item config:name="PrinterSetup" config:type="base64Binary"/>
   <config:config-item config:name="RasterResolutionY" config:type="int">1000</config:config-item>
   <config:config-item config:name="LoadReadonly" config:type="boolean">false</config:config-item>
   <config:config-item config:name="RasterSubdivisionX" config:type="int">1</config:config-item>
   <config:config-item config:name="ShowNotes" config:type="boolean">true</config:config-item>
   <config:config-item config:name="ShowZeroValues" config:type="boolean">true</config:config-item>
   <config:config-item config:name="RasterSubdivisionY" config:type="int">1</config:config-item>
   <config:config-item config:name="ApplyUserData" config:type="boolean">true</config:config-item>
   <config:config-item config:name="GridColor" config:type="long">12632256</config:config-item>
   <config:config-item config:name="RasterIsVisible" config:type="boolean">false</config:config-item>
   <config:config-item config:name="IsSnapToRaster" config:type="boolean">false</config:config-item>
   <config:config-item config:name="PrinterName" config:type="string"/>
   <config:config-item config:name="ShowGrid" config:type="boolean">true</config:config-item>
   <config:config-item config:name="CharacterCompressionType" config:type="short">0</config:config-item>
   <config:config-item-map-indexed config:name="ForbiddenCharacters">
    <config:config-item-map-entry>
     <config:config-item config:name="Language" config:type="string">$Language</config:config-item>
     <config:config-item config:name="Country" config:type="string">$Country</config:config-item>
     <config:config-item config:name="Variant" config:type="string"/>
     <config:config-item config:name="BeginLine" config:type="string"/>
     <config:config-item config:name="EndLine" config:type="string"/>
    </config:config-item-map-entry>
   </config:config-item-map-indexed>
   <config:config-item config:name="IsOutlineSymbolsSet" config:type="boolean">true</config:config-item>
   <config:config-item config:name="AutoCalculate" config:type="boolean">true</config:config-item>
   <config:config-item config:name="IsDocumentShared" config:type="boolean">false</config:config-item>
   <config:config-item config:name="UpdateFromTemplate" config:type="boolean">true</config:config-item>
  </config:config-item-set>
 </office:settings>
</office:document-settings>
'''
    _STYLES_XML = '''<?xml version="1.0" encoding="UTF-8"?>

<office:document-styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:chart="urn:oasis:names:tc:opendocument:xmlns:chart:1.0" xmlns:dr3d="urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0" xmlns:math="http://www.w3.org/1998/Math/MathML" xmlns:form="urn:oasis:names:tc:opendocument:xmlns:form:1.0" xmlns:script="urn:oasis:names:tc:opendocument:xmlns:script:1.0" xmlns:ooo="http://openoffice.org/2004/office" xmlns:ooow="http://openoffice.org/2004/writer" xmlns:oooc="http://openoffice.org/2004/calc" xmlns:dom="http://www.w3.org/2001/xml-events" xmlns:rpt="http://openoffice.org/2005/report" xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:grddl="http://www.w3.org/2003/g/data-view#" xmlns:tableooo="http://openoffice.org/2009/table" office:version="1.2">
 <office:font-face-decls>
  <style:font-face style:name="Segoe UI" svg:font-family="&apos;Segoe UI&apos;" style:font-adornments="Standard" style:font-family-generic="swiss" style:font-pitch="variable"/>
 </office:font-face-decls>
 <office:styles>
  <style:default-style style:family="table-cell">
   <style:paragraph-properties style:tab-stop-distance="1.25cm"/>
   <style:text-properties style:font-name="Arial" fo:language="$Language" fo:country="$Country" style:font-name-asian="Arial Unicode MS" style:language-asian="zh" style:country-asian="CN" style:font-name-complex="Tahoma" style:language-complex="hi" style:country-complex="IN"/>
  </style:default-style>
  <number:number-style style:name="N0">
   <number:number number:min-integer-digits="1"/>
  </number:number-style>
  <style:style style:name="Default" style:family="table-cell">
   <style:table-cell-properties style:text-align-source="fix" style:repeat-content="false" fo:background-color="transparent" fo:wrap-option="wrap" fo:padding="0.136cm" style:vertical-align="top"/>
   <style:paragraph-properties fo:text-align="start"/>
   <style:text-properties style:font-name="Segoe UI" style:font-name-asian="Microsoft YaHei" style:font-name-complex="Arial Unicode MS"/>
  </style:style>
  <style:style style:name="Result" style:family="table-cell" style:parent-style-name="Default">
   <style:text-properties fo:font-style="italic" style:text-underline-style="solid" style:text-underline-width="auto" style:text-underline-color="font-color" fo:font-weight="bold"/>
  </style:style>
  <style:style style:name="Result2" style:family="table-cell" style:parent-style-name="Result"/>
  <style:style style:name="Heading" style:family="table-cell" style:parent-style-name="Default">
   <style:table-cell-properties fo:background-color="#cfe7f5" style:text-align-source="fix" style:repeat-content="false"/>
   <style:paragraph-properties fo:text-align="start"/>
   <style:text-properties fo:font-weight="bold"/>
  </style:style>
  <style:style style:name="Heading1" style:family="table-cell" style:parent-style-name="Heading">
   <style:table-cell-properties style:rotation-angle="90"/>
  </style:style>
 </office:styles>
 <office:automatic-styles>
  <style:page-layout style:name="Mpm1">
   <style:page-layout-properties style:writing-mode="lr-tb"/>
   <style:header-style>
    <style:header-footer-properties fo:min-height="0.751cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-bottom="0.25cm"/>
   </style:header-style>
   <style:footer-style>
    <style:header-footer-properties fo:min-height="0.751cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="0.25cm"/>
   </style:footer-style>
  </style:page-layout>
  <style:page-layout style:name="Mpm2">
   <style:page-layout-properties style:writing-mode="lr-tb"/>
   <style:header-style>
    <style:header-footer-properties fo:min-height="0.751cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-bottom="0.25cm" fo:border="0.088cm solid #000000" fo:padding="0.018cm" fo:background-color="#c0c0c0">
     <style:background-image/>
    </style:header-footer-properties>
   </style:header-style>
   <style:footer-style>
    <style:header-footer-properties fo:min-height="0.751cm" fo:margin-left="0cm" fo:margin-right="0cm" fo:margin-top="0.25cm" fo:border="0.088cm solid #000000" fo:padding="0.018cm" fo:background-color="#c0c0c0">
     <style:background-image/>
    </style:header-footer-properties>
   </style:footer-style>
  </style:page-layout>
 </office:automatic-styles>
 <office:master-styles>
  <style:master-page style:name="Default" style:page-layout-name="Mpm1">
   <style:header>
    <text:p><text:sheet-name>???</text:sheet-name></text:p>
   </style:header>
   <style:header-left style:display="false"/>
   <style:footer>
    <text:p>Seite <text:page-number>1</text:page-number></text:p>
   </style:footer>
   <style:footer-left style:display="false"/>
  </style:master-page>
  <style:master-page style:name="Report" style:page-layout-name="Mpm2">
   <style:header>
    <style:region-left>
     <text:p><text:sheet-name>???</text:sheet-name> (<text:title>???</text:title>)</text:p>
    </style:region-left>
    <style:region-right>
     <text:p><text:date style:data-style-name="N2" text:date-value="2021-03-15">15.03.2021</text:date>, <text:time>15:34:40</text:time></text:p>
    </style:region-right>
   </style:header>
   <style:header-left style:display="false"/>
   <style:footer>
    <text:p>Seite <text:page-number>1</text:page-number> / <text:page-count>99</text:page-count></text:p>
   </style:footer>
   <style:footer-left style:display="false"/>
  </style:master-page>
 </office:master-styles>
</office:document-styles>
'''
    _MIMETYPE = 'application/vnd.oasis.opendocument.spreadsheet'

    def _convert_from_yw(self, text, quick=False):
        ODS_REPLACEMENTS = [
            ('&', '&amp;'),  # must be first!
            ('"', '&quot;'),
            ("'", '&apos;'),
            ('>', '&gt;'),
            ('<', '&lt;'),
            ('\n', '</text:p>\n<text:p>'),
        ]
        try:
            text = text.rstrip()
            for yw, od in ODS_REPLACEMENTS:
                text = text.replace(yw, od)
        except AttributeError:
            text = ''
        return text


class OdsWCharList(OdsWriter):

    DESCRIPTION = _('Character list')
    SUFFIX = '_charlist'

    _fileHeader = f'''{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" table:style-name="ta1" table:print="false">
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:number-columns-repeated="3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:number-columns-repeated="1014" table:default-cell-style-name="Default"/>
     <table:table-row table:style-name="ro1">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Name</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Full name</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Aka</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Description</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Bio</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Goals</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Importance</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Tags</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Notes</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1014"/>
    </table:table-row>

'''
    _characterTemplate = '''   <table:table-row table:style-name="ro2">
     <table:table-cell office:value-type="string">
      <text:p>CrID:$ID</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Title</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$FullName</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$AKA</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Desc</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Bio</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Goals</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Status</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Tags</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Notes</text:p>
     </table:table-cell>
     <table:table-cell table:number-columns-repeated="1014"/>
    </table:table-row>

'''

    _fileFooter = OdsWriter._CONTENT_XML_FOOTER


class OdsWLocList(OdsWriter):
    DESCRIPTION = _('Location list')
    SUFFIX = '_loclist'

    _fileHeader = f'''{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" table:style-name="ta1" table:print="false">
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:number-columns-repeated="1014" table:default-cell-style-name="Default"/>
     <table:table-row table:style-name="ro1">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Name</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Description</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Aka</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Tags</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1014"/>
    </table:table-row>

'''

    _locationTemplate = '''   <table:table-row table:style-name="ro2">
     <table:table-cell office:value-type="string">
      <text:p>LcID:$ID</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Title</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Desc</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$AKA</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Tags</text:p>
     </table:table-cell>
     <table:table-cell table:number-columns-repeated="1014"/>
    </table:table-row>

'''
    _fileFooter = OdsWriter._CONTENT_XML_FOOTER


class OdsWItemList(OdsWriter):

    DESCRIPTION = _('Item list')
    SUFFIX = '_itemlist'

    _fileHeader = f'''{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" table:style-name="ta1" table:print="false">
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:number-columns-repeated="1014" table:default-cell-style-name="Default"/>
     <table:table-row table:style-name="ro1">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>ID</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Name</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Description</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Aka</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Tags</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1014"/>
    </table:table-row>

'''

    _itemTemplate = '''   <table:table-row table:style-name="ro2">
     <table:table-cell office:value-type="string">
      <text:p>ItID:$ID</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Title</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Desc</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$AKA</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Tags</text:p>
     </table:table-cell>
     <table:table-cell table:number-columns-repeated="1014"/>
    </table:table-row>

'''

    _fileFooter = OdsWriter._CONTENT_XML_FOOTER


class OdsWSceneList(OdsWriter):

    DESCRIPTION = _('Scene list')
    SUFFIX = '_scenelist'



    _fileHeader = f'''{OdsWriter._CONTENT_XML_HEADER}{DESCRIPTION}" table:style-name="ta1" table:print="false">
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co4" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co1" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co2" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-column table:style-name="co3" table:default-cell-style-name="Default"/>
    <table:table-row table:style-name="ro1">
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Scene link</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Scene title</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Scene description</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Tags</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Scene notes</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>A/R</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Goal</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Conflict</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Outcome</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Scene</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Words total</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$FieldTitle1</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$FieldTitle2</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$FieldTitle3</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>$FieldTitle4</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Word count</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Letter count</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Status</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Characters</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Locations</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" office:value-type="string">
      <text:p>Items</text:p>
     </table:table-cell>
     <table:table-cell table:style-name="Heading" table:number-columns-repeated="1003"/>
    </table:table-row>

'''

    _sceneTemplate = '''   <table:table-row table:style-name="ro2">
     <table:table-cell table:formula="of:=HYPERLINK(&quot;file:///$ProjectPath/${ProjectName}_manuscript.odt#ScID:$ID%7Cregion&quot;;&quot;ScID:$ID&quot;)" office:value-type="string" office:string-value="ScID:$ID">
      <text:p>ScID:$ID</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Title</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Desc</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Tags</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Notes</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$ReactionScene</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Goal</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Conflict</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Outcome</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="float" office:value="$SceneNumber">
      <text:p>$SceneNumber</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="float" office:value="$WordsTotal">
      <text:p>$WordsTotal</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="float" office:value="$Field1">
      <text:p>$Field1</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="float" office:value="$Field2">
      <text:p>$Field2</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="float" office:value="$Field3">
      <text:p>$Field3</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="float" office:value="$Field4">
      <text:p>$Field4</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="float" office:value="$WordCount">
      <text:p>$WordCount</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="float" office:value="$LetterCount">
      <text:p>$LetterCount</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Status</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Characters</text:p>
     </table:table-cell>
     <table:table-cell office:value-type="string">
      <text:p>$Locations</text:p>
     </table:table-cell>
     <table:table-cell>
      <text:p>$Items</text:p>
     </table:table-cell>
    </table:table-row>

'''

    _fileFooter = OdsWriter._CONTENT_XML_FOOTER

    def _get_sceneMapping(self, scId, sceneNumber, wordsTotal, lettersTotal):
        sceneMapping = super()._get_sceneMapping(scId, sceneNumber, wordsTotal, lettersTotal)
        if self.novel.scenes[scId].field1 == '1':
            sceneMapping['Field1'] = ''
        if self.novel.scenes[scId].field2 == '1':
            sceneMapping['Field2'] = ''
        if self.novel.scenes[scId].field3 == '1':
            sceneMapping['Field3'] = ''
        if self.novel.scenes[scId].field4 == '1':
            sceneMapping['Field4'] = ''
        return sceneMapping


class DataFiles(Yw7File):
    DESCRIPTION = _('yWriter XML data files')
    EXTENSION = '.xml'

    def _postprocess_xml_file(self, filePath):
        '''Postprocess three xml files created by ElementTree.
        
        Positional argument:
            filePath: str -- path to .yw7 xml file.
            
        Generate the xml file paths from the .yw7 path. 
        Read, postprocess and write the characters, locations, and items xml files.        
        Extends the superclass method.
        '''
        path, __ = os.path.splitext(filePath)
        characterPath = f'{path}_Characters.xml'
        super()._postprocess_xml_file(characterPath)
        locationPath = f'{path}_Locations.xml'
        super()._postprocess_xml_file(locationPath)
        itemPath = f'{path}_Items.xml'
        super()._postprocess_xml_file(itemPath)

    def _write_element_tree(self, ywProject):
        path, __ = os.path.splitext(ywProject.filePath)
        characterPath = f'{path}_Characters.xml'
        characterSubtree = ywProject.tree.find('CHARACTERS')
        characterTree = ET.ElementTree(characterSubtree)
        try:
            characterTree.write(characterPath, xml_declaration=False, encoding='utf-8')
        except(PermissionError):
            raise Error(f'{_("File is write protected")}: "{norm_path(characterPath)}".')

        locationPath = f'{path}_Locations.xml'
        locationSubtree = ywProject.tree.find('LOCATIONS')
        locationTree = ET.ElementTree(locationSubtree)
        try:
            locationTree.write(locationPath, xml_declaration=False, encoding='utf-8')
        except(PermissionError):
            raise Error(f'{_("File is write protected")}: "{norm_path(locationPath)}".')

        itemPath = f'{path}_Items.xml'
        itemSubtree = ywProject.tree.find('ITEMS')
        itemTree = ET.ElementTree(itemSubtree)
        try:
            itemTree.write(itemPath, xml_declaration=False, encoding='utf-8')
        except(PermissionError):
            raise Error(f'{_("File is write protected")}: "{norm_path(itemPath)}".')


from abc import ABC, abstractmethod


class NvExporter(ABC):

    @abstractmethod
    def run(self, source, suffix, lock=False, show=False):
        pass



class OdtWCharacters(OdtWriter):
    DESCRIPTION = _('Character descriptions')
    SUFFIX = '_characters'

    _fileHeader = f'''{OdtWriter._CONTENT_XML_HEADER}<text:p text:style-name="Title">$Title</text:p>
<text:p text:style-name="Subtitle">$AuthorName</text:p>
'''

    _characterTemplate = f'''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title$FullName$AKA</text:h>
<text:section text:style-name="Sect1" text:name="CrID:$ID">
<text:h text:style-name="Heading_20_3" text:outline-level="3">{_("Description")}</text:h>
<text:section text:style-name="Sect1" text:name="CrID_desc:$ID">
<text:p text:style-name="Text_20_body">$Desc</text:p>
</text:section>
<text:h text:style-name="Heading_20_3" text:outline-level="3">{_("Bio")}</text:h>
<text:section text:style-name="Sect1" text:name="CrID_bio:$ID">
<text:p text:style-name="Text_20_body">$Bio</text:p>
</text:section>
<text:h text:style-name="Heading_20_3" text:outline-level="3">{_("Goals")}</text:h>
<text:section text:style-name="Sect1" text:name="CrID_goals:$ID">
<text:p text:style-name="Text_20_body">$Goals</text:p>
</text:section>
<text:h text:style-name="Heading_20_3" text:outline-level="3">{_("Notes")}</text:h>
<text:section text:style-name="Sect1" text:name="CrID_notes:$ID">
<text:p text:style-name="Text_20_body">$Notes</text:p>
</text:section>
</text:section>
'''

    _fileFooter = OdtWriter._CONTENT_XML_FOOTER

    def _get_characterMapping(self, crId):
        characterMapping = OdtWriter._get_characterMapping(self, crId)
        if self.novel.characters[crId].aka:
            characterMapping['AKA'] = f' ("{self.novel.characters[crId].aka}")'
        if self.novel.characters[crId].fullName:
            characterMapping['FullName'] = f'/{self.novel.characters[crId].fullName}'
        return characterMapping


class OdtCharactersNv(OdtWCharacters):

    _characterTemplate = f'''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title$FullName$AKA</text:h>
<text:section text:style-name="Sect1" text:name="CrID:$ID">
<text:h text:style-name="Heading_20_3" text:outline-level="3">{_("Description")}</text:h>
<text:section text:style-name="Sect1" text:name="CrID_desc:$ID">
<text:p text:style-name="Text_20_body">$Desc</text:p>
</text:section>
<text:h text:style-name="Heading_20_3" text:outline-level="3">$BioTitle</text:h>
<text:section text:style-name="Sect1" text:name="CrID_bio:$ID">
<text:p text:style-name="Text_20_body">$Bio</text:p>
</text:section>
<text:h text:style-name="Heading_20_3" text:outline-level="3">$GoalsTitle</text:h>
<text:section text:style-name="Sect1" text:name="CrID_goals:$ID">
<text:p text:style-name="Text_20_body">$Goals</text:p>
</text:section>
<text:h text:style-name="Heading_20_3" text:outline-level="3">{_("Notes")}</text:h>
<text:section text:style-name="Sect1" text:name="CrID_notes:$ID">
<text:p text:style-name="Text_20_body">$Notes</text:p>
</text:section>
</text:section>
'''
    PRJ_KWVAR = (
        'Field_CustomChrBio',
        'Field_CustomChrGoals',
        )

    def _get_characterMapping(self, crId):
        characterMapping = super()._get_characterMapping(crId)

        if self.novel.kwVar.get('Field_CustomChrBio', None):
            characterMapping['BioTitle'] = self.novel.kwVar['Field_CustomChrBio']
        else:
            characterMapping['BioTitle'] = _('Bio')
        if self.novel.kwVar.get('Field_CustomChrGoals', None):
            characterMapping['GoalsTitle'] = self.novel.kwVar['Field_CustomChrGoals']
        else:
            characterMapping['GoalsTitle'] = _('Goals')

        return characterMapping




class WrimoFile(FileExport):
    DESCRIPTION = _('Obfuscated text for word count')
    EXTENSION = '.txt'
    SUFFIX = '_wrimo'

    _sceneTemplate = '$SceneContent\n\n'

    def _convert_from_yw(self, text, quick=False):
        if text:
            text = ADDITIONAL_WORD_LIMITS.sub(' ', text)
            text = NO_WORD_LIMITS.sub('', text)
            text = re.sub('\S', 'x', text)
        else:
            text = ''
        return text

from string import Template


class OdtArcs(OdtWTodo):
    DESCRIPTION = _('Arcs')
    SUFFIX = '_arcs'

    _todoPartTemplate = '''<text:h text:style-name="Heading_20_1" text:outline-level="1">$Title</text:h>
'''

    _todoChapterTemplate = '''<text:h text:style-name="Heading_20_2" text:outline-level="2">$Title</text:h>
<text:p text:style-name="Text_20_body">$Desc</text:p>
'''
    _todoSceneTemplate = '''<text:h text:style-name="Heading_20_3" text:outline-level="3">$Title</text:h>
<text:p text:style-name="Text_20_body">$Desc</text:p>
$SceneAssoc
<text:p text:style-name="Heading_20_4">―――</text:p>\n
<text:p text:style-name="Text_20_body">$SceneContent</text:p>
'''
    _todoChapterEndTemplate = ''

    _sceneLinkTemplate = '''
<text:p text:style-name="Text_20_body">$Scene: <text:span text:style-name="Emphasis">$SceneAssocTitle</text:span></text:p>    
<text:p text:style-name="Text_20_body">→ <text:a xlink:href="../${ProjectName}_scenes.odt#ScID:$ID%7Cregion">$Description</text:a></text:p>
<text:p text:style-name="Text_20_body">→ <text:a xlink:href="../${ProjectName}_manuscript.odt#ScID:$ID%7Cregion">$Manuscript</text:a></text:p>
'''

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._chapterFilter = ArcFilter()
        self._sceneFilter = PointFilter()

    def _get_chapters(self):
        lines = []
        chapterNumber = 0
        sceneNumber = 0
        wordsTotal = 0
        lettersTotal = 0
        partHeading = None
        for chId in self.novel.srtChapters:
            dispNumber = 0
            doNotExport = False
            template = None
            if self.novel.chapters[chId].chType == 2:
                if self.novel.chapters[chId].chLevel == 1:
                    partHeading = Template(self._todoPartTemplate).safe_substitute(self._get_chapterMapping(chId, dispNumber))
                elif not self._chapterFilter.accept(self, chId):
                    partHeading = None
                    continue

                elif self._todoChapterTemplate:
                    if partHeading:
                        lines.append(partHeading)
                        partHeading = None
                    template = Template(self._todoChapterTemplate)
                    chapterNumber += 1
                    dispNumber = chapterNumber

                if template is not None:
                    lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))

                    sceneLines, sceneNumber, wordsTotal, lettersTotal = self._get_scenes(
                        chId, sceneNumber, wordsTotal, lettersTotal, doNotExport)
                    lines.extend(sceneLines)

        return lines

    def _get_sceneMapping(self, scId, sceneNumber, wordsTotal, lettersTotal):
        sceneMapping = super()._get_sceneMapping(scId, sceneNumber, wordsTotal, lettersTotal)
        sceneAssocId = self.novel.scenes[scId].kwVar.get('Field_SceneAssoc', None)
        if sceneAssocId:
            sceneAssocMapping = dict(
                SceneAssocId=sceneAssocId,
                SceneAssocTitle=self.novel.scenes[sceneAssocId].title,
                ProjectName=sceneMapping['ProjectName'],
                Scene=_('Scene'),
                Description=_('Description'),
                Manuscript=_('Manuscript'),
                ID=sceneAssocId,
                )
            template = Template(self._sceneLinkTemplate)
            sceneMapping['SceneAssoc'] = template.safe_substitute(sceneAssocMapping)
        else:
            sceneMapping['SceneAssoc'] = ''
        return sceneMapping


class ArcFilter:

    def accept(self, source, eId):
        if source.novel.chapters[eId].kwVar.get('Field_ArcDefinition', None):
            return True

        else:
            return False


class PointFilter:

    def accept(self, source, eId):
        if source.novel.scenes[eId].scnArcs:
            return True

        else:
            return False


class NvDocExporter(NvExporter):
    EXPORT_TARGET_CLASSES = [OdtWProof,
                             OdtWManuscript,
                             OdtWBriefSynopsis,
                             OdtWSceneDesc,
                             OdtWChapterDesc,
                             OdtWPartDesc,
                             OdtWExport,
                             OdtArcs,
                             OdtCharactersNv,
                             OdtWItems,
                             OdtWLocations,
                             OdtWXref,
                             OdtWNotes,
                             OdtWTodo,
                             OdsWCharList,
                             OdsWLocList,
                             OdsWItemList,
                             OdsWSceneList,
                             DataFiles,
                             WrimoFile,
                             ]

    def __init__(self, ui):
        DataFiles.SUFFIX = '_data'

        self.exportTargetFactory = ExportTargetFactory(self.EXPORT_TARGET_CLASSES)
        self.ui = ui
        self._source = None
        self._target = None
        self._lock = False
        self._show = False
        self._popup = None

    def run(self, source, suffix, lock=True, show=True):
        self._source = source
        self._lock = lock
        self._show = show
        self._popup = None
        self._isNewer = False
        kwargs = {'suffix':suffix}
        try:
            __, self._target = self.exportTargetFactory.make_file_objects(self._source.filePath, **kwargs)
        except Error as ex:
            self.ui.set_info_how(f'!{str(ex)}')
            return

        if os.path.isfile(self._target.filePath):
            self._ask()
        else:
            self._export()

    def _ask(self):
        targetTimestamp = os.path.getmtime(self._target.filePath)
        try:
            if  targetTimestamp > self.ui.prjFile.timestamp:
                timeStatus = _('Newer than the project file')
                self._isNewer = True
            else:
                timeStatus = _('Older than the project file')
        except:
            timeStatus = ''
        self._targetFileDate = datetime.fromtimestamp(targetTimestamp).replace(microsecond=0).isoformat(sep=' ')
        message = _('{0} already exists.\n{1} (last saved on {2}).\nOpen this document instead of overwriting it?').format(
                    norm_path(self._target.DESCRIPTION), timeStatus, self._targetFileDate)
        offset = 300
        __, x, y = self.ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        self._popup = tk.Toplevel()
        self._popup.resizable(0, 0)
        self._popup.geometry(windowGeometry)
        self._popup.title(self.ui.novel.title)
        self._popup.grab_set()
        tk.Label(self._popup, text=message, bg='white').pack(ipadx=10, ipady=30)
        cancelButton = ttk.Button(self._popup, text=_('Cancel'), command=self._cancel)
        cancelButton.pack(side='right', padx=5, pady=10)
        openButton = ttk.Button(self._popup, text=_('Open existing'), command=self._open_existing)
        openButton.pack(side='right', padx=5, pady=10)
        overwriteButton = ttk.Button(self._popup, text=_('Overwrite'), command=self._export)
        overwriteButton.pack(side='right', padx=5, pady=10)
        overwriteButton.focus_set()

    def _cancel(self):
        if self._popup is not None:
            self._popup.destroy()
        self.ui.set_info_how(f'!{_("Action canceled by user")}.')

    def _export(self):
        if self._popup is not None:
            self._popup.destroy()
        try:
            self._target.novel = self._source.novel
            self._target.write()
        except Error as ex:
            self.ui.set_info_how(f'!{str(ex)}')
        else:
            if self._lock and not self.ui.isLocked:
                self.ui.isLocked = True
            self._targetFileDate = datetime.now().replace(microsecond=0).isoformat(sep=' ')
            self.ui.set_info_how(_('Created {0} on {1}.').format(self._target.DESCRIPTION, self._targetFileDate))
            if self._show:
                if self.ui.ask_yes_no(_('Document "{}" created. Open now?').format(norm_path(self._target.filePath))):
                    open_document(self._target.filePath)

    def _open_existing(self):
        if self._popup is not None:
            self._popup.destroy()
        open_document(self._target.filePath)
        if self._isNewer:
            prefix = ''
        else:
            prefix = '!'
        self.ui.set_info_how(f'{prefix}{_("Opened existing {0} (last saved on {1})").format(self._target.DESCRIPTION, self._targetFileDate)}.')
        if self._lock and not self.ui.isLocked:
            self.ui.isLocked = True



class HtmlReport(FileExport):
    DESCRIPTION = 'HTML report'
    EXTENSION = '.html'
    SUFFIX = '_report'

    _fileHeader = '''<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

<style type="text/css">
body {font-family: sans-serif}
p.title {font-size: larger; font-weight: bold}
td {padding: 10}
tr.heading {font-size:smaller; font-weight: bold; background-color:lightgray}
table {border-spacing: 0}
table, td {border: lightgrey solid 1px; vertical-align: top}
td.chtitle {font-weight: bold}
</style>

'''

    _fileFooter = '''</table>
</body>
</html>
'''



class HtmlProjectNotes(HtmlReport):
    DESCRIPTION = 'HTML project notes report'
    EXTENSION = '.html'
    SUFFIX = '_projectnote_report'

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Project notes')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Project notes')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Title')}</td>
<td>{_('Text')}</td>
</tr>
'''

    _projectNoteTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$Desc</td>
</tr>
'''



class HtmlCharacters(HtmlReport):
    DESCRIPTION = 'HTML charcters report'
    EXTENSION = '.html'
    SUFFIX = '_character_report'

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Characters')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Characters')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Name')}</td>
<td>{_('Full name')}</td>
<td>{_('AKA')}</td>
<td>{_('Tags')}</td>
<td>{_('Description')}</td>
<td>{_('Bio')}</td>
<td>{_('Goals')}</td>
<td>{_('Notes')}</td>
</tr>
'''

    _characterTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$FullName</td>
<td>$AKA</td>
<td>$Tags</td>
<td>$Desc</td>
<td>$Bio</td>
<td>$Goals</td>
<td>$Notes</td>
</tr>
'''



class HtmlLocations(HtmlReport):
    DESCRIPTION = 'HTML locations report'
    EXTENSION = '.html'
    SUFFIX = '_location_report'

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Locations')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Locations')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Name')}</td>
<td>{_('AKA')}</td>
<td>{_('Tags')}</td>
<td>{_('Description')}</td>
</tr>
'''

    _locationTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$AKA</td>
<td>$Tags</td>
<td>$Desc</td>
</tr>
'''



class HtmlItems(HtmlReport):
    DESCRIPTION = 'HTML items report'
    EXTENSION = '.html'
    SUFFIX = '_item_report'

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Items')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Items')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Name')}</td>
<td>{_('AKA')}</td>
<td>{_('Tags')}</td>
<td>{_('Description')}</td>
</tr>
'''

    _itemTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$AKA</td>
<td>$Tags</td>
<td>$Desc</td>
</tr>
'''



class NvReporter(NvExporter):
    EXPORT_TARGET_CLASSES = [HtmlProjectNotes,
                             HtmlCharacters,
                             HtmlLocations,
                             HtmlItems,
                             ]

    def __init__(self, ui):
        self._exportTargetFactory = ExportTargetFactory(self.EXPORT_TARGET_CLASSES)
        self._ui = ui

    def run(self, source, suffix):
        kwargs = {'suffix':suffix}
        try:
            __, target = self._exportTargetFactory.make_file_objects(source.filePath, **kwargs)
        except Error as ex:
            self._ui.set_info_how(f'{str(ex)}')
        else:
            dirname, filename = os.path.split(target.filePath)
            try:
                if self._ui.tempDir:
                    dirname = self._ui.tempDir
            except:
                if not dirname:
                    dirname = '.'
            target.filePath = f'{dirname}/{filename}'
            try:
                target.novel = source.novel
                target.write()
            except Error as ex:
                self._ui.set_info_how(f'!{str(ex)}')
            else:
                open_document(target.filePath)



class CharacterDataReader(Yw7File):
    DESCRIPTION = _('XML character data file')
    EXTENSION = '.xml'

    def read(self):
        try:
            tree = ET.parse(self.filePath)
        except:
            raise Error(f'{_("Can not process file")}: "{norm_path(self.filePath)}".')
        else:
            root = ET.Element('ROOT')
            root.append(tree.getroot())
            self._read_characters(root)



class LocationDataReader(Yw7File):
    DESCRIPTION = _('XML location data file')
    EXTENSION = '.xml'

    def read(self):
        try:
            tree = ET.parse(self.filePath)
        except:
            raise Error(f'{_("Can not process file")}: "{norm_path(self.filePath)}".')
        else:
            root = ET.Element('ROOT')
            root.append(tree.getroot())
            self._read_locations(root)



class ItemDataReader(Yw7File):
    DESCRIPTION = _('XML item data file')
    EXTENSION = '.xml'

    def read(self):
        try:
            tree = ET.parse(self.filePath)
        except:
            raise Error(f'{_("Can not process file")}: "{norm_path(self.filePath)}".')
        else:
            root = ET.Element('ROOT')
            root.append(tree.getroot())
            self._read_items(root)


from tkinter import ttk


class DataImporter(tk.Toplevel):

    def __init__(self, ui, title, geometry, sourceElements, targetElements, targetSrtElements):
        super().__init__()
        self._ui = ui
        self.title(title)
        self.geometry(geometry)
        self.grab_set()
        self.focus()
        self._sourceElements = sourceElements
        self._targetElements = targetElements
        self._targetSrtElements = targetSrtElements
        self._pickList = ttk.Treeview(self, selectmode='extended')
        scrollY = ttk.Scrollbar(self._pickList, orient='vertical', command=self._pickList.yview)
        self._pickList.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')
        self._pickList.pack(fill='both', expand=True)
        ttk.Button(self, text=_('Import selected elements'), command=self._import).pack()
        for elemId in self._sourceElements:
            self._pickList.insert('', 'end', elemId, text=self._sourceElements[elemId].title)

    def _import(self):
        i = 0
        for  elemId in self._pickList.selection():
            newId = create_id(self._targetElements)
            self._targetElements[newId] = self._sourceElements[elemId]
            self._targetSrtElements.append(newId)
            i += 1
        if i > 0:
            self._ui.isModified = True
            self._ui.tv.refresh_tree()
            self._ui.show_info(f'{i} {_("elements imported")}', title=_('XML data import'))
        self.destroy()


PLUGIN_PATH = f'{sys.path[0]}/plugin'


class NovelystTk(MainTk):
    COLORING_MODES = [_('None'), _('Status'), _('Work phase'), _('Mode')]
    _HELP_URL = 'https://peter88213.github.io/novelyst/help/help'
    _KEY_NEW_PROJECT = ('<Control-n>', 'Ctrl-N')
    _KEY_LOCK_PROJECT = ('<Control-l>', 'Ctrl-L')
    _KEY_UNLOCK_PROJECT = ('<Control-u>', 'Ctrl-U')
    _KEY_FOLDER = ('<Control-p>', 'Ctrl-P')
    _KEY_RELOAD_PROJECT = ('<Control-r>', 'Ctrl-R')
    _KEY_REFRESH_TREE = ('<F5>', 'F5')
    _KEY_SAVE_PROJECT = ('<Control-s>', 'Ctrl-S')
    _KEY_SAVE_AS = ('<Control-S>', 'Ctrl-Shift-S')
    _KEY_CHAPTER_LEVEL = ('<Control-Alt-c>', 'Ctrl-Alt-C')
    _KEY_TOGGLE_VIEWER = ('<Control-t>', 'Ctrl-T')
    _KEY_TOGGLE_PROPERTIES = ('<Control-Alt-t>', 'Ctrl-Alt-T')
    _KEY_DETACH_PROPERTIES = ('<Control-Alt-d>', 'Ctrl-Alt-D')
    _KEY_GO_BACK = ('<F11>', 'F11')
    _KEY_GO_FORWARD = ('<F12>', 'F12')
    _KEY_SHOW_BOOK = (f'<Home>', f'{_("Home")}')
    _KEY_SHOW_CHARACTERS = ('<F6>', 'F6')
    _KEY_SHOW_LOCATIONS = ('<F7>', 'F7')
    _KEY_SHOW_ITEMS = ('<F8>', 'F8')
    _KEY_SHOW_RESEARCH = ('<F9>', 'F9')
    _KEY_SHOW_PLANNING = ('<F10>', 'F10')
    _KEY_SHOW_PROJECTNOTES = (f'<End>', f'{_("End")}')
    _KEY_SHOW_HELP = ('<F1>', 'F1')

    _YW_CLASS = WorkFile

    def __init__(self, colTitle, tempDir, **kwargs):
        super().__init__(colTitle, **kwargs)

        set_icon(self.root, icon='nLogo32')
        self._fileTypes = [(WorkFile.DESCRIPTION, WorkFile.EXTENSION)]

        self.guiStyle = ttk.Style()

        self.plugins = PluginCollection(self)

        self.tempDir = tempDir
        self.kwargs = kwargs
        self._internalModificationFlag = False
        self._internalLockFlag = False
        self.exporter = NvDocExporter(self)
        self.reporter = NvReporter(self)
        self.wordCount = 0
        self.reloading = False
        self.prjFile = None
        self.novel = None

        try:
            self.coloringMode = int(self.kwargs['coloring_mode'])
        except:
            self.coloringMode = 0
        if self.coloringMode > len(self.COLORING_MODES):
            self.coloringMode = 0

        self.cleanUpYw = self.kwargs['clean_up_yw']


        self.appWindow = ttk.Frame(self.mainWindow)
        self.appWindow.pack(expand=True, fill='both')

        self.leftFrame = ttk.Frame(self.appWindow)
        self.leftFrame.pack(side='left', expand=True, fill='both')

        self.tv = TreeViewer(self.leftFrame, self, self.kwargs)
        self.tv.pack(expand=True, fill='both')

        self.middleFrame = ttk.Frame(self.appWindow, width=self.kwargs['middle_frame_width'])
        self.middleFrame.pack_propagate(0)

        self.contentsViewer = ContentsViewer(self, self.middleFrame, **self.kwargs)
        self.contentsViewer.pack(expand=True, fill='both')
        if self.kwargs['show_contents']:
            self.middleFrame.pack(side='left', expand=False, fill='both')


        self.fileMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('File'), menu=self.fileMenu)
        self.fileMenu.add_command(label=_('New'), accelerator=self._KEY_NEW_PROJECT[1], command=self.new_project)
        self.fileMenu.add_command(label=_('Open...'), accelerator=self._KEY_OPEN_PROJECT[1], command=lambda: self.open_project(''))
        self.fileMenu.add_command(label=_('Reload'), accelerator=self._KEY_RELOAD_PROJECT[1], command=self.reload_project)
        self.fileMenu.add_separator()
        self.fileMenu.add_command(label=_('Refresh Tree'), accelerator=self._KEY_REFRESH_TREE[1], command=self.refresh_tree)
        self.fileMenu.add_command(label=_('Lock'), accelerator=self._KEY_LOCK_PROJECT[1], command=self.lock)
        self.fileMenu.add_command(label=_('Unlock'), accelerator=self._KEY_UNLOCK_PROJECT[1], command=self.unlock)
        self.fileMenu.add_command(label=_('Open Project folder'), accelerator=self._KEY_FOLDER[1], command=self.open_projectFolder)
        self.fileMenu.add_command(label=_('Discard manuscript'), command=self.discard_manuscript)
        self.fileMenu.add_separator()
        self.fileMenu.add_command(label=_('Save'), accelerator=self._KEY_SAVE_PROJECT[1], command=self.save_project)
        self.fileMenu.add_command(label=_('Save as...'), accelerator=self._KEY_SAVE_AS[1], command=self.save_as)
        self.fileMenu.add_command(label=_('Close'), command=self.close_project)
        self.fileMenu.add_command(label=_('Exit'), accelerator=self._KEY_QUIT_PROGRAM[1], command=self.on_quit)

        self.viewMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('View'), menu=self.viewMenu)
        self.viewMenu.add_command(label=_('Chapter level'), accelerator=self._KEY_CHAPTER_LEVEL[1], command=self.show_chapter_level)
        self.viewMenu.add_command(label=_('Expand selected'), command=lambda: self.tv.open_children(self.tv.tree.selection()[0]))
        self.viewMenu.add_command(label=_('Collapse selected'), command=lambda: self.tv.close_children(self.tv.tree.selection()[0]))
        self.viewMenu.add_command(label=_('Expand all'), command=lambda: self.tv.open_children(''))
        self.viewMenu.add_command(label=_('Collapse all'), command=lambda: self.tv.close_children(''))
        self.viewMenu.add_separator()
        self.viewMenu.add_command(label=_('Show Book'), accelerator=self._KEY_SHOW_BOOK[1], command=lambda: self.tv.show_branch(self.tv.NV_ROOT))
        self.viewMenu.add_command(label=_('Show Characters'), accelerator=self._KEY_SHOW_CHARACTERS[1], command=lambda: self.tv.show_branch(self.tv.CR_ROOT))
        self.viewMenu.add_command(label=_('Show Locations'), accelerator=self._KEY_SHOW_LOCATIONS[1], command=lambda: self.tv.show_branch(self.tv.LC_ROOT))
        self.viewMenu.add_command(label=_('Show Items'), accelerator=self._KEY_SHOW_ITEMS[1], command=lambda: self.tv.show_branch(self.tv.IT_ROOT))
        self.viewMenu.add_command(label=_('Show Research'), accelerator=self._KEY_SHOW_RESEARCH[1], command=lambda: self.tv.show_branch(self.tv.RS_ROOT))
        self.viewMenu.add_command(label=_('Show Planning'), accelerator=self._KEY_SHOW_PLANNING[1], command=lambda: self.tv.show_branch(self.tv.PL_ROOT))
        self.viewMenu.add_command(label=_('Show Project notes'), accelerator=self._KEY_SHOW_PROJECTNOTES[1], command=lambda: self.tv.show_branch(self.tv.PN_ROOT))
        self.viewMenu.add_separator()
        self.viewMenu.add_command(label=_('Toggle Text viewer'), accelerator=self._KEY_TOGGLE_VIEWER[1], command=self.toggle_viewer)
        self.viewMenu.add_command(label=_('Toggle Properties'), accelerator=self._KEY_TOGGLE_PROPERTIES[1], command=self.toggle_properties)
        self.viewMenu.add_command(label=_('Detach/Dock Properties'), accelerator=self._KEY_DETACH_PROPERTIES[1], command=self.toggle_properties_window)

        self.partMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Part'), menu=self.partMenu)
        self.partMenu.add_command(label=_('Add'), command=self.tv.add_part)
        self.partMenu.add_separator()
        self.partMenu.add_command(label=_('Export part descriptions for editing'), command=lambda: self.export_document('_parts'))

        self.chapterMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Chapter'), menu=self.chapterMenu)
        self.chapterMenu.add_command(label=_('Add'), command=self.tv.add_chapter)
        self.chapterMenu.add_separator()
        self.chapterMenu.add_command(label=_('Export chapter descriptions for editing'), command=lambda: self.export_document('_chapters'))

        self.sceneMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Scene'), menu=self.sceneMenu)
        self.sceneMenu.add_command(label=_('Add'), command=self.tv.add_scene)
        self.sceneMenu.add_separator()
        self.sceneMenu.add_cascade(label=_('Set Type'), menu=self.tv.scTypeMenu)
        self.sceneMenu.add_cascade(label=_('Set Status'), menu=self.tv.scStatusMenu)
        self.sceneMenu.add_separator()
        self.sceneMenu.add_cascade(label=_('Set Mode'), menu=self.tv.scStyleMenu)
        self.sceneMenu.add_separator()
        self.sceneMenu.add_command(label=_('Export scene descriptions for editing'), command=lambda: self.export_document('_scenes'))
        self.sceneMenu.add_command(label=_('Export scene list (spreadsheet)'), command=lambda: self.export_document('_scenelist'))

        self.characterMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Characters'), menu=self.characterMenu)
        self.characterMenu.add_command(label=_('Add'), command=self.tv.add_character)
        self.characterMenu.add_separator()
        self.characterMenu.add_cascade(label=_('Set Status'), menu=self.tv.crStatusMenu)
        self.characterMenu.add_separator()
        self.characterMenu.add_command(label=_('Import'), command=self.import_characters)
        self.characterMenu.add_separator()
        self.characterMenu.add_command(label=_('Export character descriptions for editing'), command=lambda: self.export_document('_characters'))
        self.characterMenu.add_command(label=_('Export character list (spreadsheet)'), command=lambda: self.export_document('_charlist'))
        self.characterMenu.add_command(label=_('Show list'), command=lambda: self._show_report('_character_report'))

        self.locationMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Locations'), menu=self.locationMenu)
        self.locationMenu.add_command(label=_('Add'), command=self.tv.add_location)
        self.locationMenu.add_separator()
        self.locationMenu.add_command(label=_('Import'), command=self.import_locations)
        self.locationMenu.add_separator()
        self.locationMenu.add_command(label=_('Export location descriptions for editing'), command=lambda: self.export_document('_locations'))
        self.locationMenu.add_command(label=_('Export location list (spreadsheet)'), command=lambda: self.export_document('_loclist'))
        self.locationMenu.add_command(label=_('Show list'), command=lambda: self._show_report('_location_report'))

        self.itemMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Items'), menu=self.itemMenu)
        self.itemMenu.add_command(label=_('Add'), command=self.tv.add_item)
        self.itemMenu.add_separator()
        self.itemMenu.add_command(label=_('Import'), command=self.import_items)
        self.itemMenu.add_separator()
        self.itemMenu.add_command(label=_('Export item descriptions for editing'), command=lambda: self.export_document('_items'))
        self.itemMenu.add_command(label=_('Export item list (spreadsheet)'), command=lambda: self.export_document('_itemlist'))
        self.itemMenu.add_command(label=_('Show list'), command=lambda: self._show_report('_item_report'))

        self.prjNoteMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Project notes'), menu=self.prjNoteMenu)
        self.prjNoteMenu.add_command(label=_('Add'), command=self.tv.add_project_note)
        self.prjNoteMenu.add_separator()
        self.prjNoteMenu.add_command(label=_('Show list'), command=lambda: self._show_report('_projectnote_report'))

        self.exportMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Export'), menu=self.exportMenu)
        self.exportMenu.add_command(label=_('Manuscript for editing'), command=lambda:self.export_document('_manuscript'))
        self.exportMenu.add_command(label=_('Notes chapters for editing'), command=lambda: self.export_document('_notes'))
        self.exportMenu.add_command(label=_('Todo chapters for editing'), command=lambda: self.export_document('_todo'))
        self.exportMenu.add_separator()
        self.exportMenu.add_command(label=_('Manuscript with visible structure tags for proof reading'), command=lambda: self.export_document('_proof'))
        self.exportMenu.add_separator()
        self.exportMenu.add_command(label=_('Manuscript without tags (export only)'), command=lambda: self.export_document('', lock=False))
        self.exportMenu.add_command(label=_('Brief synopsis (export only)'), command=lambda: self.export_document('_brf_synopsis', lock=False))
        self.exportMenu.add_command(label=_('Arcs (export only)'), command=lambda: self.export_document('_arcs', lock=False))
        self.exportMenu.add_command(label=_('Cross references (export only)'), command=lambda: self.export_document('_xref', lock=False))
        self.exportMenu.add_separator()
        self.exportMenu.add_command(label=_('Obfuscated text for word count'), command=lambda: self.export_document('_wrimo', lock=False, show=False))
        self.exportMenu.add_command(label=_('Characters/locations/items data files'), command=lambda: self.export_document('_data', lock=False, show=False))

        self.toolsMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Tools'), menu=self.toolsMenu)
        self.toolsMenu.add_command(label=_('Program settings'), command=self.edit_settings)
        self.toolsMenu.add_command(label=_('Plugin Manager'), command=self.manage_plugins)
        self.toolsMenu.add_command(label=_('Open installation folder'), command=self.open_installationFolder)
        self.toolsMenu.add_separator()

        self.helpMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), accelerator=self._KEY_SHOW_HELP[1], command=lambda: webbrowser.open(self._HELP_URL))

        self.plugins.load_plugins(PLUGIN_PATH)
        self.disable_menu()

        self.rightFrame = ttk.Frame(self.appWindow, width=self.kwargs['right_frame_width'])
        self.rightFrame.pack_propagate(0)
        if self.kwargs['show_properties']:
            self.rightFrame.pack(expand=True, fill='both')
        self._initialize_properties_frame(self.rightFrame)
        self._propWinDetached = False
        if self.kwargs['detach_prop_win']:
            self.detach_properties_frame()

        self.root.bind(self._KEY_NEW_PROJECT[0], self.new_project)
        self.root.bind(self._KEY_LOCK_PROJECT[0], self.lock)
        self.root.bind(self._KEY_UNLOCK_PROJECT[0], self.unlock)
        self.root.bind(self._KEY_RELOAD_PROJECT[0], self.reload_project)
        self.root.bind(self._KEY_FOLDER[0], self.open_projectFolder)
        self.root.bind(self._KEY_REFRESH_TREE[0], self.refresh_tree)
        self.root.bind(self._KEY_SAVE_PROJECT[0], self.save_project)
        self.root.bind(self._KEY_SAVE_AS[0], self.save_as)
        self.root.bind(self._KEY_CHAPTER_LEVEL[0], self.show_chapter_level)
        self.root.bind(self._KEY_TOGGLE_VIEWER[0], self.toggle_viewer)
        self.root.bind(self._KEY_TOGGLE_PROPERTIES[0], self.toggle_properties)
        self.root.bind(self._KEY_DETACH_PROPERTIES[0], self.toggle_properties_window)
        self.root.bind(self._KEY_GO_BACK[0], self.tv.go_back)
        self.root.bind(self._KEY_GO_FORWARD[0], self.tv.go_forward)
        if sys.platform == 'win32':
            self.root.bind('<4>', self.tv.go_back)
            self.root.bind('<5>', self.tv.go_forward)
        self.root.bind(self._KEY_SHOW_BOOK[0], lambda event: self.tv.show_branch(self.tv.NV_ROOT))
        self.root.bind(self._KEY_SHOW_CHARACTERS[0], lambda event: self.tv.show_branch(self.tv.CR_ROOT))
        self.root.bind(self._KEY_SHOW_LOCATIONS[0], lambda event: self.tv.show_branch(self.tv.LC_ROOT))
        self.root.bind(self._KEY_SHOW_ITEMS[0], lambda event: self.tv.show_branch(self.tv.IT_ROOT))
        self.root.bind(self._KEY_SHOW_RESEARCH[0], lambda event: self.tv.show_branch(self.tv.RS_ROOT))
        self.root.bind(self._KEY_SHOW_PLANNING[0], lambda event: self.tv.show_branch(self.tv.PL_ROOT))
        self.root.bind(self._KEY_SHOW_PROJECTNOTES[0], lambda event: self.tv.show_branch(self.tv.PN_ROOT))
        self.root.bind(self._KEY_SHOW_HELP[0], lambda event: webbrowser.open(self._HELP_URL))

    @property
    def isModified(self):
        return self._internalModificationFlag

    @isModified.setter
    def isModified(self, setFlag):
        if setFlag:
            self.contentsViewer.update()
            self._internalModificationFlag = True
            self.pathBar.config(bg=self.kwargs['color_modified_bg'])
            self.pathBar.config(fg=self.kwargs['color_modified_fg'])
        else:
            self._internalModificationFlag = False
            if not self.isLocked:
                self.pathBar.config(bg=self.root.cget('background'))
                self.pathBar.config(fg='black')

    @property
    def isLocked(self):
        return self._internalLockFlag

    @isLocked.setter
    def isLocked(self, setFlag):
        if setFlag:
            if self.isModified and not self._internalLockFlag:
                if self.ask_yes_no(_('Save and lock?')):
                    self.save_project()
                else:
                    return

            self._internalLockFlag = True
            self.pathBar.config(bg=self.kwargs['color_locked_bg'])
            self.pathBar.config(fg=self.kwargs['color_locked_fg'])
            self.fileMenu.entryconfig(_('Save'), state='disabled')
            self.fileMenu.entryconfig(_('Lock'), state='disabled')
            self.fileMenu.entryconfig(_('Unlock'), state='normal')
        else:
            self._internalLockFlag = False
            self.pathBar.config(bg=self.root.cget('background'))
            self.pathBar.config(fg='black')
            self.fileMenu.entryconfig(_('Save'), state='normal')
            self.fileMenu.entryconfig(_('Lock'), state='normal')
            self.fileMenu.entryconfig(_('Unlock'), state='disabled')

    def check_lock(self, event=None):
        if self.isLocked:
            if self.ask_yes_no(_('The project is locked.\nUnlock?'), title=_('Can not do')):
                self.unlock()
                return False

            else:
                return True
        else:
            return False

    def close_project(self, event=None):
        self._elementView.apply_changes()
        self.contentsViewer.reset_view()
        self.plugins.on_close()

        if self.isModified and not self.reloading:
            if self.ask_yes_no(_('Save changes?')):
                self.save_project()
        self.isModified = False
        self.view_nothing()
        self.tv.reset_tree()
        self.reloading = False
        self.isLocked = False
        self.novel = None
        super().close_project()

    def detach_properties_frame(self, event=None):
        self._elementView.apply_changes()
        if self._propWinDetached:
            return

        if self.rightFrame.winfo_manager():
            self.rightFrame.pack_forget()
        self._propertiesWindow = tk.Toplevel()
        self._propertiesWindow.geometry(self.kwargs['prop_win_geometry'])
        set_icon(self._propertiesWindow, icon='pLogo32', default=False)
        self._elementView.pack_forget()
        self._initialize_properties_frame(self._propertiesWindow)
        self._elementView.pack()
        self.show_properties()
        self._propertiesWindow.protocol("WM_DELETE_WINDOW", self.dock_properties_frame)
        self.kwargs['detach_prop_win'] = True
        self._propWinDetached = True

    def dock_properties_frame(self, event=None):
        self._elementView.apply_changes()
        if not self._propWinDetached:
            return

        self._initialize_properties_frame(self.rightFrame)
        if not self.rightFrame.winfo_manager():
            self.rightFrame.pack(side='left', expand=False, fill='both')
        self._elementView.pack()
        self.show_properties()
        self.kwargs['prop_win_geometry'] = self._propertiesWindow.winfo_geometry()
        self._propertiesWindow.destroy()
        self.kwargs['show_properties'] = True
        self.kwargs['detach_prop_win'] = False
        self._propWinDetached = False
        self.root.lift()

    def disable_menu(self):
        super().disable_menu()
        self.mainMenu.entryconfig(_('View'), state='disabled')
        self.mainMenu.entryconfig(_('Part'), state='disabled')
        self.mainMenu.entryconfig(_('Chapter'), state='disabled')
        self.mainMenu.entryconfig(_('Scene'), state='disabled')
        self.mainMenu.entryconfig(_('Characters'), state='disabled')
        self.mainMenu.entryconfig(_('Locations'), state='disabled')
        self.mainMenu.entryconfig(_('Items'), state='disabled')
        self.mainMenu.entryconfig(_('Export'), state='disabled')
        self.mainMenu.entryconfig(_('Project notes'), state='disabled')

        self.fileMenu.entryconfig(_('Reload'), state='disabled')
        self.fileMenu.entryconfig(_('Refresh Tree'), state='disabled')
        self.fileMenu.entryconfig(_('Lock'), state='disabled')
        self.fileMenu.entryconfig(_('Unlock'), state='disabled')
        self.fileMenu.entryconfig(_('Open Project folder'), state='disabled')
        self.fileMenu.entryconfig(_('Save'), state='disabled')
        self.fileMenu.entryconfig(_('Save as...'), state='disabled')

        self.plugins.disable_menu()

    def discard_manuscript(self):
        fileName, __ = os.path.splitext(self.prjFile.filePath)
        manuscriptPath = f'{fileName}_manuscript.odt'
        if os.path.isfile(manuscriptPath):
            prjPath, manuscriptName = os.path.split(manuscriptPath)
            if os.path.isfile(f'{prjPath}/.~lock.{manuscriptName}#'):
                self.set_info_how(f"!{_('Please close the manuscript first')}.")
            elif self.ask_yes_no(f"{_('Discard manuscript')}?", self.novel.title):
                os.replace(manuscriptPath, f'{fileName}_manuscript.odt.bak')
                self.set_info_how(f"{_('Manuscript discarded')}.")

    def edit_settings(self, event=None):
        offset = 300
        __, x, y = self.root.geometry().split('+')
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        SettingsWindow(self.tv, self, windowGeometry)

    def enable_menu(self):
        super().enable_menu()
        self.mainMenu.entryconfig(_('View'), state='normal')
        self.mainMenu.entryconfig(_('Part'), state='normal')
        self.mainMenu.entryconfig(_('Chapter'), state='normal')
        self.mainMenu.entryconfig(_('Scene'), state='normal')
        self.mainMenu.entryconfig(_('Characters'), state='normal')
        self.mainMenu.entryconfig(_('Locations'), state='normal')
        self.mainMenu.entryconfig(_('Items'), state='normal')
        self.mainMenu.entryconfig(_('Export'), state='normal')
        self.mainMenu.entryconfig(_('Project notes'), state='normal')

        self.fileMenu.entryconfig(_('Reload'), state='normal')
        self.fileMenu.entryconfig(_('Refresh Tree'), state='normal')
        self.fileMenu.entryconfig(_('Lock'), state='normal')
        self.fileMenu.entryconfig(_('Open Project folder'), state='normal')
        self.fileMenu.entryconfig(_('Save'), state='normal')
        self.fileMenu.entryconfig(_('Save as...'), state='normal')

        self.plugins.enable_menu()

    def export_document(self, suffix, **kwargs):
        self.restore_status()
        self._elementView.apply_changes()
        self.exporter.run(self.prjFile, suffix, **kwargs)

    def import_characters(self):
        self.restore_status()
        fileTypes = [(_('XML data file'), '.xml')]
        filePath = filedialog.askopenfilename(filetypes=fileTypes)
        if filePath:
            source = CharacterDataReader(filePath)
            source.novel = Novel()
            try:
                source.read()
            except:
                self.set_info_how(f"!{_('No character data found')}: {norm_path(filePath)}")
            else:
                offset = 50
                size = '300x400'
                __, x, y = self.root.geometry().split('+')
                windowGeometry = f'{size}+{int(x)+offset}+{int(y)+offset}'
                DataImporter(self, _('Select characters'),
                             windowGeometry,
                             source.novel.characters,
                             self.prjFile.novel.characters,
                             self.prjFile.novel.srtCharacters)

    def import_locations(self):
        self.restore_status()
        fileTypes = [(_('XML data file'), '.xml')]
        filePath = filedialog.askopenfilename(filetypes=fileTypes)
        if filePath:
            source = LocationDataReader(filePath)
            source.novel = Novel()
            try:
                source.read()
            except:
                self.set_info_how(f"!{_('No location data found')}: {norm_path(filePath)}")
            else:
                offset = 50
                size = '300x400'
                __, x, y = self.root.geometry().split('+')
                windowGeometry = f'{size}+{int(x)+offset}+{int(y)+offset}'
                DataImporter(self, _('Select locations'),
                             windowGeometry,
                             source.novel.locations,
                             self.prjFile.novel.locations,
                             self.prjFile.novel.srtLocations)

    def import_items(self):
        self.restore_status()
        fileTypes = [(_('XML data file'), '.xml')]
        filePath = filedialog.askopenfilename(filetypes=fileTypes)
        if filePath:
            source = ItemDataReader(filePath)
            source.novel = Novel()
            try:
                source.read()
            except:
                self.set_info_how(f"!{_('No item data found')}: {norm_path(filePath)}")
            else:
                offset = 50
                size = '300x400'
                __, x, y = self.root.geometry().split('+')
                windowGeometry = f'{size}+{int(x)+offset}+{int(y)+offset}'
                DataImporter(self, _('Select items'),
                             windowGeometry,
                             source.novel.items,
                             self.prjFile.novel.items,
                             self.prjFile.novel.srtItems)

    def lock(self, event=None):
        if self.prjFile.filePath is not None:
            self.isLocked = True
            if self.isLocked:
                self.prjFile.lock()
                return True

        return False

    def manage_plugins(self, event=None):
        offset = 300
        __, x, y = self.root.geometry().split('+')
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        PluginManager(self, windowGeometry)

    def new_project(self, event=None):
        if self.prjFile is not None:
            self.close_project()
        fileName = filedialog.asksaveasfilename(filetypes=self._fileTypes, defaultextension=self._fileTypes[0][1])
        if fileName:
            self.prjFile = WorkFile(fileName)
            self.novel = Novel()
            self.novel.title = ''
            self.novel.authorName = ''
            self.novel.authorBio = ''
            self.novel.desc = ''
            self.novel.wordCountStart = 0
            self.novel.wordTarget = 0
            self.prjFile.novel = self.novel
            self.set_title()
            self.show_path(norm_path(fileName))
            self.enable_menu()
            self.tv.build_tree()
            self.show_status()
            self.isModified = True

            for fieldName in self.prjFile.PRJ_KWVAR:
                self.novel.kwVar[fieldName] = None
            self.novel.kwVar['Field_WorkPhase'] = 1

    def on_quit(self, event=None):
        try:
            self._elementView.apply_changes()

            self.close_project()
            self.plugins.on_quit()

            self.kwargs['show_markup'] = self.contentsViewer.showMarkup.get()

            self.kwargs['clean_up_yw'] = self.cleanUpYw

            self.kwargs['coloring_mode'] = self.coloringMode

            if self._propWinDetached:
                self.kwargs['prop_win_geometry'] = self._propertiesWindow.winfo_geometry()
            self.tv.on_quit()
            super().on_quit()
        except Exception as ex:
            self.show_error(str(ex), title='ERROR: Unhandled exception on exit')
            self.root.quit()

    def open_project(self, fileName=''):
        if not super().open_project(fileName):
            return False

        self.show_path(_('{0} (last saved on {1})').format(norm_path(self.prjFile.filePath), self.prjFile.fileDate))
        self.tv.build_tree()
        self.show_status()
        self.contentsViewer.view_text()
        if self.prjFile.wcLogUpdate and self.novel.kwVar.get('Field_SaveWordCount', False):
            self.isModified = True
        else:
            self.isModified = False
        if self.prjFile.has_lockfile():
            self.isLocked = True
        return True

    def open_installationFolder(self, event=None):
        installDir = os.path.dirname(sys.argv[0])
        try:
            os.startfile(norm_path(installDir))
        except:
            try:
                os.system('xdg-open "%s"' % norm_path(installDir))
            except:
                try:
                    os.system('open "%s"' % norm_path(installDir))
                except:
                    pass

    def open_projectFolder(self, event=None):
        projectDir, __ = os.path.split(self.prjFile.filePath)
        try:
            os.startfile(norm_path(projectDir))
        except:
            try:
                os.system('xdg-open "%s"' % norm_path(projectDir))
            except:
                try:
                    os.system('open "%s"' % norm_path(projectDir))
                except:
                    pass

    def refresh_tree(self, event=None):
        self._elementView.apply_changes()
        self.tv.refresh_tree()

    def reload_project(self, event=None):
        if self.prjFile.is_locked():
            self.set_info_how(f'!{_("yWriter seems to be open. Please close first")}.')
            return

        if self.isModified and not self.ask_yes_no(_('Discard changes and reload the project?')):
            return

        if self.prjFile.has_changed_on_disk() and not self.ask_yes_no(_('File has changed on disk. Reload anyway?')):
            return

        self.reloading = True
        self.open_project(self.prjFile.filePath)

    def save_as(self, event=None):
        fileName = filedialog.asksaveasfilename(filetypes=self._fileTypes, defaultextension=self._fileTypes[0][1])
        if fileName:
            if self.prjFile is not None:
                self.prjFile.filePath = fileName
                try:
                    self.prjFile.write()
                except Error as ex:
                    self.set_info_how(f'!{str(ex)}')
                else:
                    self.unlock()
                    self.show_path(f'{norm_path(self.prjFile.filePath)} ({_("last saved on")} {self.prjFile.fileDate})')
                    self.isModified = False
                    self.restore_status(event)
                    self.kwargs['yw_last_open'] = self.prjFile.filePath
                    return True

        return False

    def save_project(self, event=None):
        if self.check_lock():
            self.set_info_how(f'!{_("Cannot save: The project is locked")}.')
            return False

        if self.prjFile.is_locked():
            self.set_info_how(f'!{_("yWriter seems to be open. Please close first")}.')
            return False

        if self.prjFile.has_changed_on_disk() and not self.ask_yes_no(_('File has changed on disk. Save anyway?')):
            return False

        self._elementView.apply_changes()
        try:
            if self.cleanUpYw:
                self.prjFile.tree = None
            self.prjFile.write()
        except Error as ex:
            self.set_info_how(f'!{str(ex)}')
            return False

        self.show_path(f'{norm_path(self.prjFile.filePath)} ({_("last saved on")} {self.prjFile.fileDate})')
        self.isModified = False
        self.restore_status(event)
        self.kwargs['yw_last_open'] = self.prjFile.filePath
        return True

    def show_chapter_level(self, event=None):
        self.tv.show_chapters(self.tv.NV_ROOT)

    def show_properties(self, event=None):
        try:
            nodeId = self.tv.tree.selection()[0]
            if nodeId.startswith(self.tv.SCENE_PREFIX):
                self.view_scene(nodeId[2:])
            elif nodeId.startswith(self.tv.CHAPTER_PREFIX):
                self.view_chapter(nodeId[2:])
            elif nodeId.startswith(self.tv.PART_PREFIX):
                self.view_chapter(nodeId[2:])
            elif nodeId.startswith(self.tv.NV_ROOT):
                self.view_narrative()
            elif nodeId.startswith(self.tv.CHARACTER_PREFIX):
                self.view_character(nodeId[2:])
            elif nodeId.startswith(self.tv.LOCATION_PREFIX):
                self.view_location(nodeId[2:])
            elif nodeId.startswith(self.tv.ITEM_PREFIX):
                self.view_item(nodeId[2:])
            elif nodeId.startswith(self.tv.PRJ_NOTE_PREFIX):
                self.view_projectNote(nodeId[2:])
            else:
                self.view_nothing()
        except IndexError:
            pass

    def show_status(self, message=None):
        if self.prjFile is not None and not message:
            wordCount, sceneCount, chapterCount, partCount = self.prjFile.get_counts()
            message = _('{0} parts, {1} chapters, {2} scenes, {3} words').format(partCount, chapterCount, sceneCount, wordCount)
            self.wordCount = wordCount
        super().show_status(message)

    def toggle_lock(self):
        if self.isLocked:
            self.unlock()
        else:
            self.lock()

    def toggle_viewer(self, event=None):
        if self.middleFrame.winfo_manager():
            self.middleFrame.pack_forget()
            self.kwargs['show_contents'] = False
        else:
            self.middleFrame.pack(after=self.leftFrame, side='left', expand=False, fill='both')
            self.kwargs['show_contents'] = True

    def toggle_properties(self, event=None):
        if self.rightFrame.winfo_manager():
            self._elementView.apply_changes()
            self.rightFrame.pack_forget()
            self.kwargs['show_properties'] = False
        elif not self._propWinDetached:
            self.rightFrame.pack(side='left', expand=False, fill='both')
            self.kwargs['show_properties'] = True

    def toggle_properties_window(self, event=None):
        if self._propWinDetached:
            self.dock_properties_frame()
        else:
            self.detach_properties_frame()

    def unlock(self, event=None):
        self.isLocked = False
        self.prjFile.unlock()
        if self.prjFile.has_changed_on_disk():
            if self.ask_yes_no(_('File has changed on disk. Reload?')):
                self.open_project(self.prjFile.filePath)

    def view_chapter(self, chId):
        self._elementView.apply_changes()
        if self.novel.chapters[chId].chLevel == 0 and self.novel.chapters[chId].chType == 2:
            if not self._elementView is self._todoChapterView:
                self._elementView.hide()
                self._elementView = self._todoChapterView
                self._elementView.show()
        else:
            if not self._elementView is self._chapterView:
                self._elementView.hide()
                self._elementView = self._chapterView
                self._elementView.show()
        self._elementView.set_data(self.novel.chapters[chId])
        self.contentsViewer.see(f'ch{chId}')

    def view_character(self, crId):
        self._elementView.apply_changes()
        if not self._elementView is self._characterView:
            self._elementView.hide()
            self._elementView = self._characterView
            self._elementView.show()
        self._elementView.set_data(self.novel.characters[crId])

    def view_item(self, itId):
        self._elementView.apply_changes()
        if not self._elementView is self._worldElementView:
            self._elementView.hide()
            self._elementView = self._worldElementView
            self._elementView.show()
        self._elementView.set_data(self.novel.items[itId])

    def view_location(self, lcId):
        self._elementView.apply_changes()
        if not self._elementView is self._worldElementView:
            self._elementView.hide()
            self._elementView = self._worldElementView
            self._elementView.show()
        self._elementView.set_data(self.novel.locations[lcId])

    def view_narrative(self):
        self._elementView.apply_changes()
        if not self._elementView is self._projectView:
            self._elementView.hide()
            self._elementView = self._projectView
            self._elementView.show()
        self._elementView.set_data(self.novel)

    def view_nothing(self):
        if not self._elementView is self._basicView:
            self._elementView.apply_changes()
            self._elementView.hide()
            self._elementView = self._basicView
            self._elementView.show()

    def view_projectNote(self, pnId):
        self._elementView.apply_changes()
        if not self._elementView is self._projectnoteView:
            self._elementView.hide()
            self._elementView = self._projectnoteView
            self._elementView.show()
        self._elementView.set_data(self.novel.projectNotes[pnId])

    def view_scene(self, scId):
        self._elementView.apply_changes()
        if self.novel.scenes[scId].scType == 2:
            if not self._elementView is self._todoSceneView:
                self._elementView.hide()
                self._elementView = self._todoSceneView
                self._elementView.show()
        elif self.novel.scenes[scId].scType == 1:
            if not self._elementView is self._notesSceneView:
                self._elementView.hide()
                self._elementView = self._notesSceneView
                self._elementView.show()
        else:
            if not self._elementView is self._sceneView:
                self._elementView.hide()
                self._elementView = self._sceneView
                self._elementView.show()
        self._elementView.set_data(self.novel.scenes[scId])
        self.contentsViewer.see(f'sc{scId}')

    def _build_main_menu(self):
        pass

    def _initialize_properties_frame(self, parent):
        self._basicView = BasicView(self, parent)
        self._projectView = ProjectView(self, parent)
        self._chapterView = ChapterView(self, parent)
        self._todoChapterView = TodoChapterView(self, parent)
        self._todoSceneView = TodoSceneView(self, parent)
        self._notesSceneView = NotesSceneView(self, parent)
        self._sceneView = NormalSceneView(self, parent)
        self._characterView = CharacterView(self, parent)
        self._projectnoteView = ProjectnoteView(self, parent)
        self._worldElementView = WorldElementView(self, parent)

        self._elementView = self._basicView
        self._elementView.set_data(None)

    def _show_report(self, suffix):
        self.restore_status()
        self._elementView.apply_changes()
        self.reporter.run(self.prjFile, suffix)


APPNAME = 'novelyst'
SETTINGS = dict(
    yw_last_open='',
    root_geometry='1200x800',
    gui_theme='',
    button_context_menu='<Button-3>',
    middle_frame_width=400,
    right_frame_width=350,
    index_card_height=13,
    gco_height=4,
    prop_win_geometry='299x716+260+260',
    color_chapter='green',
    color_unused='gray',
    color_not_exported='rosy brown',
    color_notes='blue',
    color_todo='red',
    color_major='navy',
    color_minor='cornflower blue',
    color_outline='dark orchid',
    color_draft='black',
    color_1st_edit='DarkGoldenrod4',
    color_2nd_edit='DarkGoldenrod3',
    color_done='DarkGoldenrod2',
    color_staged='black',
    color_descriptive='light sea green',
    color_explaining='brown',
    color_summarizing='cornflower blue',
    color_behind_schedule='tomato',
    color_before_schedule='sea green',
    color_on_schedule='black',
    color_locked_bg='dim gray',
    color_locked_fg='light gray',
    color_modified_bg='goldenrod1',
    color_modified_fg='maroon',
    color_text_bg='white',
    color_text_fg='black',
    color_notes_bg='lemon chiffon',
    color_notes_fg='black',
    coloring_mode='',
    title_width=400,
    ps_width=50,
    wc_width=50,
    status_width=100,
    mode_width=100,
    nt_width=20,
    vp_width=100,
    tags_width=100,
    pacing_width=40,
    date_width=70,
    time_width=40,
    duration_width=55,
    arcs_width=55,
    plot_width=300,
    column_order='wc;vp;sy;st;nt;dt;tm;dr;tg;po;ac;pt;ar'
)
OPTIONS = dict(
    show_contents=True,
    show_properties=True,
    show_markup=False,
    show_language_settings=False,
    show_auto_numbering=False,
    show_renamings=False,
    show_writing_progress=False,
    show_arcs=False,
    show_date_time=False,
    show_action_reaction=False,
    show_relationships=False,
    show_cr_bio=True,
    show_cr_goals=True,
    detach_prop_win=False,
    clean_up_yw=False,
)


def main():
    try:
        homeDir = str(Path.home()).replace('\\', '/')
        installDir = f'{homeDir}/.pywriter/{APPNAME}'
    except:
        installDir = '.'
    os.makedirs(installDir, exist_ok=True)
    configDir = f'{installDir}/config'
    os.makedirs(configDir, exist_ok=True)
    tempDir = f'{installDir}/temp'
    os.makedirs(tempDir, exist_ok=True)

    iniFile = f'{configDir}/{APPNAME}.ini'
    configuration = Configuration(SETTINGS, OPTIONS)
    configuration.read(iniFile)
    kwargs = {}
    kwargs.update(configuration.settings)
    kwargs.update(configuration.options)

    app = NovelystTk('novelyst 4.38.0', tempDir, **kwargs)

    try:
        sourcePath = sys.argv[1]
    except:
        sourcePath = ''
    if not sourcePath or not os.path.isfile(sourcePath):
        sourcePath = kwargs['yw_last_open']
    if sourcePath and os.path.isfile(sourcePath):
        app.root.after_idle(lambda:app.open_project(sourcePath))

    app.start()

    for keyword in app.kwargs:
        if keyword in configuration.options:
            configuration.options[keyword] = app.kwargs[keyword]
        elif keyword in configuration.settings:
            configuration.settings[keyword] = app.kwargs[keyword]
    configuration.write(iniFile)

    for file in os.scandir(tempDir):
        try:
            os.remove(file)
        except:
            pass


if __name__ == '__main__':
    main()
